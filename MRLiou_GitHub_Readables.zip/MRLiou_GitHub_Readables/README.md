# MRLiou Seed – GitHub Readable Pack

這個資料夾提供 **二進位封存檔** 的 **可讀對應版**，方便在 GitHub 預覽；同時保留原始二進位檔（若你要一起上傳）。  
也包含 `decode_files.py`，可將 `.pcode / .flpkg / .flynz.map / .rhythmwave / .hexsig` 等輸出成可讀摘要。

## 結構
- `spec/`：純文字規格與解說（給 GitHub 直接看）
- `bin/`：二進位樣本（若你想一起上傳或測試解碼器）
- `tools/`：轉譯/解碼工具腳本

> 注意：這些內容是**範本**與**對應文字版**，不會覆蓋你的原始封存定義。請把它們併到你的 repo，或用來產生自身系統的文字對應輸出。
