#!/usr/bin/env python3
# Minimal stub: parse spec/OriginCollapse.rhythmwave.txt pattern -> prints time events.
# 如需輸出 .wav，請在本機加上 sounddevice 或 wave 庫再擴充。