OpenAI System Package
Contains:
- docker-compose.yml
- wrapper service (Responses API wrapper)
- k8s manifests (deployment-wrapper.yaml)
- nginx config (example)
- mcp config placeholder
- server_tuning.sh (OS & NVIDIA tuning snippets)
- BIOS_CHECKLIST.md

Instructions:
1. Edit wrapper/.env with your OpenAI API key and settings.
2. (Local test) docker compose up -d
3. (K8s) kubectl apply -f k8s/
4. Follow server_tuning.sh to optimize your DL580 Gen9 node.
