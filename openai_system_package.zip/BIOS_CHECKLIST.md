BIOS / Firmware checklist for HP DL580 Gen9
- Update iLO to latest firmware
- Update system ROM / BIOS to latest
- Confirm PCIe riser configuration supports all GPUs
- Consider disabling C-States for latency-sensitive workloads
- Enable SR-IOV if using RoCE / RDMA networking
- Review power and thermal profiles
