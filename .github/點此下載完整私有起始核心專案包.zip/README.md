# MRLiou LogicSeed Core (Private Starter Kernel)

This is the private initiation package of MRLiou's core logic execution system.
It includes modular logic execution files, simulation tools, and CLI/API runners.

## Features
- Executable function chain (.fn)
- CLI/RESTful interface
- Logic structure trace maps and visual flowcharts
- Compression/restoration utilities

## Requirements
- Python 3.10+
- Packages: fastapi, uvicorn, rich

## Usage
```bash
python src/cli_runner.py
```

## License
This private package is under restricted license for internal development only.