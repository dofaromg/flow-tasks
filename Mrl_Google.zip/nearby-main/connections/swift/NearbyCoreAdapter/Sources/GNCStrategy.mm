// Copyright 2022 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#import "connections/swift/NearbyCoreAdapter/Sources/Public/NearbyCoreAdapter/GNCStrategy.h"

#import <Foundation/Foundation.h>

#include "connections/strategy.h"

#import "connections/swift/NearbyCoreAdapter/Sources/GNCStrategy+Internal.h"

namespace nearby {
namespace connections {

Strategy CppStrategyFromGNCStrategy(GNCStrategy strategy) {
  switch (strategy) {
    case GNCStrategyCluster:
      return Strategy::kP2pCluster;
    case GNCStrategyStar:
      return Strategy::kP2pStar;
    case GNCStrategyPointToPoint:
      return Strategy::kP2pPointToPoint;
  }
}

}  // namespace connections
}  // namespace nearby
