# AMP (Agent Memory Protocol) — deployable repo

High-throughput **index-only** event ledger with:
- Append-only **Causal Chain** (hash-linked)
- **Branch / Fork / Merge** (Git-like DAG)
- **Snapshot / Replay / Verify**
- Adapters:
  - Notion (metadata-only) ✅
  - GitHub (metadata-only) ✅ (commits via API) — optional

## Quick start (local)
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp config.sample.yaml config.yaml
python cli.py init
python cli.py append "hello"
python cli.py log --n 5
python cli.py verify
```

## Notion sync
```bash
export NOTION_TOKEN="..."
# put root IDs in config.yaml
python cli.py notion-sync
```

## GitHub sync (optional)
```bash
export GITHUB_TOKEN="..."
# set repos in config.yaml
python cli.py github-sync
```

## Docker
```bash
docker build -t amp .
docker run --rm -v "$PWD:/data" amp init
docker run --rm -v "$PWD:/data" amp append "hello"
docker run --rm -v "$PWD:/data" -e NOTION_TOKEN="..." amp notion-sync
```
