import sys, yaml, os, hashlib
from amp.storage import Storage
from amp.ledger import Ledger
from adapters.notion_adapter import sync as notion_sync
from adapters.github_adapter import sync as github_sync

def load_cfg():
    if os.path.exists("config.yaml"):
        return yaml.safe_load(open("config.yaml", "r", encoding="utf-8"))
    return yaml.safe_load(open("config.sample.yaml", "r", encoding="utf-8"))

def ledger_from_cfg(cfg):
    return Ledger(Storage(cfg["storage"]["dir"]),
                  chain_file=cfg["storage"]["chain_file"],
                  dag_file=cfg["storage"]["dag_file"],
                  refs_file=cfg["storage"]["refs_file"],
                  snapshots_dir=cfg["storage"]["snapshots_dir"])

def main():
    cfg = load_cfg()
    led = ledger_from_cfg(cfg)
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"

    if cmd == "init":
        led.init(); print("ok"); return
    if cmd == "append":
        payload = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else ""
        h = hashlib.sha256(payload.encode()).hexdigest()[:16]
        print(led.append({"type":"event","payload_hash":h,"size":len(payload)})); return
    if cmd == "log":
        n = 20
        if "--n" in sys.argv:
            n = int(sys.argv[sys.argv.index("--n")+1])
        for r in led.log(n=n):
            idx = r["idx"]
            print(r["hash"], idx.get("src","local"), idx.get("type"), idx.get("id") or idx.get("payload_hash"), idx.get("last_edited_time") or idx.get("t"))
        return
    if cmd == "verify":
        ok, msg = led.verify()
        print(("ok" if ok else "fail"), msg)
        sys.exit(0 if ok else 2)
    if cmd == "fork":
        led.fork(sys.argv[2], from_ref=(sys.argv[3] if len(sys.argv)>3 else "HEAD")); print("ok"); return
    if cmd == "merge":
        print(led.merge(other_ref=sys.argv[2], into_ref=(sys.argv[3] if len(sys.argv)>3 else "HEAD"))); return
    if cmd == "snapshot":
        print(led.snapshot(sys.argv[2] if len(sys.argv)>2 else "snap")); return
    if cmd == "replay":
        snap = led.replay(sys.argv[2]); print("ok", snap["head"]); return
    if cmd == "notion-sync":
        notion_sync("config.yaml" if os.path.exists("config.yaml") else "config.sample.yaml"); return
    if cmd == "github-sync":
        github_sync("config.yaml" if os.path.exists("config.yaml") else "config.sample.yaml"); return

    print("Commands: init, append, log, verify, fork, merge, snapshot, replay, notion-sync, github-sync")
    sys.exit(1)

if __name__ == "__main__":
    main()
