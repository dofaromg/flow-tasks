import json, os, hashlib

def sha256(s: bytes) -> str:
    return hashlib.sha256(s).hexdigest()

def jcanon(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)
