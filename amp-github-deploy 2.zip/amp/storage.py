import os, json
from amp.util import ensure_dir

class Storage:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        ensure_dir(self.base_dir)

    def path(self, *parts):
        return os.path.join(self.base_dir, *parts)

    def append_jsonl(self, rel_path: str, obj: dict):
        p = self.path(rel_path)
        ensure_dir(os.path.dirname(p))
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")

    def read_jsonl(self, rel_path: str):
        p = self.path(rel_path)
        if not os.path.exists(p):
            return []
        out = []
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    out.append(json.loads(line))
        return out

    def write_json(self, rel_path: str, obj: dict):
        p = self.path(rel_path)
        ensure_dir(os.path.dirname(p))
        with open(p, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2, sort_keys=True)

    def read_json(self, rel_path: str, default):
        p = self.path(rel_path)
        if not os.path.exists(p):
            return default
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
