from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
from amp.util import sha256, jcanon
from amp.storage import Storage
import time

@dataclass
class Edge:
    parent: str
    child: str
    kind: str   # "append" | "merge"

class Ledger:
    def __init__(self, storage: Storage, chain_file="chain.jsonl", dag_file="dag_edges.jsonl", refs_file="refs.json", snapshots_dir="snapshots"):
        self.s = storage
        self.chain_file = chain_file
        self.dag_file = dag_file
        self.refs_file = refs_file
        self.snapshots_dir = snapshots_dir

    def _hash_idx(self, idx: dict) -> str:
        return sha256(jcanon(idx))

    def _chain_hash(self, prev_hash: str, idx: dict) -> str:
        return sha256((prev_hash + ":" + self._hash_idx(idx)).encode("utf-8"))

    def init(self):
        refs = self.s.read_json(self.refs_file, default={})
        refs.setdefault("HEAD", "")
        refs.setdefault("main", "")
        self.s.write_json(self.refs_file, refs)

    def get_refs(self) -> dict:
        return self.s.read_json(self.refs_file, default={"HEAD": "", "main": ""})

    def set_ref(self, name: str, value: str):
        refs = self.get_refs()
        refs[name] = value
        self.s.write_json(self.refs_file, refs)

    def append(self, idx: dict, ref="HEAD") -> str:
        refs = self.get_refs()
        prev = refs.get(ref, "")
        idx = dict(idx)
        idx.setdefault("t", int(time.time()))
        h = self._chain_hash(prev, idx)
        self.s.append_jsonl(self.chain_file, {"hash": h, "prev": prev, "idx": idx})
        if prev:
            self.s.append_jsonl(self.dag_file, {"parent": prev, "child": h, "kind": "append"})
        self.set_ref(ref, h)
        return h

    def fork(self, new_ref: str, from_ref="HEAD"):
        refs = self.get_refs()
        refs[new_ref] = refs.get(from_ref, "")
        self.s.write_json(self.refs_file, refs)

    def merge(self, other_ref: str, into_ref="HEAD") -> str:
        refs = self.get_refs()
        a = refs.get(into_ref, "")
        b = refs.get(other_ref, "")
        idx = {"type": "merge", "parents": [a, b], "t": int(time.time())}
        h = self._chain_hash(a, idx)
        self.s.append_jsonl(self.chain_file, {"hash": h, "prev": a, "idx": idx})
        if a:
            self.s.append_jsonl(self.dag_file, {"parent": a, "child": h, "kind": "merge"})
        if b:
            self.s.append_jsonl(self.dag_file, {"parent": b, "child": h, "kind": "merge"})
        self.set_ref(into_ref, h)
        return h

    def log(self, ref="HEAD", n=20) -> List[dict]:
        refs = self.get_refs()
        cur = refs.get(ref, "")
        if not cur:
            return []
        recs = self.s.read_jsonl(self.chain_file)
        byh = {r["hash"]: r for r in recs}
        out = []
        while cur and len(out) < n and cur in byh:
            r = byh[cur]
            out.append(r)
            cur = r["prev"]
        return out

    def verify(self) -> Tuple[bool, str]:
        recs = self.s.read_jsonl(self.chain_file)
        byh = {r["hash"]: r for r in recs}
        for r in recs:
            expected = self._chain_hash(r["prev"], r["idx"])
            if expected != r["hash"]:
                return False, f"hash mismatch at {r['hash']}"
            if r["prev"] and r["prev"] not in byh:
                return False, f"missing prev {r['prev']} for {r['hash']}"
        return True, "ok"

    def snapshot(self, name: str, ref="HEAD") -> str:
        refs = self.get_refs()
        head = refs.get(ref, "")
        snap = {"ref": ref, "head": head, "refs": refs}
        path = f"{self.snapshots_dir}/{name}.json"
        self.s.write_json(path, snap)
        return path

    def replay(self, snapshot_name: str) -> dict:
        path = f"{self.snapshots_dir}/{snapshot_name}.json"
        snap = self.s.read_json(path, default=None)
        if snap is None:
            raise FileNotFoundError(path)
        self.s.write_json(self.refs_file, snap["refs"])
        return snap
