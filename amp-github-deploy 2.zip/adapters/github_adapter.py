import os, yaml, requests
from amp.ledger import Ledger
from amp.storage import Storage

API = "https://api.github.com"

def _headers(token: str):
    return {"Authorization": f"token {token}", "Accept":"application/vnd.github+json", "User-Agent":"amp-github-adapter"}

def sync(config_path="config.yaml"):
    cfg = yaml.safe_load(open(config_path, "r", encoding="utf-8"))
    gh = cfg.get("github", {})
    if not gh.get("enabled", False):
        print("github disabled"); return

    token = os.environ.get(gh.get("token_env","GITHUB_TOKEN"))
    if not token:
        raise SystemExit("Missing GITHUB_TOKEN env var")

    led = Ledger(Storage(cfg["storage"]["dir"]),
                 chain_file=cfg["storage"]["chain_file"],
                 dag_file=cfg["storage"]["dag_file"],
                 refs_file=cfg["storage"]["refs_file"],
                 snapshots_dir=cfg["storage"]["snapshots_dir"])
    led.init()

    for repo in (gh.get("repos") or []):
        url = f"{API}/repos/{repo}/commits?per_page=30"
        r = requests.get(url, headers=_headers(token), timeout=30)
        r.raise_for_status()
        for c in r.json():
            commit = c.get("commit") or {}
            author = commit.get("author") or {}
            idx = {"src":"github","repo":repo,"type":"commit","id":c.get("sha"),"last_edited_time":author.get("date"),"url":c.get("html_url")}
            led.append(idx, ref="HEAD")
    print("github sync ok")
