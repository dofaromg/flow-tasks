import os, yaml
from notion_client import Client
from amp.ledger import Ledger
from amp.storage import Storage

def to_index(obj: dict) -> dict:
    _id = obj.get("id")
    _type = obj.get("object")
    _parent = obj.get("parent", {}) or {}
    pt = _parent.get("type")
    pid = _parent.get(pt) if pt else None
    created = obj.get("created_time")
    updated = obj.get("last_edited_time")
    archived = obj.get("archived", False)
    title = None
    if _type == "page":
        props = obj.get("properties", {}) or {}
        for _, v in props.items():
            if (v or {}).get("type") == "title":
                t = v.get("title", []) or []
                title = "".join([x.get("plain_text","") for x in t])[:120]
                break
    elif _type == "database":
        t = obj.get("title", []) or []
        title = "".join([x.get("plain_text","") for x in t])[:120]
    return {"src":"notion","id":_id,"type":_type,"parent_type":pt,"parent_id":pid,"created_time":created,"last_edited_time":updated,"archived":archived,"title":title}

def list_children_blocks(client: Client, block_id: str, page_size: int = 100):
    cursor = None
    while True:
        resp = client.blocks.children.list(block_id=block_id, start_cursor=cursor, page_size=page_size)
        for b in (resp.get("results") or []):
            yield b
        cursor = resp.get("next_cursor")
        if not resp.get("has_more"):
            break

def sync(config_path="config.yaml"):
    cfg = yaml.safe_load(open(config_path, "r", encoding="utf-8"))
    notion_cfg = cfg.get("notion", {})
    if not notion_cfg.get("enabled", True):
        print("notion disabled"); return

    token = os.environ.get(notion_cfg.get("token_env","NOTION_TOKEN"))
    if not token:
        raise SystemExit("Missing NOTION_TOKEN env var")

    led = Ledger(Storage(cfg["storage"]["dir"]),
                 chain_file=cfg["storage"]["chain_file"],
                 dag_file=cfg["storage"]["dag_file"],
                 refs_file=cfg["storage"]["refs_file"],
                 snapshots_dir=cfg["storage"]["snapshots_dir"])
    led.init()

    client = Client(auth=token)
    roots = notion_cfg.get("roots", [])
    visited = set()

    def ingest(obj):
        idx = to_index(obj)
        if not idx.get("id") or idx["id"] in visited:
            return
        visited.add(idx["id"])
        led.append(idx, ref="HEAD")

    for rid in roots:
        try:
            ingest(client.pages.retrieve(page_id=rid))
            for b in list_children_blocks(client, rid):
                if b.get("type") == "child_page":
                    try:
                        ingest(client.pages.retrieve(page_id=b["id"]))
                    except Exception:
                        pass
        except Exception:
            try:
                ingest(client.databases.retrieve(database_id=rid))
            except Exception:
                pass

    print(f"notion sync ok: {len(visited)} objects")
