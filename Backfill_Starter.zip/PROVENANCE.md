# PROVENANCE（證據與參考）
- External: ChatGPT share https://chatgpt.com/share/68c3928d-f52c-800d-94b6-1cc45ff9d961
- Hashes: 對關鍵快照/檔案計算 SHA-256 並記錄於此
- Signed tags / Sigstore: 如使用 git 或 cosign，請把 log/URL 放這裡
