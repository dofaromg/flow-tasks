#ifndef MRLIOU_MRL_ATOM_H
#define MRLIOU_MRL_ATOM_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Compiler_Atom | LAW-0 原子 40-byte(既有規格);type_id 編碼 mrl.type.*(裁定03) */
#pragma pack(push,1)
typedef struct {
    uint32_t magic;       /* 'MRL0' = 0x304C524D (LE) */
    uint32_t type_id;     /* mrl.type.* */
    uint64_t particle_id;
    uint64_t payload_lo;
    uint64_t payload_hi;
    uint32_t eta_q16;     /* η Q16 定點 */
    uint32_t sig_crc;     /* CRC32 槽位;Ed25519 全簽走既有 Pure C 外掛 */
} mrliou_mrl_atom_t;
#pragma pack(pop)
_Static_assert(sizeof(mrliou_mrl_atom_t) == 40, "atom_t must be 40 bytes (LAW-0 spec)");
#endif
