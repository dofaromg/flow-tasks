#ifndef MRLIOU_MRL_DATABASE_H
#define MRLIOU_MRL_DATABASE_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Database | Wave_02 local database(local only / process-local / no external DB)
 * iterate = key 升冪(strcmp;確定性順序);cb 回非 0 提前停止;iterate 回傳已訪數或 E_ARG。 */
#define MRLIOU_MRL_DB_SLOTS   64
#define MRLIOU_MRL_DB_KEY_MAX 48
#define MRLIOU_MRL_DB_VAL_MAX 256
typedef int (*mrliou_mrl_database_iter_fn)(const char *key, const void *val, uint64_t n, void *ud);
int mrliou_mrl_database_init(void);
int mrliou_mrl_database_put(const char *key, const void *val, uint64_t n);
int mrliou_mrl_database_get(const char *key, void *buf, uint64_t cap, uint64_t *out_n);
int mrliou_mrl_database_delete(const char *key);
int mrliou_mrl_database_iterate(mrliou_mrl_database_iter_fn cb, void *ud);
int mrliou_mrl_database_reset(void);
#endif
