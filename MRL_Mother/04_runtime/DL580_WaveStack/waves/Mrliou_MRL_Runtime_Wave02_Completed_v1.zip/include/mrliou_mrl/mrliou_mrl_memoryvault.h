#ifndef MRLIOU_MRL_MEMORYVAULT_H
#define MRLIOU_MRL_MEMORYVAULT_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_MemoryVault | Wave_02 封存層
 * archive/restore roundtrip;每筆封存保留 origin_signature 與 CRC;manifest 確定性;
 * no external storage(process-local)。archive_id 自 1 起確定性遞增。 */
#define MRLIOU_MRL_VAULT_SLOTS   32
#define MRLIOU_MRL_VAULT_TAG_MAX 32
#define MRLIOU_MRL_VAULT_VAL_MAX 256
int mrliou_mrl_memoryvault_init(void);
int mrliou_mrl_memoryvault_archive(const char *tag, const void *data, uint64_t n, uint32_t *out_archive_id);
int mrliou_mrl_memoryvault_restore(uint32_t archive_id, void *buf, uint64_t cap, uint64_t *out_n);
int mrliou_mrl_memoryvault_manifest(char *out, uint64_t cap);
int mrliou_mrl_memoryvault_reset(void);
#endif
