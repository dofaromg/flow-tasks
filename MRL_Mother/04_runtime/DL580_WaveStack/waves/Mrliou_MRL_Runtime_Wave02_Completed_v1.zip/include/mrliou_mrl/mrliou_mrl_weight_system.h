#ifndef MRLIOU_MRL_WEIGHT_SYSTEM_H
#define MRLIOU_MRL_WEIGHT_SYSTEM_H
/* canonical_name: Mrliou_MRL_WeightSystem | 10D 權重治理,Σ(D_i)=10.0 */
int mrliou_mrl_weight_system_validate(const double d[10]);
#endif
