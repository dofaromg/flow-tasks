#ifndef MRLIOU_MRL_ENGINE_H
#define MRLIOU_MRL_ENGINE_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Engine | 粒子場演化核;創世公式 P_{k+1}=N_k*P_k*eta_k(LAW-3 記 Δ) */
double   mrliou_mrl_engine_evolve(double P_k, double N_k, double eta_k);
uint64_t mrliou_mrl_engine_delta_count(void);
#endif
