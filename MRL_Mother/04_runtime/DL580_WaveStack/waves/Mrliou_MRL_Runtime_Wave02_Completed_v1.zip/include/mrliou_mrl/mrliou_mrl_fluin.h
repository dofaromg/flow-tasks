#ifndef MRLIOU_MRL_FLUIN_H
#define MRLIOU_MRL_FLUIN_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Fluin | 粒子向量符號層,Binary Spatter Code(2048-bit),XOR 綁定=天生可逆(LAW-2)
 * 正式粒子: Mrliou_MRL_Fluin_Bind / _Unbind(繼承律;C 符號=小寫投影) */
#define MRLIOU_MRL_FLUIN_DIM 256
typedef struct { uint8_t v[MRLIOU_MRL_FLUIN_DIM]; } mrliou_mrl_fluin_vec_t;
void mrliou_mrl_fluin_bind  (const mrliou_mrl_fluin_vec_t *role, const mrliou_mrl_fluin_vec_t *filler, mrliou_mrl_fluin_vec_t *bound);
void mrliou_mrl_fluin_unbind(const mrliou_mrl_fluin_vec_t *bound, const mrliou_mrl_fluin_vec_t *role,  mrliou_mrl_fluin_vec_t *filler);
int  mrliou_mrl_fluin_equal (const mrliou_mrl_fluin_vec_t *a, const mrliou_mrl_fluin_vec_t *b);
#endif
