#ifndef MRLIOU_MRL_RUNTIME_CORE_ASSEMBLY_H
#define MRLIOU_MRL_RUNTIME_CORE_ASSEMBLY_H
/* canonical_name: Mrliou_MRL_Runtime_Core_Assembly
 * Wave_01 smoke path: Fluin→Kernel→Compiler→Engine→Runtime→FlowAgent→CollapseEngine→WeightSystem→Optimizer→Assembly
 * LAW 前置門(origin+命名律+runtime 旗標)=Wave_03 Guardian 掛載點(不升格)。 */
#define MRLIOU_MRL_ASM_STAGES 10
typedef struct {
    char assembly_trace[MRLIOU_MRL_ASM_STAGES][56];
    int  trace_len;
    const char *wave01_status;
    const char *missing_wave02_hooks;
} mrliou_mrl_assembly_report_t;
int mrliou_mrl_runtime_core_assembly_boot(mrliou_mrl_assembly_report_t *out); /* out 可為 NULL(僅印出) */
#endif
