#ifndef MRLIOU_MRL_MEMORYLAYER_H
#define MRLIOU_MRL_MEMORYLAYER_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_MemoryLayer | Wave_02 Runtime 記憶層(canonical KV)
 * process-local / deterministic / no network / no external storage。
 * Mrliou_MRL_Kernel 之 MemIO 已委派至本層。lazy ensure-init(確定性)。 */
#define MRLIOU_MRL_MEML_KEY_MAX 48
#define MRLIOU_MRL_MEML_VAL_MAX 512
#define MRLIOU_MRL_MEML_SLOTS   128
int mrliou_mrl_memorylayer_init(void);
int mrliou_mrl_memorylayer_write(const char *key, const void *buf, uint64_t n);
int mrliou_mrl_memorylayer_read (const char *key, void *buf, uint64_t cap, uint64_t *out_n);
int mrliou_mrl_memorylayer_delete(const char *key);
int mrliou_mrl_memorylayer_exists(const char *key); /* 1=存在, 0=不存在, <0=錯誤 */
int mrliou_mrl_memorylayer_reset(void);
#endif
