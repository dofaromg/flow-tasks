#ifndef MRLIOU_MRL_FLOWAGENT_H
#define MRLIOU_MRL_FLOWAGENT_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_FlowAgent | 推理控制。
 * Wave_01 補滿: deterministic 骨架決策(同輸入必同輸出;無 random/network/外部模型)。
 * 「符號定邊界+機率選一」之骨架投影 = legal_mask 定邊界 + 確定性 mix 選位 + 均勻信心。
 * scope=skeleton_decision(非完整 P1 推理,誠實標註)。 */
typedef struct {
    uint32_t signal;      /* runtime context 訊號 */
    uint32_t legal_mask;  /* 符號層合法路由遮罩(bit i = route i 合法) */
} mrliou_mrl_flow_context_t;
typedef struct {
    int decision_code;        /* 0=decided, 1=no_legal_route */
    int route;                /* 選中路由;-1=無 */
    int legal_count;
    uint32_t confidence_q16;  /* 0..65536 ⇔ 0..1 */
} mrliou_mrl_flow_decision_t;
int mrliou_mrl_flowagent_decide(const mrliou_mrl_flow_context_t *ctx, mrliou_mrl_flow_decision_t *out);
#endif
