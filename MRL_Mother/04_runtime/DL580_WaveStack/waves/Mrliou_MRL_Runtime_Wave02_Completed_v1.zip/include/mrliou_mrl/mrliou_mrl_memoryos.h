#ifndef MRLIOU_MRL_MEMORYOS_H
#define MRLIOU_MRL_MEMORYOS_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_MemoryOS | Wave_02 記憶命名空間管理
 * ns_id = FNV-1a(name)(確定性:同名跨次必同 id);duplicate=E_DUP;missing=E_NOT_FOUND。 */
#define MRLIOU_MRL_MEMOS_NS_MAX   16
#define MRLIOU_MRL_MEMOS_NAME_MAX 32
int mrliou_mrl_memoryos_init(void);
int mrliou_mrl_memoryos_namespace_create(const char *name, uint32_t *out_ns_id);
int mrliou_mrl_memoryos_namespace_lookup(const char *name, uint32_t *out_ns_id);
int mrliou_mrl_memoryos_namespace_delete(const char *name);
int mrliou_mrl_memoryos_reset(void);
#endif
