#ifndef MRLIOU_MRL_OPTIMIZER_H
#define MRLIOU_MRL_OPTIMIZER_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Optimizer | 最小優化通道(Wave_01 補滿)。
 * 規則: 摺疊 weight==0 且 required==0 之冗餘節點;required 節點絕不刪除;
 * provenance_fp 保留原始出處指紋(LAW-2 before/after 可對照);deterministic + idempotent。 */
#define MRLIOU_MRL_PLAN_MAX 32
typedef struct {
    uint32_t node_id;
    uint32_t weight;     /* 0 = 冗餘候選 */
    uint8_t  required;   /* 1 = 必要節點(不可刪) */
} mrliou_mrl_plan_node_t;
typedef struct {
    mrliou_mrl_plan_node_t nodes[MRLIOU_MRL_PLAN_MAX];
    int n;
    uint32_t provenance_fp;   /* 原始 plan 指紋;優化後保留 */
} mrliou_mrl_plan_t;
int mrliou_mrl_optimizer_pass(const mrliou_mrl_plan_t *in, mrliou_mrl_plan_t *out);
#endif
