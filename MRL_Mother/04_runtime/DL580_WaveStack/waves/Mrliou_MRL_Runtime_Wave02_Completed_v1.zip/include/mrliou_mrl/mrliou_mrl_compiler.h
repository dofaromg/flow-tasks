#ifndef MRLIOU_MRL_COMPILER_H
#define MRLIOU_MRL_COMPILER_H
#include <stddef.h>
#include <stdint.h>
#include "mrliou_mrl/mrliou_mrl_atom.h"
/* canonical_name: Mrliou_MRL_Compiler | LAW-1 描述 → LAW-0 atom_t[](40B);編譯↔反解可逆(LAW-2)
 * Ed25519 全簽 = 既有 Pure C 路徑外掛(Wave_01=NULL,不偽造簽名) */
extern int (*mrliou_mrl_ed25519_sign_hook)(const uint8_t *msg, size_t len, uint8_t out_sig[64]);
int mrliou_mrl_compiler_compile  (const char *law1_src, mrliou_mrl_atom_t *out, size_t max_atoms, size_t *n_atoms);
int mrliou_mrl_compiler_decompile(const mrliou_mrl_atom_t *atoms, size_t n_atoms, char *out, size_t out_cap);
uint32_t mrliou_mrl_crc32(const void *data, size_t len);
#endif
