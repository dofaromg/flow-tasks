#ifndef MRLIOU_MRL_MEMORYCUBE_H
#define MRLIOU_MRL_MEMORYCUBE_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_MemoryCube | Wave_02 多維記憶容器
 * cube_id(0..7) + coordinate(x,y,z 各 0..3) + payload(≤64B);trace=占用格升冪(確定性)。 */
#define MRLIOU_MRL_CUBE_MAX         8
#define MRLIOU_MRL_CUBE_AXIS        4
#define MRLIOU_MRL_CUBE_CELLS       64   /* 4*4*4 */
#define MRLIOU_MRL_CUBE_PAYLOAD_MAX 64
typedef struct { uint32_t x, y, z; } mrliou_mrl_cube_coord_t;
int mrliou_mrl_memorycube_init(void);
int mrliou_mrl_memorycube_store(uint32_t cube_id, const mrliou_mrl_cube_coord_t *c, const void *payload, uint64_t n);
int mrliou_mrl_memorycube_fetch(uint32_t cube_id, const mrliou_mrl_cube_coord_t *c, void *buf, uint64_t cap, uint64_t *out_n);
int mrliou_mrl_memorycube_trace(uint32_t cube_id, uint32_t *out_trace, int trace_cap, int *out_len); /* entry=(cell_idx<<8)|len */
int mrliou_mrl_memorycube_reset(void);
#endif
