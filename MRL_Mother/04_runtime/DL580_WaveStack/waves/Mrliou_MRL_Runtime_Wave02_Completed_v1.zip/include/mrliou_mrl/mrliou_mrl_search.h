#ifndef MRLIOU_MRL_SEARCH_H
#define MRLIOU_MRL_SEARCH_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Search | Wave_02 查詢層(建構於 Mrliou_MRL_Database 之上)
 * exact / prefix / namespace(鍵慣例 "<ns>:<rest>",ns 須存在於 Mrliou_MRL_MemoryOS)
 * 結果順序 = key 升冪(確定性);無匹配 = E_NOT_FOUND;結果溢出(>16)= E_ARG。 */
#define MRLIOU_MRL_SEARCH_MAX 16
typedef struct {
    char keys[MRLIOU_MRL_SEARCH_MAX][48];
    int count;
} mrliou_mrl_search_result_t;
int mrliou_mrl_search_exact(const char *key, mrliou_mrl_search_result_t *out);
int mrliou_mrl_search_prefix(const char *prefix, mrliou_mrl_search_result_t *out);
int mrliou_mrl_search_namespace(const char *ns_name, mrliou_mrl_search_result_t *out);
int mrliou_mrl_search_reset(void);
uint64_t mrliou_mrl_search_query_count(void);
#endif
