#ifndef MRLIOU_MRL_LAW_H
#define MRLIOU_MRL_LAW_H
/* canonical_name: Mrliou_MRL_LAW_Interface | origin_signature: MrLiouWord
 * LAW-0~8 gate hooks, skeleton-level strengthened(Wave_01 封版)。
 * 不升格為 Guardian: Wave_03 Mrliou_MRL_Guardian 接管全部鉤位。 */
#define MRLIOU_MRL_ORIGIN_SIGNATURE "MrLiouWord"
#define MRLIOU_MRL_WAVE01_VERSION   "MRL_Runtime_Wave01_v1.0"   /* W1 封版標籤(lineage) */
#define MRLIOU_MRL_WAVE02_VERSION   "Mrliou_MRL_Runtime_Wave02_v1.0"
typedef enum { MRLIOU_MRL_GATE_ALLOW = 0, MRLIOU_MRL_GATE_BLOCK = 1 } mrliou_mrl_gate_t;
/* LAW-0: origin 驗證 */
mrliou_mrl_gate_t mrliou_mrl_law_verify(const char *origin_signature);
/* 繼承律: core node 名必為 Mrliou_MRL_ 前綴;External_*/
/* 與外部主權名禁入 core node。0=合法, -1=違規(範圍=core node;產品層 W5 另計) */
int mrliou_mrl_law_check_module_name(const char *module_name);
/* runtime_not_complete 旗標保護: Wave_01 內必為 1;改 0(=宣告 Runtime 完成)即違規 */
int mrliou_mrl_law_check_runtime_flag(int runtime_not_complete_flag);
#endif
