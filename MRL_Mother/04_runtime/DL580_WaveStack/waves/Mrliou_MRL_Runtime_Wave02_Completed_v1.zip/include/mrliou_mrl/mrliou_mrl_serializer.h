#ifndef MRLIOU_MRL_SERIALIZER_H
#define MRLIOU_MRL_SERIALIZER_H
#include <stdint.h>
#include "mrliou_mrl/mrliou_mrl_atom.h"
#include "mrliou_mrl/mrliou_mrl_memorycube.h"
/* canonical_name: Mrliou_MRL_Serializer | Wave_02 序列化層
 * 確定性二進位框架: [u32 magic 'MRLS'][u32 type][u64 body_len][body][u32 crc32(body)](全 LE)
 * type: 1=atom(40B), 2=memory_record, 3=cube_object;invalid payload/size → E_ARG。 */
#define MRLIOU_MRL_SER_MAGIC     0x534C524Du /* 'MRLS' LE */
#define MRLIOU_MRL_SER_T_ATOM    1u
#define MRLIOU_MRL_SER_T_MEMREC  2u
#define MRLIOU_MRL_SER_T_CUBEOBJ 3u
typedef struct {
    char key[48];
    uint64_t len;
    uint8_t val[256];
} mrliou_mrl_memory_record_t;
typedef struct {
    uint32_t cube_id;
    mrliou_mrl_cube_coord_t coord;
    uint64_t len;
    uint8_t payload[64];
} mrliou_mrl_cube_object_t;
int mrliou_mrl_serializer_atom(const mrliou_mrl_atom_t *a, uint8_t *out, uint64_t cap, uint64_t *out_n);
int mrliou_mrl_deserializer_atom(const uint8_t *in, uint64_t n, mrliou_mrl_atom_t *out);
int mrliou_mrl_serializer_memory_record(const mrliou_mrl_memory_record_t *r, uint8_t *out, uint64_t cap, uint64_t *out_n);
int mrliou_mrl_deserializer_memory_record(const uint8_t *in, uint64_t n, mrliou_mrl_memory_record_t *out);
int mrliou_mrl_serializer_cube_object(const mrliou_mrl_cube_object_t *o, uint8_t *out, uint64_t cap, uint64_t *out_n);
int mrliou_mrl_deserializer_cube_object(const uint8_t *in, uint64_t n, mrliou_mrl_cube_object_t *out);
#endif
