#ifndef MRLIOU_MRL_RUNTIME_H
#define MRLIOU_MRL_RUNTIME_H
/* canonical_name: Mrliou_MRL_Runtime | 執行宿主,生命週期 init→run→suspend→resume→halt
 * lineage(source_ref,裁定01): FlowAgent.Runtime v1-v56 — 參照非主體,禁升格 */
typedef enum {
    MRLIOU_MRL_RT_INIT = 0,
    MRLIOU_MRL_RT_RUN,
    MRLIOU_MRL_RT_SUSPEND,
    MRLIOU_MRL_RT_HALT
} mrliou_mrl_rt_state_t;
typedef struct { mrliou_mrl_rt_state_t state; } mrliou_mrl_runtime_t;
int mrliou_mrl_runtime_init(mrliou_mrl_runtime_t *rt);
int mrliou_mrl_runtime_transition(mrliou_mrl_runtime_t *rt, mrliou_mrl_rt_state_t target);
#endif
