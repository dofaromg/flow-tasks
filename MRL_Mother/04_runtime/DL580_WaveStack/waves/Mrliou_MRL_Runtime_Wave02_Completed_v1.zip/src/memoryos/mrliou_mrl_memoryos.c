#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memoryos.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
typedef struct { int used; char name[MRLIOU_MRL_MEMOS_NAME_MAX]; uint32_t ns_id; } mrliou_mrl_memos_ns_t;
static mrliou_mrl_memos_ns_t g_ns[MRLIOU_MRL_MEMOS_NS_MAX];
static int g_os_init = 0;
static void memos_ensure(void){ if (!g_os_init){ memset(g_ns, 0, sizeof g_ns); g_os_init = 1; } }
static uint32_t memos_fnv(const char *s){
    uint32_t h = 2166136261u;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++){ h ^= *p; h *= 16777619u; }
    return h ? h : 1u;  /* ns_id 恆非 0;確定性 */
}
static int memos_check_name(const char *name){
    if (!name || name[0] == '\0') return -1;
    if (strlen(name) >= MRLIOU_MRL_MEMOS_NAME_MAX) return -1;
    return 0;
}
static mrliou_mrl_memos_ns_t *memos_find(const char *name){
    for (int i = 0; i < MRLIOU_MRL_MEMOS_NS_MAX; i++)
        if (g_ns[i].used && strcmp(g_ns[i].name, name) == 0) return &g_ns[i];
    return 0;
}
int mrliou_mrl_memoryos_init(void){
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    memset(g_ns, 0, sizeof g_ns);
    g_os_init = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memoryos_namespace_create(const char *name, uint32_t *out_ns_id){
    if (memos_check_name(name) != 0) return MRLIOU_MRL_E_ARG;
    memos_ensure();
    if (memos_find(name)) return MRLIOU_MRL_E_DUP;                       /* duplicate = error */
    mrliou_mrl_memos_ns_t *s = 0;
    for (int i = 0; i < MRLIOU_MRL_MEMOS_NS_MAX; i++) if (!g_ns[i].used){ s = &g_ns[i]; break; }
    if (!s) return MRLIOU_MRL_E_ARG;                                     /* 容量滿 */
    memset(s, 0, sizeof *s);
    size_t nl = strlen(name);
    memcpy(s->name, name, nl); s->name[nl] = '\0';
    s->ns_id = memos_fnv(name);
    s->used = 1;
    if (out_ns_id) *out_ns_id = s->ns_id;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memoryos_namespace_lookup(const char *name, uint32_t *out_ns_id){
    if (memos_check_name(name) != 0) return MRLIOU_MRL_E_ARG;
    memos_ensure();
    mrliou_mrl_memos_ns_t *s = memos_find(name);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;
    if (out_ns_id) *out_ns_id = s->ns_id;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memoryos_namespace_delete(const char *name){
    if (memos_check_name(name) != 0) return MRLIOU_MRL_E_ARG;
    memos_ensure();
    mrliou_mrl_memos_ns_t *s = memos_find(name);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;
    memset(s, 0, sizeof *s);
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memoryos_reset(void){
    memset(g_ns, 0, sizeof g_ns);
    g_os_init = 1;
    return MRLIOU_MRL_E_OK;
}
