#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memoryvault.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_compiler.h"  /* mrliou_mrl_crc32 */
typedef struct {
    int used;
    uint32_t id;
    char tag[MRLIOU_MRL_VAULT_TAG_MAX];
    char origin[16];
    uint64_t len;
    uint32_t crc;
    uint8_t data[MRLIOU_MRL_VAULT_VAL_MAX];
} mrliou_mrl_vault_slot_t;
static mrliou_mrl_vault_slot_t g_vault[MRLIOU_MRL_VAULT_SLOTS];
static uint32_t g_vault_next = 1;
static int g_vault_init = 0;
static void vault_ensure(void){ if (!g_vault_init){ memset(g_vault, 0, sizeof g_vault); g_vault_next = 1; g_vault_init = 1; } }
int mrliou_mrl_memoryvault_init(void){
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    memset(g_vault, 0, sizeof g_vault);
    g_vault_next = 1;
    g_vault_init = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memoryvault_archive(const char *tag, const void *data, uint64_t n, uint32_t *out_archive_id){
    if (!tag || tag[0] == '\0' || strlen(tag) >= MRLIOU_MRL_VAULT_TAG_MAX) return MRLIOU_MRL_E_ARG;
    if (!data || n == 0 || n > MRLIOU_MRL_VAULT_VAL_MAX) return MRLIOU_MRL_E_ARG;
    vault_ensure();
    mrliou_mrl_vault_slot_t *s = 0;
    for (int i = 0; i < MRLIOU_MRL_VAULT_SLOTS; i++) if (!g_vault[i].used){ s = &g_vault[i]; break; }
    if (!s) return MRLIOU_MRL_E_ARG;                                     /* 容量滿 */
    memset(s, 0, sizeof *s);
    s->id = g_vault_next++;
    size_t tl = strlen(tag);
    memcpy(s->tag, tag, tl); s->tag[tl] = '\0';
    memcpy(s->origin, MRLIOU_MRL_ORIGIN_SIGNATURE, sizeof MRLIOU_MRL_ORIGIN_SIGNATURE); /* preserve origin */
    memcpy(s->data, data, (size_t)n);
    s->len = n;
    s->crc = mrliou_mrl_crc32(data, (size_t)n);
    s->used = 1;
    if (out_archive_id) *out_archive_id = s->id;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memoryvault_restore(uint32_t archive_id, void *buf, uint64_t cap, uint64_t *out_n){
    if (!buf || !out_n) return MRLIOU_MRL_E_ARG;
    vault_ensure();
    mrliou_mrl_vault_slot_t *s = 0;
    for (int i = 0; i < MRLIOU_MRL_VAULT_SLOTS; i++)
        if (g_vault[i].used && g_vault[i].id == archive_id){ s = &g_vault[i]; break; }
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;
    if (strcmp(s->origin, MRLIOU_MRL_ORIGIN_SIGNATURE) != 0) return MRLIOU_MRL_E_LAW;   /* origin 保護 */
    if (mrliou_mrl_crc32(s->data, (size_t)s->len) != s->crc) return MRLIOU_MRL_E_LAW;   /* 完整性 */
    if (cap < s->len) return MRLIOU_MRL_E_ARG;
    memcpy(buf, s->data, (size_t)s->len);
    *out_n = s->len;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memoryvault_manifest(char *out, uint64_t cap){
    if (!out || cap < 40) return MRLIOU_MRL_E_ARG;
    vault_ensure();
    int w = snprintf(out, (size_t)cap, "Mrliou_MRL_MemoryVault_Manifest v1\n");
    if (w < 0 || (uint64_t)w >= cap) return MRLIOU_MRL_E_ARG;
    uint64_t off = (uint64_t)w;
    for (int i = 0; i < MRLIOU_MRL_VAULT_SLOTS; i++){                    /* id 升冪(無刪除;槽序=id 序) */
        if (!g_vault[i].used) continue;
        w = snprintf(out + off, (size_t)(cap - off), "id=%u tag=%s len=%llu crc=%08x origin=%s\n",
                     (unsigned)g_vault[i].id, g_vault[i].tag,
                     (unsigned long long)g_vault[i].len, (unsigned)g_vault[i].crc, g_vault[i].origin);
        if (w < 0 || (uint64_t)w >= cap - off) return MRLIOU_MRL_E_ARG;  /* size check */
        off += (uint64_t)w;
    }
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memoryvault_reset(void){
    memset(g_vault, 0, sizeof g_vault);
    g_vault_next = 1;
    g_vault_init = 1;
    return MRLIOU_MRL_E_OK;
}
