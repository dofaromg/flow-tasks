#include <string.h>
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_memorylayer.h"
int mrliou_mrl_kernel_init(mrliou_mrl_kernel_t *k){
    if (!k) return MRLIOU_MRL_E_ARG;
    memset(&k->latent, 0, sizeof k->latent);
    k->delta_count = 0;
    memset(k->origin_signature, 0, sizeof k->origin_signature);
    strncpy(k->origin_signature, MRLIOU_MRL_ORIGIN_SIGNATURE, sizeof k->origin_signature - 1);
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_kernel_step(mrliou_mrl_kernel_t *k, const mrliou_mrl_fluin_vec_t *input){
    if (!k || !input) return MRLIOU_MRL_E_ARG;
    if (mrliou_mrl_law_verify(k->origin_signature) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    mrliou_mrl_fluin_vec_t next;
    mrliou_mrl_fluin_bind(&k->latent, input, &next); /* 可逆變換骨架 */
    k->latent = next;
    k->delta_count++; /* LAW-3 */
    return MRLIOU_MRL_E_OK;
}
/* ---- MemIO: W1 contract 檢查 → 委派 Mrliou_MRL_MemoryLayer(W2 canonical 記憶層) ---- */
static int memio_check_key(const char *key){
    if (!key || key[0] == '\0') return -1;
    if (strlen(key) >= MRLIOU_MRL_MEMIO_KEY_MAX) return -1;
    return 0;
}
int mrliou_mrl_kernel_memio_write(mrliou_mrl_kernel_t *k, const char *key, const void *buf, uint64_t n){
    if (!k || !buf) return MRLIOU_MRL_E_ARG;
    if (memio_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (n == 0 || n > MRLIOU_MRL_MEMIO_VAL_MAX) return MRLIOU_MRL_E_ARG;   /* W1 size 契約 */
    if (mrliou_mrl_law_verify(k->origin_signature) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    return mrliou_mrl_memorylayer_write(key, buf, n);
}
int mrliou_mrl_kernel_memio_read(mrliou_mrl_kernel_t *k, const char *key, void *buf, uint64_t cap, uint64_t *out_n){
    if (!k || !buf || !out_n) return MRLIOU_MRL_E_ARG;
    if (memio_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (mrliou_mrl_law_verify(k->origin_signature) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    return mrliou_mrl_memorylayer_read(key, buf, cap, out_n);
}
