#include <string.h>
#include "mrliou_mrl/mrliou_mrl_law.h"
mrliou_mrl_gate_t mrliou_mrl_law_verify(const char *origin_signature){
    if (origin_signature && strcmp(origin_signature, MRLIOU_MRL_ORIGIN_SIGNATURE) == 0) return MRLIOU_MRL_GATE_ALLOW;
    return MRLIOU_MRL_GATE_BLOCK;
}
/* 外部主權名 token(禁入 core node;品牌僅得存在於 source_ref/adapter 層) */
static const char *k_forbidden_core_tokens[] = {
    "External_", "Firebase", "OpenAI", "ChatGPT", "Google_", "AWS_", "Azure_", "Notion_"
};
int mrliou_mrl_law_check_module_name(const char *module_name){
    if (!module_name || module_name[0] == '\0') return -1;
    for (unsigned i = 0; i < sizeof k_forbidden_core_tokens / sizeof k_forbidden_core_tokens[0]; i++)
        if (strstr(module_name, k_forbidden_core_tokens[i])) return -1;
    if (strncmp(module_name, "Mrliou_MRL_", 11) != 0) return -1; /* 繼承律 */
    return 0;
}
int mrliou_mrl_law_check_runtime_flag(int runtime_not_complete_flag){
    return (runtime_not_complete_flag == 1) ? 0 : -1; /* Wave_01: 禁宣告 Runtime 完成 */
}
