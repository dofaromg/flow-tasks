#include <string.h>
#include "mrliou_mrl/mrliou_mrl_optimizer.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
static uint32_t mrliou_mrl_fold32(const void *p, size_t len){ /* FNV-1a;確定性指紋 */
    const uint8_t *b = (const uint8_t *)p;
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < len; i++){ h ^= b[i]; h *= 16777619u; }
    return h ? h : 1u; /* 指紋恆非 0 */
}
int mrliou_mrl_optimizer_pass(const mrliou_mrl_plan_t *in, mrliou_mrl_plan_t *out){
    if (!in || !out) return MRLIOU_MRL_E_ARG;
    if (in->n < 0 || in->n > MRLIOU_MRL_PLAN_MAX) return MRLIOU_MRL_E_ARG;
    mrliou_mrl_plan_t tmp;                /* 別名安全 */
    memset(&tmp, 0, sizeof tmp);
    uint32_t fp = mrliou_mrl_fold32(in->nodes, sizeof(mrliou_mrl_plan_node_t) * (size_t)in->n);
    int m = 0;
    for (int i = 0; i < in->n; i++){
        const mrliou_mrl_plan_node_t *nd = &in->nodes[i];
        if (nd->required || nd->weight > 0) tmp.nodes[m++] = *nd;   /* 必要節點全保留;僅摺疊冗餘 */
    }
    tmp.n = m;
    tmp.provenance_fp = in->provenance_fp ? in->provenance_fp : fp; /* 保留原始 provenance */
    *out = tmp;
    return MRLIOU_MRL_E_OK;
}
