#include <math.h>
#include "mrliou_mrl/mrliou_mrl_weight_system.h"
int mrliou_mrl_weight_system_validate(const double d[10]){
    if (!d) return -1;
    double s = 0.0;
    for (int i = 0; i < 10; i++) s += d[i];
    return (fabs(s - 10.0) < 1e-9) ? 0 : -1; /* Σ(D_i)=10.0 */
}
