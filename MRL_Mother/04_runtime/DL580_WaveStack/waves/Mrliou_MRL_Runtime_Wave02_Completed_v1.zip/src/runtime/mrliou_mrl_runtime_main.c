#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_runtime.h"
#include "mrliou_mrl/mrliou_mrl_runtime_core_assembly.h"
#include "mrliou_mrl/mrliou_mrl_memory_runtime_assembly.h"
int main(void){
    mrliou_mrl_assembly_report_t rep;
    if (mrliou_mrl_runtime_core_assembly_boot(&rep) != 0){
        fprintf(stderr, "[Mrliou_MRL_Runtime] core assembly boot FAILED\n");
        return 1;
    }
    printf("[Mrliou_MRL_Runtime] wave01_status: %s\n", rep.wave01_status);
    mrliou_mrl_memory_assembly_report_t mrep;
    if (mrliou_mrl_memory_runtime_assembly_boot(&mrep) != 0){
        fprintf(stderr, "[Mrliou_MRL_Runtime] memory assembly boot FAILED\n");
        return 1;
    }
    printf("[Mrliou_MRL_Runtime] memory_status: %s\n", mrep.memory_status);
    printf("[Mrliou_MRL_Runtime] remaining_wave03_hooks: %s\n", mrep.remaining_wave03_hooks);
    mrliou_mrl_runtime_t rt;
    mrliou_mrl_runtime_init(&rt);
    mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_RUN);
    mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_SUSPEND);
    mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_RUN);
    mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_HALT);
    printf("[Mrliou_MRL_Runtime] %s boot OK (wave02_closed; runtime_not_complete=true; origin=MrLiouWord)\n",
           MRLIOU_MRL_WAVE02_VERSION);
    return 0;
}
