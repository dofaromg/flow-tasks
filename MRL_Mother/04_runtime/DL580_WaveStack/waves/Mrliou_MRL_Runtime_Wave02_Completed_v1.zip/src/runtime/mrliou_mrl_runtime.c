#include "mrliou_mrl/mrliou_mrl_runtime.h"
int mrliou_mrl_runtime_init(mrliou_mrl_runtime_t *rt){
    if (!rt) return -1;
    rt->state = MRLIOU_MRL_RT_INIT;
    return 0;
}
int mrliou_mrl_runtime_transition(mrliou_mrl_runtime_t *rt, mrliou_mrl_rt_state_t target){
    if (!rt) return -1;
    int legal = 0;
    switch (rt->state){
        case MRLIOU_MRL_RT_INIT:    legal = (target == MRLIOU_MRL_RT_RUN); break;
        case MRLIOU_MRL_RT_RUN:     legal = (target == MRLIOU_MRL_RT_SUSPEND || target == MRLIOU_MRL_RT_HALT); break;
        case MRLIOU_MRL_RT_SUSPEND: legal = (target == MRLIOU_MRL_RT_RUN || target == MRLIOU_MRL_RT_HALT); break;
        case MRLIOU_MRL_RT_HALT:    legal = 0; break;
    }
    if (!legal) return -1;
    rt->state = target;
    return 0;
}
