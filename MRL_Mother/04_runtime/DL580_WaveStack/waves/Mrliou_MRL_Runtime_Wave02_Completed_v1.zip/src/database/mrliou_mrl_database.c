#include <string.h>
#include "mrliou_mrl/mrliou_mrl_database.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
typedef struct {
    int used;
    char key[MRLIOU_MRL_DB_KEY_MAX];
    uint64_t len;
    uint8_t val[MRLIOU_MRL_DB_VAL_MAX];
} mrliou_mrl_db_slot_t;
static mrliou_mrl_db_slot_t g_db[MRLIOU_MRL_DB_SLOTS]; /* process-local;no external DB */
static int g_db_init = 0;
static void db_ensure(void){ if (!g_db_init){ memset(g_db, 0, sizeof g_db); g_db_init = 1; } }
static int db_check_key(const char *key){
    if (!key || key[0] == '\0') return -1;
    if (strlen(key) >= MRLIOU_MRL_DB_KEY_MAX) return -1;
    return 0;
}
static mrliou_mrl_db_slot_t *db_find(const char *key){
    for (int i = 0; i < MRLIOU_MRL_DB_SLOTS; i++)
        if (g_db[i].used && strcmp(g_db[i].key, key) == 0) return &g_db[i];
    return 0;
}
int mrliou_mrl_database_init(void){
    memset(g_db, 0, sizeof g_db);
    g_db_init = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_database_put(const char *key, const void *val, uint64_t n){
    if (db_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (!val || n == 0 || n > MRLIOU_MRL_DB_VAL_MAX) return MRLIOU_MRL_E_ARG;
    db_ensure();
    mrliou_mrl_db_slot_t *s = db_find(key);
    if (!s){
        for (int i = 0; i < MRLIOU_MRL_DB_SLOTS; i++) if (!g_db[i].used){ s = &g_db[i]; break; }
        if (!s) return MRLIOU_MRL_E_ARG;
        memset(s, 0, sizeof *s);
        size_t kl = strlen(key);
        memcpy(s->key, key, kl); s->key[kl] = '\0';
        s->used = 1;
    }
    memcpy(s->val, val, (size_t)n);
    s->len = n;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_database_get(const char *key, void *buf, uint64_t cap, uint64_t *out_n){
    if (db_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (!buf || !out_n) return MRLIOU_MRL_E_ARG;
    db_ensure();
    mrliou_mrl_db_slot_t *s = db_find(key);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;
    if (cap < s->len) return MRLIOU_MRL_E_ARG;
    memcpy(buf, s->val, (size_t)s->len);
    *out_n = s->len;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_database_delete(const char *key){
    if (db_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    db_ensure();
    mrliou_mrl_db_slot_t *s = db_find(key);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;
    memset(s, 0, sizeof *s);
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_database_iterate(mrliou_mrl_database_iter_fn cb, void *ud){
    if (!cb) return MRLIOU_MRL_E_ARG;
    db_ensure();
    int idx[MRLIOU_MRL_DB_SLOTS], cnt = 0;
    for (int i = 0; i < MRLIOU_MRL_DB_SLOTS; i++) if (g_db[i].used) idx[cnt++] = i;
    for (int a = 1; a < cnt; a++){                                       /* 插入排序:key 升冪 = 確定性 */
        int v = idx[a], b = a - 1;
        while (b >= 0 && strcmp(g_db[idx[b]].key, g_db[v].key) > 0){ idx[b + 1] = idx[b]; b--; }
        idx[b + 1] = v;
    }
    int visited = 0;
    for (int i = 0; i < cnt; i++){
        mrliou_mrl_db_slot_t *s = &g_db[idx[i]];
        visited++;
        if (cb(s->key, s->val, s->len, ud) != 0) break;                  /* 提前停止 */
    }
    return visited;
}
int mrliou_mrl_database_reset(void){
    memset(g_db, 0, sizeof g_db);
    g_db_init = 1;
    return MRLIOU_MRL_E_OK;
}
