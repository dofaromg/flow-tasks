#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memorylayer.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
typedef struct {
    int used;
    char key[MRLIOU_MRL_MEML_KEY_MAX];
    uint64_t len;
    uint8_t val[MRLIOU_MRL_MEML_VAL_MAX];
} mrliou_mrl_meml_slot_t;
static mrliou_mrl_meml_slot_t g_meml[MRLIOU_MRL_MEML_SLOTS]; /* process-local */
static int g_meml_init = 0;
static void meml_ensure(void){ if (!g_meml_init){ memset(g_meml, 0, sizeof g_meml); g_meml_init = 1; } }
static int meml_check_key(const char *key){
    if (!key || key[0] == '\0') return -1;                       /* 空 key = error */
    if (strlen(key) >= MRLIOU_MRL_MEML_KEY_MAX) return -1;       /* name size check */
    return 0;
}
static mrliou_mrl_meml_slot_t *meml_find(const char *key){
    for (int i = 0; i < MRLIOU_MRL_MEML_SLOTS; i++)
        if (g_meml[i].used && strcmp(g_meml[i].key, key) == 0) return &g_meml[i];
    return 0;
}
int mrliou_mrl_memorylayer_init(void){
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    memset(g_meml, 0, sizeof g_meml);
    g_meml_init = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memorylayer_write(const char *key, const void *buf, uint64_t n){
    if (!buf) return MRLIOU_MRL_E_ARG;
    if (meml_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (n == 0 || n > MRLIOU_MRL_MEML_VAL_MAX) return MRLIOU_MRL_E_ARG;  /* size/capacity check */
    meml_ensure();
    mrliou_mrl_meml_slot_t *s = meml_find(key);
    if (!s){
        for (int i = 0; i < MRLIOU_MRL_MEML_SLOTS; i++) if (!g_meml[i].used){ s = &g_meml[i]; break; }
        if (!s) return MRLIOU_MRL_E_ARG;                                 /* 容量滿 */
        memset(s, 0, sizeof *s);
        size_t kl = strlen(key);
        memcpy(s->key, key, kl); s->key[kl] = '\0';
        s->used = 1;
    }
    memcpy(s->val, buf, (size_t)n);
    s->len = n;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memorylayer_read(const char *key, void *buf, uint64_t cap, uint64_t *out_n){
    if (!buf || !out_n) return MRLIOU_MRL_E_ARG;
    if (meml_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    meml_ensure();
    mrliou_mrl_meml_slot_t *s = meml_find(key);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;                               /* missing = not_found */
    if (cap < s->len) return MRLIOU_MRL_E_ARG;
    memcpy(buf, s->val, (size_t)s->len);
    *out_n = s->len;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memorylayer_delete(const char *key){
    if (meml_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    meml_ensure();
    mrliou_mrl_meml_slot_t *s = meml_find(key);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;
    memset(s, 0, sizeof *s);
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memorylayer_exists(const char *key){
    if (meml_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    meml_ensure();
    return meml_find(key) ? 1 : 0;
}
int mrliou_mrl_memorylayer_reset(void){
    memset(g_meml, 0, sizeof g_meml);
    g_meml_init = 1;
    return MRLIOU_MRL_E_OK;
}
