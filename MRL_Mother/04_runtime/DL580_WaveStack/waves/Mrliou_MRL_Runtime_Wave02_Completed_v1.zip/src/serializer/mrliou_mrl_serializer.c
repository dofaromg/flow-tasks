#include <string.h>
#include "mrliou_mrl/mrliou_mrl_serializer.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_compiler.h"  /* mrliou_mrl_crc32 */
static void ser_put_u32(uint8_t *p, uint32_t v){ for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static uint32_t ser_get_u32(const uint8_t *p){ uint32_t v = 0; for (int i = 0; i < 4; i++) v |= ((uint32_t)p[i]) << (8 * i); return v; }
static void ser_put_u64(uint8_t *p, uint64_t v){ for (int i = 0; i < 8; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static uint64_t ser_get_u64(const uint8_t *p){ uint64_t v = 0; for (int i = 0; i < 8; i++) v |= ((uint64_t)p[i]) << (8 * i); return v; }
static int ser_frame_emit(uint32_t type, const uint8_t *body, uint64_t blen, uint8_t *out, uint64_t cap, uint64_t *out_n){
    uint64_t total = 4 + 4 + 8 + blen + 4;
    if (!out || !out_n || cap < total) return MRLIOU_MRL_E_ARG;          /* size check */
    ser_put_u32(out, MRLIOU_MRL_SER_MAGIC);
    ser_put_u32(out + 4, type);
    ser_put_u64(out + 8, blen);
    memcpy(out + 16, body, (size_t)blen);
    ser_put_u32(out + 16 + blen, mrliou_mrl_crc32(body, (size_t)blen));
    *out_n = total;
    return MRLIOU_MRL_E_OK;
}
static int ser_frame_open(uint32_t type, const uint8_t *in, uint64_t n, const uint8_t **body, uint64_t *blen){
    if (!in || n < 20) return MRLIOU_MRL_E_ARG;
    if (ser_get_u32(in) != MRLIOU_MRL_SER_MAGIC) return MRLIOU_MRL_E_ARG;
    if (ser_get_u32(in + 4) != type) return MRLIOU_MRL_E_ARG;
    uint64_t bl = ser_get_u64(in + 8);
    if (n != 16 + bl + 4) return MRLIOU_MRL_E_ARG;                       /* invalid payload */
    if (mrliou_mrl_crc32(in + 16, (size_t)bl) != ser_get_u32(in + 16 + bl)) return MRLIOU_MRL_E_ARG;
    *body = in + 16;
    *blen = bl;
    return MRLIOU_MRL_E_OK;
}
/* ---- atom ---- */
int mrliou_mrl_serializer_atom(const mrliou_mrl_atom_t *a, uint8_t *out, uint64_t cap, uint64_t *out_n){
    if (!a) return MRLIOU_MRL_E_ARG;
    return ser_frame_emit(MRLIOU_MRL_SER_T_ATOM, (const uint8_t *)a, sizeof *a, out, cap, out_n);
}
int mrliou_mrl_deserializer_atom(const uint8_t *in, uint64_t n, mrliou_mrl_atom_t *out){
    const uint8_t *b; uint64_t bl;
    if (!out) return MRLIOU_MRL_E_ARG;
    int rc = ser_frame_open(MRLIOU_MRL_SER_T_ATOM, in, n, &b, &bl);
    if (rc != MRLIOU_MRL_E_OK) return rc;
    if (bl != sizeof *out) return MRLIOU_MRL_E_ARG;
    if (ser_get_u32(b) != 0x304C524Du) return MRLIOU_MRL_E_ARG;          /* atom magic */
    memcpy(out, b, sizeof *out);
    return MRLIOU_MRL_E_OK;
}
/* ---- memory_record: body = u32 key_len + key + u64 val_len + val ---- */
int mrliou_mrl_serializer_memory_record(const mrliou_mrl_memory_record_t *r, uint8_t *out, uint64_t cap, uint64_t *out_n){
    if (!r) return MRLIOU_MRL_E_ARG;
    const void *z = memchr(r->key, 0, sizeof r->key);
    if (!z) return MRLIOU_MRL_E_ARG;
    size_t klen = (size_t)((const char *)z - r->key);
    if (klen == 0) return MRLIOU_MRL_E_ARG;
    if (r->len == 0 || r->len > sizeof r->val) return MRLIOU_MRL_E_ARG;
    uint8_t body[4 + 48 + 8 + 256];
    ser_put_u32(body, (uint32_t)klen);
    memcpy(body + 4, r->key, klen);
    ser_put_u64(body + 4 + klen, r->len);
    memcpy(body + 12 + klen, r->val, (size_t)r->len);
    return ser_frame_emit(MRLIOU_MRL_SER_T_MEMREC, body, 4 + klen + 8 + r->len, out, cap, out_n);
}
int mrliou_mrl_deserializer_memory_record(const uint8_t *in, uint64_t n, mrliou_mrl_memory_record_t *out){
    const uint8_t *b; uint64_t bl;
    if (!out) return MRLIOU_MRL_E_ARG;
    int rc = ser_frame_open(MRLIOU_MRL_SER_T_MEMREC, in, n, &b, &bl);
    if (rc != MRLIOU_MRL_E_OK) return rc;
    if (bl < 13) return MRLIOU_MRL_E_ARG;
    uint32_t klen = ser_get_u32(b);
    if (klen == 0 || klen >= 48 || bl < (uint64_t)4 + klen + 8) return MRLIOU_MRL_E_ARG;
    uint64_t vlen = ser_get_u64(b + 4 + klen);
    if (vlen == 0 || vlen > 256 || bl != (uint64_t)4 + klen + 8 + vlen) return MRLIOU_MRL_E_ARG;
    memset(out, 0, sizeof *out);
    memcpy(out->key, b + 4, klen);
    out->len = vlen;
    memcpy(out->val, b + 12 + klen, (size_t)vlen);
    return MRLIOU_MRL_E_OK;
}
/* ---- cube_object: body = u32 cube_id + u32 x + u32 y + u32 z + u64 len + payload ---- */
int mrliou_mrl_serializer_cube_object(const mrliou_mrl_cube_object_t *o, uint8_t *out, uint64_t cap, uint64_t *out_n){
    if (!o) return MRLIOU_MRL_E_ARG;
    if (o->len == 0 || o->len > sizeof o->payload) return MRLIOU_MRL_E_ARG;
    uint8_t body[4 + 4 + 4 + 4 + 8 + 64];
    ser_put_u32(body, o->cube_id);
    ser_put_u32(body + 4, o->coord.x);
    ser_put_u32(body + 8, o->coord.y);
    ser_put_u32(body + 12, o->coord.z);
    ser_put_u64(body + 16, o->len);
    memcpy(body + 24, o->payload, (size_t)o->len);
    return ser_frame_emit(MRLIOU_MRL_SER_T_CUBEOBJ, body, 24 + o->len, out, cap, out_n);
}
int mrliou_mrl_deserializer_cube_object(const uint8_t *in, uint64_t n, mrliou_mrl_cube_object_t *out){
    const uint8_t *b; uint64_t bl;
    if (!out) return MRLIOU_MRL_E_ARG;
    int rc = ser_frame_open(MRLIOU_MRL_SER_T_CUBEOBJ, in, n, &b, &bl);
    if (rc != MRLIOU_MRL_E_OK) return rc;
    if (bl < 25) return MRLIOU_MRL_E_ARG;
    uint64_t plen = ser_get_u64(b + 16);
    if (plen == 0 || plen > 64 || bl != 24 + plen) return MRLIOU_MRL_E_ARG;
    memset(out, 0, sizeof *out);
    out->cube_id = ser_get_u32(b);
    out->coord.x = ser_get_u32(b + 4);
    out->coord.y = ser_get_u32(b + 8);
    out->coord.z = ser_get_u32(b + 12);
    out->len = plen;
    memcpy(out->payload, b + 24, (size_t)plen);
    return MRLIOU_MRL_E_OK;
}
