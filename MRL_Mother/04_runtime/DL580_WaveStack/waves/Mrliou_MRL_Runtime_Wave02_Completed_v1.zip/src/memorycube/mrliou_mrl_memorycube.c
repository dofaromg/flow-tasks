#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memorycube.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
typedef struct { int used; uint64_t len; uint8_t payload[MRLIOU_MRL_CUBE_PAYLOAD_MAX]; } mrliou_mrl_cube_cell_t;
typedef struct { int used; mrliou_mrl_cube_cell_t cell[MRLIOU_MRL_CUBE_CELLS]; } mrliou_mrl_cube_t;
static mrliou_mrl_cube_t g_cube[MRLIOU_MRL_CUBE_MAX];
static int g_cube_init = 0;
static void cube_ensure(void){ if (!g_cube_init){ memset(g_cube, 0, sizeof g_cube); g_cube_init = 1; } }
static int cube_coord_check(const mrliou_mrl_cube_coord_t *c){
    if (!c) return -1;
    if (c->x >= MRLIOU_MRL_CUBE_AXIS || c->y >= MRLIOU_MRL_CUBE_AXIS || c->z >= MRLIOU_MRL_CUBE_AXIS) return -1;
    return 0;
}
static int cube_idx(const mrliou_mrl_cube_coord_t *c){
    return (int)(c->x * MRLIOU_MRL_CUBE_AXIS * MRLIOU_MRL_CUBE_AXIS + c->y * MRLIOU_MRL_CUBE_AXIS + c->z);
}
int mrliou_mrl_memorycube_init(void){
    memset(g_cube, 0, sizeof g_cube);
    g_cube_init = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memorycube_store(uint32_t cube_id, const mrliou_mrl_cube_coord_t *c, const void *payload, uint64_t n){
    if (cube_id >= MRLIOU_MRL_CUBE_MAX) return MRLIOU_MRL_E_ARG;
    if (cube_coord_check(c) != 0) return MRLIOU_MRL_E_ARG;              /* coordinate boundary */
    if (!payload || n == 0 || n > MRLIOU_MRL_CUBE_PAYLOAD_MAX) return MRLIOU_MRL_E_ARG;
    cube_ensure();
    mrliou_mrl_cube_cell_t *cell = &g_cube[cube_id].cell[cube_idx(c)];
    memset(cell, 0, sizeof *cell);
    memcpy(cell->payload, payload, (size_t)n);
    cell->len = n;
    cell->used = 1;
    g_cube[cube_id].used = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memorycube_fetch(uint32_t cube_id, const mrliou_mrl_cube_coord_t *c, void *buf, uint64_t cap, uint64_t *out_n){
    if (cube_id >= MRLIOU_MRL_CUBE_MAX) return MRLIOU_MRL_E_ARG;
    if (cube_coord_check(c) != 0) return MRLIOU_MRL_E_ARG;
    if (!buf || !out_n) return MRLIOU_MRL_E_ARG;
    cube_ensure();
    if (!g_cube[cube_id].used) return MRLIOU_MRL_E_NOT_FOUND;           /* missing cube */
    mrliou_mrl_cube_cell_t *cell = &g_cube[cube_id].cell[cube_idx(c)];
    if (!cell->used) return MRLIOU_MRL_E_NOT_FOUND;                     /* missing cell */
    if (cap < cell->len) return MRLIOU_MRL_E_ARG;
    memcpy(buf, cell->payload, (size_t)cell->len);
    *out_n = cell->len;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memorycube_trace(uint32_t cube_id, uint32_t *out_trace, int trace_cap, int *out_len){
    if (cube_id >= MRLIOU_MRL_CUBE_MAX) return MRLIOU_MRL_E_ARG;
    if (!out_trace || !out_len || trace_cap < 1) return MRLIOU_MRL_E_ARG;
    cube_ensure();
    if (!g_cube[cube_id].used) return MRLIOU_MRL_E_NOT_FOUND;
    int cnt = 0;
    for (int i = 0; i < MRLIOU_MRL_CUBE_CELLS; i++){                    /* 升冪 = deterministic trace */
        if (!g_cube[cube_id].cell[i].used) continue;
        if (cnt >= trace_cap) return MRLIOU_MRL_E_ARG;
        out_trace[cnt++] = ((uint32_t)i << 8) | (uint32_t)(g_cube[cube_id].cell[i].len & 0xFFu);
    }
    *out_len = cnt;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_memorycube_reset(void){
    memset(g_cube, 0, sizeof g_cube);
    g_cube_init = 1;
    return MRLIOU_MRL_E_OK;
}
