#include <string.h>
#include "mrliou_mrl/mrliou_mrl_compiler.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int (*mrliou_mrl_ed25519_sign_hook)(const uint8_t *msg, size_t len, uint8_t out_sig[64]) = 0;
uint32_t mrliou_mrl_crc32(const void *data, size_t len){
    const uint8_t *p = (const uint8_t *)data;
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < len; i++){
        crc ^= p[i];
        for (int b = 0; b < 8; b++) crc = (crc >> 1) ^ ((crc & 1u) ? 0xEDB88320u : 0u);
    }
    return ~crc;
}
int mrliou_mrl_compiler_compile(const char *law1_src, mrliou_mrl_atom_t *out, size_t max_atoms, size_t *n_atoms){
    if (!law1_src || !out || !n_atoms) return MRLIOU_MRL_E_LAW;
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    size_t len = strlen(law1_src);
    size_t need = (len + 15) / 16; if (need == 0) need = 1;
    if (need > max_atoms) return MRLIOU_MRL_E_LAW;
    for (size_t i = 0; i < need; i++){
        uint8_t chunk[16] = {0};
        size_t off = i * 16;
        if (off < len){ size_t take = (len - off) > 16 ? 16 : (len - off); memcpy(chunk, law1_src + off, take); }
        mrliou_mrl_atom_t *a = &out[i];
        a->magic = 0x304C524Du; a->type_id = 1; a->particle_id = (uint64_t)i;
        memcpy(&a->payload_lo, chunk, 8); memcpy(&a->payload_hi, chunk + 8, 8);
        a->eta_q16 = 65536u; a->sig_crc = mrliou_mrl_crc32(chunk, 16);
    }
    *n_atoms = need;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_compiler_decompile(const mrliou_mrl_atom_t *atoms, size_t n_atoms, char *out, size_t out_cap){
    if (!atoms || !out || out_cap < n_atoms * 16 + 1) return MRLIOU_MRL_E_LAW;
    for (size_t i = 0; i < n_atoms; i++){
        if (atoms[i].magic != 0x304C524Du) return MRLIOU_MRL_E_LAW;
        uint8_t chunk[16];
        memcpy(chunk, &atoms[i].payload_lo, 8); memcpy(chunk + 8, &atoms[i].payload_hi, 8);
        if (mrliou_mrl_crc32(chunk, 16) != atoms[i].sig_crc) return MRLIOU_MRL_E_LAW; /* LAW-2 對照 */
        memcpy(out + i * 16, chunk, 16);
    }
    out[n_atoms * 16] = '\0';
    return MRLIOU_MRL_E_OK;
}
