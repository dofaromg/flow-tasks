#include "mrliou_mrl/mrliou_mrl_engine.h"
static uint64_t g_engine_delta = 0; /* LAW-3 */
double mrliou_mrl_engine_evolve(double P_k, double N_k, double eta_k){
    g_engine_delta++;
    return N_k * P_k * eta_k; /* P_{k+1} = N_k * P_k * eta_k */
}
uint64_t mrliou_mrl_engine_delta_count(void){ return g_engine_delta; }
