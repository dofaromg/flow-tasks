#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memory_runtime_assembly.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_memorylayer.h"
#include "mrliou_mrl/mrliou_mrl_memoryos.h"
#include "mrliou_mrl/mrliou_mrl_memorycube.h"
#include "mrliou_mrl/mrliou_mrl_memoryvault.h"
#include "mrliou_mrl/mrliou_mrl_database.h"
#include "mrliou_mrl/mrliou_mrl_serializer.h"
#include "mrliou_mrl/mrliou_mrl_search.h"
#include "mrliou_mrl/mrliou_mrl_compiler.h"

static const char *k_w2_nodes[MRLIOU_MRL_MEM_ASM_STAGES] = {
    "Mrliou_MRL_MemoryLayer", "Mrliou_MRL_MemoryOS", "Mrliou_MRL_MemoryCube", "Mrliou_MRL_MemoryVault",
    "Mrliou_MRL_Database", "Mrliou_MRL_Serializer", "Mrliou_MRL_Search", "Mrliou_MRL_Memory_Runtime_Assembly"
};
static void mem_mark(mrliou_mrl_memory_assembly_report_t *r, int idx, const char *line){
    printf("[memory_assembly] %s\n", line);
    if (r && idx >= 0 && idx < MRLIOU_MRL_MEM_ASM_STAGES){
        snprintf(r->memory_trace[idx], sizeof r->memory_trace[idx], "%s", line);
        r->trace_len = idx + 1;
    }
}
static int count_cb(const char *key, const void *val, uint64_t n, void *ud){
    (void)key; (void)val; (void)n;
    (*(int *)ud)++;
    return 0;
}
int mrliou_mrl_memory_runtime_assembly_boot(mrliou_mrl_memory_assembly_report_t *out){
    if (out) memset(out, 0, sizeof *out);
    /* --- LAW 前置門(skeleton-level;Guardian=Wave_03 接管) --- */
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return -1;
    for (int i = 0; i < MRLIOU_MRL_MEM_ASM_STAGES; i++)
        if (mrliou_mrl_law_check_module_name(k_w2_nodes[i]) != 0) return -1;
    if (mrliou_mrl_law_check_module_name("External_MemoryLayer") == 0) return -1;  /* 反向自檢 */
    if (mrliou_mrl_law_check_runtime_flag(1) != 0) return -1;
    printf("[memory_assembly] LAW gate: origin+naming+flag verified (Guardian=Wave_03 hook)\n");

    /* 0 MemoryLayer */
    uint8_t w[3] = {1, 2, 3}, rb[600]; uint64_t rn = 0;
    if (mrliou_mrl_memorylayer_init() != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_memorylayer_write("asm_w2", w, 3) != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_memorylayer_read("asm_w2", rb, sizeof rb, &rn) != MRLIOU_MRL_E_OK || rn != 3 || memcmp(w, rb, 3) != 0) return -2;
    if (mrliou_mrl_memorylayer_exists("asm_w2") != 1) return -2;
    if (mrliou_mrl_memorylayer_delete("asm_w2") != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_memorylayer_exists("asm_w2") != 0) return -2;
    mem_mark(out, 0, "0 Mrliou_MRL_MemoryLayer: kv roundtrip OK");

    /* 1 MemoryOS */
    uint32_t ns1 = 0, ns2 = 0;
    if (mrliou_mrl_memoryos_init() != MRLIOU_MRL_E_OK) return -3;
    if (mrliou_mrl_memoryos_namespace_create("mrl_core", &ns1) != MRLIOU_MRL_E_OK) return -3;
    if (mrliou_mrl_memoryos_namespace_lookup("mrl_core", &ns2) != MRLIOU_MRL_E_OK || ns1 != ns2) return -3;
    if (mrliou_mrl_memoryos_namespace_create("mrl_core", 0) != MRLIOU_MRL_E_DUP) return -3;
    mem_mark(out, 1, "1 Mrliou_MRL_MemoryOS: namespace OK");

    /* 2 MemoryCube */
    mrliou_mrl_cube_coord_t cc = {1, 2, 3};
    uint8_t pay[5] = {9, 8, 7, 6, 5}; uint32_t tr[8]; int tl = 0;
    if (mrliou_mrl_memorycube_init() != MRLIOU_MRL_E_OK) return -4;
    if (mrliou_mrl_memorycube_store(1, &cc, pay, 5) != MRLIOU_MRL_E_OK) return -4;
    if (mrliou_mrl_memorycube_fetch(1, &cc, rb, sizeof rb, &rn) != MRLIOU_MRL_E_OK || rn != 5 || memcmp(pay, rb, 5) != 0) return -4;
    if (mrliou_mrl_memorycube_trace(1, tr, 8, &tl) != MRLIOU_MRL_E_OK || tl != 1) return -4;
    mem_mark(out, 2, "2 Mrliou_MRL_MemoryCube: store/fetch/trace OK");

    /* 3 MemoryVault */
    uint32_t aid = 0; char man[512];
    if (mrliou_mrl_memoryvault_init() != MRLIOU_MRL_E_OK) return -5;
    if (mrliou_mrl_memoryvault_archive("asm_tag", w, 3, &aid) != MRLIOU_MRL_E_OK || aid != 1) return -5;
    if (mrliou_mrl_memoryvault_restore(aid, rb, sizeof rb, &rn) != MRLIOU_MRL_E_OK || rn != 3 || memcmp(w, rb, 3) != 0) return -5;
    if (mrliou_mrl_memoryvault_manifest(man, sizeof man) != MRLIOU_MRL_E_OK) return -5;
    if (!strstr(man, "asm_tag") || !strstr(man, "MrLiouWord")) return -5;
    mem_mark(out, 3, "3 Mrliou_MRL_MemoryVault: archive/restore OK");

    /* 4 Database */
    int dbcount = 0;
    if (mrliou_mrl_database_init() != MRLIOU_MRL_E_OK) return -6;
    if (mrliou_mrl_database_put("mrl_core:alpha", w, 1) != MRLIOU_MRL_E_OK) return -6;
    if (mrliou_mrl_database_put("mrl_core:beta", w, 2) != MRLIOU_MRL_E_OK) return -6;
    if (mrliou_mrl_database_put("zeta", w, 3) != MRLIOU_MRL_E_OK) return -6;
    if (mrliou_mrl_database_get("zeta", rb, sizeof rb, &rn) != MRLIOU_MRL_E_OK || rn != 3) return -6;
    if (mrliou_mrl_database_iterate(count_cb, &dbcount) != 3 || dbcount != 3) return -6;
    mem_mark(out, 4, "4 Mrliou_MRL_Database: put/get/iterate OK");

    /* 5 Serializer */
    mrliou_mrl_atom_t atoms[4], a2; size_t na = 0;
    uint8_t sbuf[512]; uint64_t sn = 0;
    if (mrliou_mrl_compiler_compile("LAW-1: w2", atoms, 4, &na) != MRLIOU_MRL_E_OK || na < 1) return -7;
    if (mrliou_mrl_serializer_atom(&atoms[0], sbuf, sizeof sbuf, &sn) != MRLIOU_MRL_E_OK || sn != 60) return -7;
    if (mrliou_mrl_deserializer_atom(sbuf, sn, &a2) != MRLIOU_MRL_E_OK || memcmp(&atoms[0], &a2, sizeof a2) != 0) return -7;
    mrliou_mrl_memory_record_t mr1, mr2;
    memset(&mr1, 0, sizeof mr1);
    memcpy(mr1.key, "asm_rec", 7);
    mr1.len = 3; mr1.val[0] = 4; mr1.val[1] = 5; mr1.val[2] = 6;
    if (mrliou_mrl_serializer_memory_record(&mr1, sbuf, sizeof sbuf, &sn) != MRLIOU_MRL_E_OK) return -7;
    if (mrliou_mrl_deserializer_memory_record(sbuf, sn, &mr2) != MRLIOU_MRL_E_OK) return -7;
    if (strcmp(mr1.key, mr2.key) != 0 || mr1.len != mr2.len || memcmp(mr1.val, mr2.val, 3) != 0) return -7;
    mem_mark(out, 5, "5 Mrliou_MRL_Serializer: roundtrip OK");

    /* 6 Search */
    mrliou_mrl_search_result_t sr;
    if (mrliou_mrl_search_reset() != MRLIOU_MRL_E_OK) return -8;
    if (mrliou_mrl_search_exact("zeta", &sr) != MRLIOU_MRL_E_OK || sr.count != 1) return -8;
    if (mrliou_mrl_search_prefix("mrl_core:", &sr) != MRLIOU_MRL_E_OK || sr.count != 2) return -8;
    if (mrliou_mrl_search_namespace("mrl_core", &sr) != MRLIOU_MRL_E_OK || sr.count != 2) return -8;
    if (strcmp(sr.keys[0], "mrl_core:alpha") != 0) return -8;
    mem_mark(out, 6, "6 Mrliou_MRL_Search: exact/prefix/ns OK");

    /* 7 Assembly seal */
    mem_mark(out, 7, "7 Mrliou_MRL_Memory_Runtime_Assembly: SEAL OK");
    if (out){
        out->memory_status = "wave02_closed(memory_foundation_completed;runtime_not_complete=true)";
        out->remaining_wave03_hooks =
            "Guardian,Validator,Guardian_Runtime_Assembly(W3);collapse_search(P1);ed25519_sign_hook(deploy-side)";
    }
    return 0;
}
