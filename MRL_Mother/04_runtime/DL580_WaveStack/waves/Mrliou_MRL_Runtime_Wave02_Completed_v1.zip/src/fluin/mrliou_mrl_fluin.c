#include <string.h>
#include "mrliou_mrl/mrliou_mrl_fluin.h"
void mrliou_mrl_fluin_bind(const mrliou_mrl_fluin_vec_t *role, const mrliou_mrl_fluin_vec_t *filler, mrliou_mrl_fluin_vec_t *bound){
    for (int i = 0; i < MRLIOU_MRL_FLUIN_DIM; i++) bound->v[i] = (uint8_t)(role->v[i] ^ filler->v[i]);
}
void mrliou_mrl_fluin_unbind(const mrliou_mrl_fluin_vec_t *bound, const mrliou_mrl_fluin_vec_t *role, mrliou_mrl_fluin_vec_t *filler){
    for (int i = 0; i < MRLIOU_MRL_FLUIN_DIM; i++) filler->v[i] = (uint8_t)(bound->v[i] ^ role->v[i]);
}
int mrliou_mrl_fluin_equal(const mrliou_mrl_fluin_vec_t *a, const mrliou_mrl_fluin_vec_t *b){
    return memcmp(a->v, b->v, MRLIOU_MRL_FLUIN_DIM) == 0;
}
