#include <string.h>
#include "mrliou_mrl/mrliou_mrl_search.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_database.h"
#include "mrliou_mrl/mrliou_mrl_memoryos.h"
static uint64_t g_search_count = 0; /* process-local 查詢統計 */
typedef struct {
    const char *needle;
    size_t needle_len;
    int prefix_mode;
    mrliou_mrl_search_result_t *res;
    int overflow;
} mrliou_mrl_search_ctx_t;
static int search_cb(const char *key, const void *val, uint64_t n, void *ud){
    (void)val; (void)n;
    mrliou_mrl_search_ctx_t *c = (mrliou_mrl_search_ctx_t *)ud;
    int hit = c->prefix_mode ? (strncmp(key, c->needle, c->needle_len) == 0)
                             : (strcmp(key, c->needle) == 0);
    if (!hit) return 0;
    if (c->res->count >= MRLIOU_MRL_SEARCH_MAX){ c->overflow = 1; return 1; }
    size_t kl = strlen(key);
    if (kl > 47) kl = 47;
    memcpy(c->res->keys[c->res->count], key, kl);
    c->res->keys[c->res->count][kl] = '\0';
    c->res->count++;
    return c->prefix_mode ? 0 : 1;   /* exact: 命中即停 */
}
static int search_run(const char *needle, int prefix_mode, mrliou_mrl_search_result_t *out){
    if (!needle || needle[0] == '\0' || !out) return MRLIOU_MRL_E_ARG;
    memset(out, 0, sizeof *out);
    g_search_count++;
    mrliou_mrl_search_ctx_t ctx = { needle, strlen(needle), prefix_mode, out, 0 };
    int visited = mrliou_mrl_database_iterate(search_cb, &ctx);
    if (visited < 0) return visited;
    if (ctx.overflow) return MRLIOU_MRL_E_ARG;
    return (out->count > 0) ? MRLIOU_MRL_E_OK : MRLIOU_MRL_E_NOT_FOUND;
}
int mrliou_mrl_search_exact(const char *key, mrliou_mrl_search_result_t *out){
    return search_run(key, 0, out);
}
int mrliou_mrl_search_prefix(const char *prefix, mrliou_mrl_search_result_t *out){
    return search_run(prefix, 1, out);
}
int mrliou_mrl_search_namespace(const char *ns_name, mrliou_mrl_search_result_t *out){
    if (!ns_name || ns_name[0] == '\0' || !out) return MRLIOU_MRL_E_ARG;
    uint32_t ns_id = 0;
    int rc = mrliou_mrl_memoryos_namespace_lookup(ns_name, &ns_id);
    if (rc != MRLIOU_MRL_E_OK) return rc;                                /* ns 不存在 = not_found */
    char pfx[MRLIOU_MRL_MEMOS_NAME_MAX + 2];
    size_t nl = strlen(ns_name);
    memcpy(pfx, ns_name, nl);
    pfx[nl] = ':';
    pfx[nl + 1] = '\0';
    return search_run(pfx, 1, out);
}
int mrliou_mrl_search_reset(void){
    g_search_count = 0;
    return MRLIOU_MRL_E_OK;
}
uint64_t mrliou_mrl_search_query_count(void){ return g_search_count; }
