#include <string.h>
#include "mrliou_mrl/mrliou_mrl_flowagent.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
static uint32_t mrliou_mrl_mix32(uint32_t x){
    x ^= x >> 16; x *= 0x7feb352dU;
    x ^= x >> 15; x *= 0x846ca68bU;
    x ^= x >> 16; return x;          /* 純函數確定性混淆;非亂數 */
}
int mrliou_mrl_flowagent_decide(const mrliou_mrl_flow_context_t *ctx, mrliou_mrl_flow_decision_t *out){
    if (!ctx || !out) return MRLIOU_MRL_E_ARG;
    memset(out, 0, sizeof *out);
    int lc = 0;
    for (int i = 0; i < 32; i++) if (ctx->legal_mask & (1u << i)) lc++;
    out->legal_count = lc;
    if (lc == 0){ out->decision_code = 1; out->route = -1; out->confidence_q16 = 0; return MRLIOU_MRL_E_OK; }
    uint32_t pick = mrliou_mrl_mix32(ctx->signal) % (uint32_t)lc;
    int route = -1, seen = 0;
    for (int i = 0; i < 32; i++){
        if (ctx->legal_mask & (1u << i)){
            if ((uint32_t)seen == pick){ route = i; break; }
            seen++;
        }
    }
    out->decision_code = 0;
    out->route = route;
    out->confidence_q16 = (lc == 1) ? 65536u : (65536u / (uint32_t)lc); /* 均勻信心(骨架) */
    return MRLIOU_MRL_E_OK;
}
