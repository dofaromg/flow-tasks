#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memoryos.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint32_t id1 = 0, id2 = 0, idx = 0;
    if (mrliou_mrl_memoryos_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memoryos_namespace FAIL init\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_create("alpha", &id1) != MRLIOU_MRL_E_OK || id1 == 0){ printf("GATE mrliou_mrl_memoryos_namespace FAIL create\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_lookup("alpha", &idx) != MRLIOU_MRL_E_OK || idx != id1){ printf("GATE mrliou_mrl_memoryos_namespace FAIL lookup\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_create("alpha", 0) != MRLIOU_MRL_E_DUP){ printf("GATE mrliou_mrl_memoryos_namespace FAIL dup\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_create("beta", &id2) != MRLIOU_MRL_E_OK || id2 == id1){ printf("GATE mrliou_mrl_memoryos_namespace FAIL second\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_delete("beta") != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memoryos_namespace FAIL delete\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_lookup("beta", &idx) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memoryos_namespace FAIL del_lookup\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_lookup("ghost", &idx) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memoryos_namespace FAIL missing\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_delete("ghost") != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memoryos_namespace FAIL del_missing\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_create("", 0) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memoryos_namespace FAIL empty\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_create("abcdefghijklmnopqrstuvwxyz_abcdef", 0) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_memoryos_namespace FAIL size\n"); return 1; }
    if (mrliou_mrl_memoryos_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memoryos_namespace FAIL reset\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_lookup("alpha", &idx) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memoryos_namespace FAIL reset_lookup\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_create("alpha", &idx) != MRLIOU_MRL_E_OK || idx != id1){
        printf("GATE mrliou_mrl_memoryos_namespace FAIL determinism\n"); return 1; }   /* 同名跨 reset 必同 id */
    printf("GATE mrliou_mrl_memoryos_namespace PASS (create/lookup/delete, dup=E_DUP, not_found, size check, deterministic id)\n");
    return 0;
}
