#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_atom.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_weight_system.h"
#include "mrliou_mrl/mrliou_mrl_collapse_engine.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    if (sizeof(mrliou_mrl_atom_t) != 40){ printf("GATE mrliou_mrl_law_struct FAIL atom!=40\n"); return 1; }
    if (mrliou_mrl_law_verify("MrLiouWord") != MRLIOU_MRL_GATE_ALLOW){ printf("GATE mrliou_mrl_law_struct FAIL law allow\n"); return 1; }
    if (mrliou_mrl_law_verify("External_X") != MRLIOU_MRL_GATE_BLOCK){ printf("GATE mrliou_mrl_law_struct FAIL law block\n"); return 1; }
    if (mrliou_mrl_law_check_module_name("Mrliou_MRL_Kernel") != 0){ printf("GATE mrliou_mrl_law_struct FAIL name legal\n"); return 1; }
    if (mrliou_mrl_law_check_module_name("External_MRL_Bridge") == 0){ printf("GATE mrliou_mrl_law_struct FAIL name external\n"); return 1; }
    if (mrliou_mrl_law_check_module_name("Firebase_Adapter") == 0){ printf("GATE mrliou_mrl_law_struct FAIL name sovereignty\n"); return 1; }
    if (mrliou_mrl_law_check_module_name("FlowAgent_Runtime") == 0){ printf("GATE mrliou_mrl_law_struct FAIL name prefix\n"); return 1; }
    if (mrliou_mrl_law_check_module_name("") == 0 || mrliou_mrl_law_check_module_name(NULL) == 0){
        printf("GATE mrliou_mrl_law_struct FAIL name empty\n"); return 1; }
    if (mrliou_mrl_law_check_runtime_flag(1) != 0){ printf("GATE mrliou_mrl_law_struct FAIL flag keep\n"); return 1; }
    if (mrliou_mrl_law_check_runtime_flag(0) == 0){ printf("GATE mrliou_mrl_law_struct FAIL flag tamper\n"); return 1; }
    double ok[10] = {1,1,1,1,1,1,1,1,1,1};
    double bad[10] = {2,1,1,1,1,1,1,1,1,1};
    if (mrliou_mrl_weight_system_validate(ok) != 0){ printf("GATE mrliou_mrl_law_struct FAIL weight ok\n"); return 1; }
    if (mrliou_mrl_weight_system_validate(bad) == 0){ printf("GATE mrliou_mrl_law_struct FAIL weight bad\n"); return 1; }
    if (mrliou_mrl_collapse_search(1) != MRLIOU_MRL_E_P1){ printf("GATE mrliou_mrl_law_struct FAIL P1 honest hook\n"); return 1; }
    printf("GATE mrliou_mrl_law_struct PASS (atom=40B, origin gate, naming law, runtime flag guard, sum=10.0, P1 hook honest)\n");
    return 0;
}
