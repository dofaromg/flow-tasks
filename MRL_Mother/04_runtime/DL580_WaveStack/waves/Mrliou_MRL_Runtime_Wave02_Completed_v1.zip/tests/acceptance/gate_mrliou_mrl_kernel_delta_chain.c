#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_kernel_t k;
    if (mrliou_mrl_kernel_init(&k) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_kernel_delta_chain FAIL init\n"); return 1; }
    mrliou_mrl_fluin_vec_t in = {{0}}; in.v[3] = 7;
    for (int i = 0; i < 5; i++) if (mrliou_mrl_kernel_step(&k, &in) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_kernel_delta_chain FAIL step\n"); return 1; }
    if (k.delta_count != 5){ printf("GATE mrliou_mrl_kernel_delta_chain FAIL delta\n"); return 1; }
    if (strcmp(k.origin_signature, "MrLiouWord") != 0){ printf("GATE mrliou_mrl_kernel_delta_chain FAIL origin\n"); return 1; }
    uint8_t rb[8]; uint64_t rn = 0;
    if (mrliou_mrl_kernel_memio_read(&k, "gate_dc_missing", rb, sizeof rb, &rn) != MRLIOU_MRL_E_NOT_FOUND){
        printf("GATE mrliou_mrl_kernel_delta_chain FAIL memio not_found\n"); return 1; }
    printf("GATE mrliou_mrl_kernel_delta_chain PASS (5 steps, delta=5, origin=MrLiouWord, memio not_found semantics)\n");
    return 0;
}
