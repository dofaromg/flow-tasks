#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memorylayer.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint8_t w[5] = {1,2,3,4,5}, r[MRLIOU_MRL_MEML_VAL_MAX]; uint64_t n = 0;
    if (mrliou_mrl_memorylayer_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL init\n"); return 1; }
    if (mrliou_mrl_memorylayer_write("alpha", w, 5) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL write\n"); return 1; }
    if (mrliou_mrl_memorylayer_read("alpha", r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 5 || memcmp(w, r, 5) != 0){
        printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL roundtrip\n"); return 1; }
    if (mrliou_mrl_memorylayer_exists("alpha") != 1){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL exists1\n"); return 1; }
    if (mrliou_mrl_memorylayer_delete("alpha") != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL delete\n"); return 1; }
    if (mrliou_mrl_memorylayer_exists("alpha") != 0){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL exists0\n"); return 1; }
    if (mrliou_mrl_memorylayer_read("alpha", r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL not_found\n"); return 1; }
    if (mrliou_mrl_memorylayer_delete("alpha") != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL del_missing\n"); return 1; }
    if (mrliou_mrl_memorylayer_write("", w, 5) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL empty_key\n"); return 1; }
    if (mrliou_mrl_memorylayer_write(NULL, w, 5) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL null_key\n"); return 1; }
    if (mrliou_mrl_memorylayer_write("big", w, (uint64_t)MRLIOU_MRL_MEML_VAL_MAX + 1) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL size\n"); return 1; }
    uint8_t full[MRLIOU_MRL_MEML_VAL_MAX]; memset(full, 0x5A, sizeof full);
    if (mrliou_mrl_memorylayer_write("cap", full, sizeof full) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL max_write\n"); return 1; }
    if (mrliou_mrl_memorylayer_read("cap", r, 8, &n) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL cap\n"); return 1; }
    if (mrliou_mrl_memorylayer_reset() != MRLIOU_MRL_E_OK || mrliou_mrl_memorylayer_exists("cap") != 0){
        printf("GATE mrliou_mrl_memorylayer_roundtrip FAIL reset\n"); return 1; }
    printf("GATE mrliou_mrl_memorylayer_roundtrip PASS (roundtrip, exists/delete, not_found, empty/null key, size+cap, reset)\n");
    return 0;
}
