#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_law.h"
int main(void){
    static const char *canonical[18] = {
        "Mrliou_MRL_Fluin", "Mrliou_MRL_Kernel", "Mrliou_MRL_Compiler", "Mrliou_MRL_Engine",
        "Mrliou_MRL_Runtime", "Mrliou_MRL_FlowAgent", "Mrliou_MRL_CollapseEngine",
        "Mrliou_MRL_WeightSystem", "Mrliou_MRL_Optimizer", "Mrliou_MRL_Runtime_Core_Assembly",
        "Mrliou_MRL_MemoryLayer", "Mrliou_MRL_MemoryOS", "Mrliou_MRL_MemoryCube", "Mrliou_MRL_MemoryVault",
        "Mrliou_MRL_Database", "Mrliou_MRL_Serializer", "Mrliou_MRL_Search", "Mrliou_MRL_Memory_Runtime_Assembly"
    };
    for (int i = 0; i < 18; i++){
        if (mrliou_mrl_law_check_module_name(canonical[i]) != 0){
            printf("GATE mrliou_mrl_sovereignty_naming_wave02 FAIL canonical %d\n", i); return 1; }
    }
    static const char *illegal[5] = {
        "MemoryLayer", "MRL_Database", "External_MemoryVault", "Firebase_Cache", "Notion_Mirror"
    };
    for (int i = 0; i < 5; i++){
        if (mrliou_mrl_law_check_module_name(illegal[i]) == 0){
            printf("GATE mrliou_mrl_sovereignty_naming_wave02 FAIL illegal %d\n", i); return 1; }
    }
    if (mrliou_mrl_law_check_module_name("") == 0 || mrliou_mrl_law_check_module_name(NULL) == 0){
        printf("GATE mrliou_mrl_sovereignty_naming_wave02 FAIL empty\n"); return 1; }
    if (strncmp(MRLIOU_MRL_WAVE02_VERSION, "Mrliou_MRL_", 11) != 0){
        printf("GATE mrliou_mrl_sovereignty_naming_wave02 FAIL version_name\n"); return 1; }
    if (mrliou_mrl_law_verify("MrLiouWord") != MRLIOU_MRL_GATE_ALLOW){
        printf("GATE mrliou_mrl_sovereignty_naming_wave02 FAIL origin\n"); return 1; }
    if (mrliou_mrl_law_check_runtime_flag(1) != 0 || mrliou_mrl_law_check_runtime_flag(0) == 0){
        printf("GATE mrliou_mrl_sovereignty_naming_wave02 FAIL flag\n"); return 1; }
    printf("GATE mrliou_mrl_sovereignty_naming_wave02 PASS (18 canonical legal, bare/external/brand names blocked, seal name sovereign)\n");
    return 0;
}
