#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memorycube.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_cube_coord_t c1 = {1, 2, 3}, c0 = {0, 0, 0}, c2 = {0, 0, 1}, cbad = {4, 0, 0};
    uint8_t p1[5] = {9,8,7,6,5}, p2[2] = {3,4}, r[64]; uint64_t n = 0;
    uint32_t tA[8], tB[8]; int lA = 0, lB = 0;
    if (mrliou_mrl_memorycube_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL init\n"); return 1; }
    if (mrliou_mrl_memorycube_store(1, &c1, p1, 5) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL store\n"); return 1; }
    if (mrliou_mrl_memorycube_fetch(1, &c1, r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 5 || memcmp(p1, r, 5) != 0){
        printf("GATE mrliou_mrl_memorycube_store_fetch FAIL fetch\n"); return 1; }
    if (mrliou_mrl_memorycube_fetch(1, &c0, r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL empty_cell\n"); return 1; }
    if (mrliou_mrl_memorycube_fetch(2, &c1, r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL missing_cube\n"); return 1; }
    if (mrliou_mrl_memorycube_store(1, &cbad, p1, 5) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL coord_bound\n"); return 1; }
    if (mrliou_mrl_memorycube_store(8, &c1, p1, 5) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL cube_bound\n"); return 1; }
    if (mrliou_mrl_memorycube_store(1, &c1, p1, 65) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL payload_size\n"); return 1; }
    if (mrliou_mrl_memorycube_store(1, &c2, p2, 2) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL store2\n"); return 1; }
    if (mrliou_mrl_memorycube_trace(1, tA, 8, &lA) != MRLIOU_MRL_E_OK || lA != 2){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL trace_len\n"); return 1; }
    if (tA[0] != ((1u << 8) | 2u) || tA[1] != ((27u << 8) | 5u)){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL trace_order\n"); return 1; }
    if (mrliou_mrl_memorycube_trace(1, tB, 8, &lB) != MRLIOU_MRL_E_OK || lB != lA || memcmp(tA, tB, sizeof(uint32_t) * (size_t)lA) != 0){
        printf("GATE mrliou_mrl_memorycube_store_fetch FAIL trace_determinism\n"); return 1; }
    if (mrliou_mrl_memorycube_trace(3, tA, 8, &lA) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL trace_missing\n"); return 1; }
    if (mrliou_mrl_memorycube_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL reset\n"); return 1; }
    if (mrliou_mrl_memorycube_fetch(1, &c1, r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memorycube_store_fetch FAIL reset_fetch\n"); return 1; }
    printf("GATE mrliou_mrl_memorycube_store_fetch PASS (store/fetch, boundary, deterministic ascending trace, reset)\n");
    return 0;
}
