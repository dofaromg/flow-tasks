#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_runtime.h"
int main(void){
    mrliou_mrl_runtime_t rt;
    mrliou_mrl_runtime_init(&rt);
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_SUSPEND) == 0){ printf("GATE mrliou_mrl_runtime_lifecycle FAIL illegal allowed\n"); return 1; }
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_RUN) != 0){ printf("GATE mrliou_mrl_runtime_lifecycle FAIL init->run\n"); return 1; }
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_SUSPEND) != 0){ printf("GATE mrliou_mrl_runtime_lifecycle FAIL run->suspend\n"); return 1; }
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_RUN) != 0){ printf("GATE mrliou_mrl_runtime_lifecycle FAIL resume\n"); return 1; }
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_HALT) != 0){ printf("GATE mrliou_mrl_runtime_lifecycle FAIL halt\n"); return 1; }
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_RUN) == 0){ printf("GATE mrliou_mrl_runtime_lifecycle FAIL halt->run allowed\n"); return 1; }
    printf("GATE mrliou_mrl_runtime_lifecycle PASS (init->run->suspend->resume->halt; illegal blocked)\n");
    return 0;
}
