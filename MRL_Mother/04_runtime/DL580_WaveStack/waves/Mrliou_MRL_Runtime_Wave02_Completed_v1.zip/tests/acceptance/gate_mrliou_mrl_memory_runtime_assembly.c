#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memory_runtime_assembly.h"
int main(void){
    mrliou_mrl_memory_assembly_report_t rep;
    if (mrliou_mrl_memory_runtime_assembly_boot(&rep) != 0){ printf("GATE mrliou_mrl_memory_runtime_assembly FAIL boot\n"); return 1; }
    if (rep.trace_len != MRLIOU_MRL_MEM_ASM_STAGES){ printf("GATE mrliou_mrl_memory_runtime_assembly FAIL trace_len\n"); return 1; }
    static const char *expect[MRLIOU_MRL_MEM_ASM_STAGES] = {
        "Mrliou_MRL_MemoryLayer", "Mrliou_MRL_MemoryOS", "Mrliou_MRL_MemoryCube", "Mrliou_MRL_MemoryVault",
        "Mrliou_MRL_Database", "Mrliou_MRL_Serializer", "Mrliou_MRL_Search", "Mrliou_MRL_Memory_Runtime_Assembly"
    };
    for (int i = 0; i < MRLIOU_MRL_MEM_ASM_STAGES; i++){
        if (!strstr(rep.memory_trace[i], expect[i])){
            printf("GATE mrliou_mrl_memory_runtime_assembly FAIL stage %d order\n", i); return 1; }
    }
    if (!rep.memory_status || !strstr(rep.memory_status, "wave02_closed") ||
        !strstr(rep.memory_status, "runtime_not_complete=true")){
        printf("GATE mrliou_mrl_memory_runtime_assembly FAIL status\n"); return 1; }
    if (!rep.remaining_wave03_hooks || !strstr(rep.remaining_wave03_hooks, "Guardian")){
        printf("GATE mrliou_mrl_memory_runtime_assembly FAIL hooks\n"); return 1; }
    if (mrliou_mrl_memory_runtime_assembly_boot(0) != 0){ printf("GATE mrliou_mrl_memory_runtime_assembly FAIL null_out\n"); return 1; }
    printf("GATE mrliou_mrl_memory_runtime_assembly PASS (8-stage smoke path ordered, status sealed, W3 hooks declared)\n");
    return 0;
}
