#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_database.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
typedef struct { char keys[8][48]; int n; } collect_t;
static int collect_cb(const char *key, const void *val, uint64_t n, void *ud){
    (void)val; (void)n;
    collect_t *c = (collect_t *)ud;
    if (c->n < 8){
        size_t kl = strlen(key);
        if (kl > 47) kl = 47;
        memcpy(c->keys[c->n], key, kl);
        c->keys[c->n][kl] = '\0';
        c->n++;
    }
    return 0;
}
static int stop_cb(const char *key, const void *val, uint64_t n, void *ud){
    (void)key; (void)val; (void)n; (void)ud;
    return 1;
}
int main(void){
    uint8_t w[3] = {7,8,9}, w2[2] = {1,2}, r[256]; uint64_t n = 0;
    collect_t col; memset(&col, 0, sizeof col);
    if (mrliou_mrl_database_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_database_roundtrip FAIL init\n"); return 1; }
    if (mrliou_mrl_database_put("zeta", w, 3) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_database_roundtrip FAIL put\n"); return 1; }
    if (mrliou_mrl_database_put("alpha", w, 3) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_database_roundtrip FAIL put2\n"); return 1; }
    if (mrliou_mrl_database_put("mid", w, 3) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_database_roundtrip FAIL put3\n"); return 1; }
    if (mrliou_mrl_database_get("alpha", r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 3 || memcmp(w, r, 3) != 0){
        printf("GATE mrliou_mrl_database_roundtrip FAIL get\n"); return 1; }
    if (mrliou_mrl_database_put("alpha", w2, 2) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_database_roundtrip FAIL overwrite\n"); return 1; }
    if (mrliou_mrl_database_get("alpha", r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 2 || memcmp(w2, r, 2) != 0){
        printf("GATE mrliou_mrl_database_roundtrip FAIL overwrite_get\n"); return 1; }
    if (mrliou_mrl_database_delete("mid") != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_database_roundtrip FAIL delete\n"); return 1; }
    if (mrliou_mrl_database_get("mid", r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_database_roundtrip FAIL del_get\n"); return 1; }
    if (mrliou_mrl_database_delete("mid") != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_database_roundtrip FAIL del_missing\n"); return 1; }
    if (mrliou_mrl_database_iterate(collect_cb, &col) != 2 || col.n != 2){ printf("GATE mrliou_mrl_database_roundtrip FAIL iterate\n"); return 1; }
    if (strcmp(col.keys[0], "alpha") != 0 || strcmp(col.keys[1], "zeta") != 0){ printf("GATE mrliou_mrl_database_roundtrip FAIL order\n"); return 1; }
    if (mrliou_mrl_database_iterate(0, &col) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_database_roundtrip FAIL null_cb\n"); return 1; }
    if (mrliou_mrl_database_iterate(stop_cb, 0) != 1){ printf("GATE mrliou_mrl_database_roundtrip FAIL early_stop\n"); return 1; }
    if (mrliou_mrl_database_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_database_roundtrip FAIL reset\n"); return 1; }
    memset(&col, 0, sizeof col);
    if (mrliou_mrl_database_iterate(collect_cb, &col) != 0 || col.n != 0){ printf("GATE mrliou_mrl_database_roundtrip FAIL reset_iterate\n"); return 1; }
    printf("GATE mrliou_mrl_database_roundtrip PASS (put/get/delete, ascending iterate, early-stop, null cb, reset)\n");
    return 0;
}
