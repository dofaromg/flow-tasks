#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_search.h"
#include "mrliou_mrl/mrliou_mrl_database.h"
#include "mrliou_mrl/mrliou_mrl_memoryos.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint8_t w[2] = {1, 2};
    mrliou_mrl_search_result_t sr;
    if (mrliou_mrl_database_reset() != MRLIOU_MRL_E_OK || mrliou_mrl_memoryos_reset() != MRLIOU_MRL_E_OK){
        printf("GATE mrliou_mrl_search_lookup FAIL setup\n"); return 1; }
    if (mrliou_mrl_database_put("mrl_core:alpha", w, 1) != MRLIOU_MRL_E_OK ||
        mrliou_mrl_database_put("mrl_core:beta", w, 2) != MRLIOU_MRL_E_OK ||
        mrliou_mrl_database_put("zeta", w, 1) != MRLIOU_MRL_E_OK){
        printf("GATE mrliou_mrl_search_lookup FAIL put\n"); return 1; }
    if (mrliou_mrl_memoryos_namespace_create("mrl_core", 0) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_search_lookup FAIL ns\n"); return 1; }
    if (mrliou_mrl_search_reset() != MRLIOU_MRL_E_OK || mrliou_mrl_search_query_count() != 0){
        printf("GATE mrliou_mrl_search_lookup FAIL reset0\n"); return 1; }
    if (mrliou_mrl_search_exact("zeta", &sr) != MRLIOU_MRL_E_OK || sr.count != 1 || strcmp(sr.keys[0], "zeta") != 0){
        printf("GATE mrliou_mrl_search_lookup FAIL exact\n"); return 1; }
    if (mrliou_mrl_search_query_count() != 1){ printf("GATE mrliou_mrl_search_lookup FAIL count1\n"); return 1; }
    if (mrliou_mrl_search_exact("nope", &sr) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_search_lookup FAIL exact_miss\n"); return 1; }
    if (mrliou_mrl_search_prefix("mrl_", &sr) != MRLIOU_MRL_E_OK || sr.count != 2 ||
        strcmp(sr.keys[0], "mrl_core:alpha") != 0 || strcmp(sr.keys[1], "mrl_core:beta") != 0){
        printf("GATE mrliou_mrl_search_lookup FAIL prefix\n"); return 1; }
    if (mrliou_mrl_search_prefix("qq", &sr) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_search_lookup FAIL prefix_miss\n"); return 1; }
    if (mrliou_mrl_search_namespace("mrl_core", &sr) != MRLIOU_MRL_E_OK || sr.count != 2){
        printf("GATE mrliou_mrl_search_lookup FAIL ns_lookup\n"); return 1; }
    if (mrliou_mrl_search_namespace("ghost", &sr) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_search_lookup FAIL ns_miss\n"); return 1; }
    if (mrliou_mrl_search_exact("", &sr) != MRLIOU_MRL_E_ARG || mrliou_mrl_search_exact(0, &sr) != MRLIOU_MRL_E_ARG ||
        mrliou_mrl_search_prefix("", &sr) != MRLIOU_MRL_E_ARG || mrliou_mrl_search_namespace("", &sr) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_search_lookup FAIL arg\n"); return 1; }
    if (mrliou_mrl_search_reset() != MRLIOU_MRL_E_OK || mrliou_mrl_search_query_count() != 0){
        printf("GATE mrliou_mrl_search_lookup FAIL reset\n"); return 1; }
    if (mrliou_mrl_search_exact("zeta", &sr) != MRLIOU_MRL_E_OK || mrliou_mrl_search_query_count() != 1){
        printf("GATE mrliou_mrl_search_lookup FAIL recount\n"); return 1; }
    printf("GATE mrliou_mrl_search_lookup PASS (exact/prefix/namespace, ascending order, not_found, arg checks, reset)\n");
    return 0;
}
