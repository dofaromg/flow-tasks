#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_runtime_core_assembly.h"
int main(void){
    mrliou_mrl_assembly_report_t rep;
    if (mrliou_mrl_runtime_core_assembly_boot(&rep) != 0){ printf("GATE mrliou_mrl_runtime_core_assembly_wave01 FAIL boot\n"); return 1; }
    if (rep.trace_len != MRLIOU_MRL_ASM_STAGES){ printf("GATE mrliou_mrl_runtime_core_assembly_wave01 FAIL trace_len\n"); return 1; }
    static const char *expect[MRLIOU_MRL_ASM_STAGES] = {
        "Mrliou_MRL_Fluin", "Mrliou_MRL_Kernel", "Mrliou_MRL_Compiler", "Mrliou_MRL_Engine",
        "Mrliou_MRL_Runtime:", "Mrliou_MRL_FlowAgent", "Mrliou_MRL_CollapseEngine",
        "Mrliou_MRL_WeightSystem", "Mrliou_MRL_Optimizer", "Mrliou_MRL_Runtime_Core_Assembly"
    };
    for (int i = 0; i < MRLIOU_MRL_ASM_STAGES; i++){
        if (!strstr(rep.assembly_trace[i], expect[i])){
            printf("GATE mrliou_mrl_runtime_core_assembly_wave01 FAIL stage %d order\n", i); return 1; }
    }
    if (!rep.wave01_status || !strstr(rep.wave01_status, "wave01_closed") ||
        !strstr(rep.wave01_status, "runtime_not_complete=true")){
        printf("GATE mrliou_mrl_runtime_core_assembly_wave01 FAIL status\n"); return 1; }
    if (!rep.missing_wave02_hooks || !strstr(rep.missing_wave02_hooks, "MemoryLayer")){
        printf("GATE mrliou_mrl_runtime_core_assembly_wave01 FAIL missing hooks\n"); return 1; }
    printf("GATE mrliou_mrl_runtime_core_assembly_wave01 PASS (10-stage smoke path ordered, status sealed, W2 hooks declared)\n");
    return 0;
}
