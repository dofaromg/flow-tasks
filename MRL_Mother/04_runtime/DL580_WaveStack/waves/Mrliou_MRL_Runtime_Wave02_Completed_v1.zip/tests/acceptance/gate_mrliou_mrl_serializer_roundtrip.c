#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_serializer.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_atom_t a, a2;
    memset(&a, 0, sizeof a);
    a.magic = 0x304C524Du; a.type_id = 1; a.particle_id = 7;
    a.payload_lo = 0x1122334455667788ULL; a.payload_hi = 0x99AABBCCDDEEFF00ULL;
    a.eta_q16 = 65536u; a.sig_crc = 0xDEADBEEFu;
    uint8_t b1[256], b2[256], bad[256]; uint64_t n1 = 0, n2 = 0;
    if (mrliou_mrl_serializer_atom(&a, b1, sizeof b1, &n1) != MRLIOU_MRL_E_OK || n1 != 60){
        printf("GATE mrliou_mrl_serializer_roundtrip FAIL atom_ser\n"); return 1; }
    if (mrliou_mrl_serializer_atom(&a, b2, sizeof b2, &n2) != MRLIOU_MRL_E_OK || n2 != n1 || memcmp(b1, b2, (size_t)n1) != 0){
        printf("GATE mrliou_mrl_serializer_roundtrip FAIL atom_determinism\n"); return 1; }
    if (mrliou_mrl_deserializer_atom(b1, n1, &a2) != MRLIOU_MRL_E_OK || memcmp(&a, &a2, sizeof a) != 0){
        printf("GATE mrliou_mrl_serializer_roundtrip FAIL atom_deser\n"); return 1; }
    memcpy(bad, b1, (size_t)n1); bad[20] ^= 0xFF;
    if (mrliou_mrl_deserializer_atom(bad, n1, &a2) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_serializer_roundtrip FAIL crc\n"); return 1; }
    if (mrliou_mrl_deserializer_atom(b1, n1 - 1, &a2) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_serializer_roundtrip FAIL truncate\n"); return 1; }
    memcpy(bad, b1, (size_t)n1); bad[0] ^= 0xFF;
    if (mrliou_mrl_deserializer_atom(bad, n1, &a2) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_serializer_roundtrip FAIL magic\n"); return 1; }
    if (mrliou_mrl_serializer_atom(&a, b1, 10, &n1) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_serializer_roundtrip FAIL cap\n"); return 1; }
    /* memory_record */
    mrliou_mrl_memory_record_t mr, mr2;
    memset(&mr, 0, sizeof mr);
    memcpy(mr.key, "rec1", 4);
    mr.len = 5; mr.val[0] = 1; mr.val[1] = 2; mr.val[2] = 3; mr.val[3] = 4; mr.val[4] = 5;
    if (mrliou_mrl_serializer_memory_record(&mr, b1, sizeof b1, &n1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_serializer_roundtrip FAIL memrec_ser\n"); return 1; }
    if (mrliou_mrl_deserializer_memory_record(b1, n1, &mr2) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_serializer_roundtrip FAIL memrec_deser\n"); return 1; }
    if (strcmp(mr.key, mr2.key) != 0 || mr.len != mr2.len || memcmp(mr.val, mr2.val, 5) != 0){
        printf("GATE mrliou_mrl_serializer_roundtrip FAIL memrec_match\n"); return 1; }
    mrliou_mrl_memory_record_t mrbad; memset(&mrbad, 0, sizeof mrbad);
    memcpy(mrbad.key, "x", 1); mrbad.len = 257;
    if (mrliou_mrl_serializer_memory_record(&mrbad, b1, sizeof b1, &n1) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_serializer_roundtrip FAIL memrec_size\n"); return 1; }
    memset(&mrbad, 0, sizeof mrbad); mrbad.len = 1;
    if (mrliou_mrl_serializer_memory_record(&mrbad, b1, sizeof b1, &n1) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_serializer_roundtrip FAIL memrec_empty_key\n"); return 1; }
    /* cube_object */
    mrliou_mrl_cube_object_t co, co2;
    memset(&co, 0, sizeof co);
    co.cube_id = 2; co.coord.x = 1; co.coord.y = 0; co.coord.z = 3; co.len = 4;
    co.payload[0] = 9; co.payload[1] = 8; co.payload[2] = 7; co.payload[3] = 6;
    if (mrliou_mrl_serializer_cube_object(&co, b1, sizeof b1, &n1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_serializer_roundtrip FAIL cube_ser\n"); return 1; }
    if (mrliou_mrl_deserializer_cube_object(b1, n1, &co2) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_serializer_roundtrip FAIL cube_deser\n"); return 1; }
    if (co.cube_id != co2.cube_id || co.coord.x != co2.coord.x || co.coord.y != co2.coord.y ||
        co.coord.z != co2.coord.z || co.len != co2.len || memcmp(co.payload, co2.payload, 4) != 0){
        printf("GATE mrliou_mrl_serializer_roundtrip FAIL cube_match\n"); return 1; }
    co.len = 65;
    if (mrliou_mrl_serializer_cube_object(&co, b1, sizeof b1, &n1) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_serializer_roundtrip FAIL cube_size\n"); return 1; }
    printf("GATE mrliou_mrl_serializer_roundtrip PASS (atom 60B frame, memrec, cubeobj roundtrip; crc/truncate/magic/size guarded)\n");
    return 0;
}
