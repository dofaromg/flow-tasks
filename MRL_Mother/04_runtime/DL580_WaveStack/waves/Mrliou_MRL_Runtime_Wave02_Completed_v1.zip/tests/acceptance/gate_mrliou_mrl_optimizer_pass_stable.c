#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_optimizer.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_plan_t in, o1, o2, o3;
    memset(&in, 0, sizeof in);
    in.nodes[0].node_id = 1; in.nodes[0].weight = 5; in.nodes[0].required = 1;
    in.nodes[1].node_id = 2; in.nodes[1].weight = 9; in.nodes[1].required = 0;
    in.nodes[2].node_id = 3; in.nodes[2].weight = 0; in.nodes[2].required = 0; /* 冗餘 */
    in.nodes[3].node_id = 4; in.nodes[3].weight = 0; in.nodes[3].required = 1; /* 必要(零權重) */
    in.n = 4;
    if (mrliou_mrl_optimizer_pass(&in, &o1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_optimizer_pass_stable FAIL call\n"); return 1; }
    if (o1.n != 3){ printf("GATE mrliou_mrl_optimizer_pass_stable FAIL fold count\n"); return 1; }
    int saw1 = 0, saw2 = 0, saw3 = 0, saw4 = 0;
    for (int i = 0; i < o1.n; i++){
        if (o1.nodes[i].node_id == 1) saw1 = 1;
        if (o1.nodes[i].node_id == 2) saw2 = 1;
        if (o1.nodes[i].node_id == 3) saw3 = 1;
        if (o1.nodes[i].node_id == 4) saw4 = 1;
    }
    if (!saw1 || !saw2 || saw3 || !saw4){ printf("GATE mrliou_mrl_optimizer_pass_stable FAIL required preservation\n"); return 1; }
    if (o1.provenance_fp == 0){ printf("GATE mrliou_mrl_optimizer_pass_stable FAIL provenance\n"); return 1; }
    if (mrliou_mrl_optimizer_pass(&in, &o2) != MRLIOU_MRL_E_OK || memcmp(&o1, &o2, sizeof o1) != 0){
        printf("GATE mrliou_mrl_optimizer_pass_stable FAIL nondeterministic\n"); return 1; }
    if (mrliou_mrl_optimizer_pass(&o1, &o3) != MRLIOU_MRL_E_OK || memcmp(&o1, &o3, sizeof o1) != 0){
        printf("GATE mrliou_mrl_optimizer_pass_stable FAIL idempotence/provenance chain\n"); return 1; }
    if (mrliou_mrl_optimizer_pass(NULL, &o1) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_optimizer_pass_stable FAIL null arg\n"); return 1; }
    mrliou_mrl_plan_t bad; memset(&bad, 0, sizeof bad); bad.n = MRLIOU_MRL_PLAN_MAX + 1;
    if (mrliou_mrl_optimizer_pass(&bad, &o1) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_optimizer_pass_stable FAIL bounds\n"); return 1; }
    printf("GATE mrliou_mrl_optimizer_pass_stable PASS (required preserved, redundant folded, deterministic, idempotent, provenance kept)\n");
    return 0;
}
