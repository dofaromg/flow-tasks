#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_memoryvault.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint8_t d[4] = {0xA, 0xB, 0xC, 0xD}, r[256]; uint64_t n = 0;
    uint32_t id1 = 0, id2 = 0;
    char m1[512], m2[512];
    if (mrliou_mrl_memoryvault_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL init\n"); return 1; }
    if (mrliou_mrl_memoryvault_archive("seal", d, 4, &id1) != MRLIOU_MRL_E_OK || id1 != 1){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL archive\n"); return 1; }
    if (mrliou_mrl_memoryvault_restore(id1, r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 4 || memcmp(d, r, 4) != 0){
        printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL roundtrip\n"); return 1; }
    if (mrliou_mrl_memoryvault_archive("second", d, 2, &id2) != MRLIOU_MRL_E_OK || id2 != 2){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL archive2\n"); return 1; }
    if (mrliou_mrl_memoryvault_manifest(m1, sizeof m1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL manifest\n"); return 1; }
    if (!strstr(m1, "tag=seal") || !strstr(m1, "origin=MrLiouWord")){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL manifest_content\n"); return 1; }
    if (mrliou_mrl_memoryvault_manifest(m2, sizeof m2) != MRLIOU_MRL_E_OK || strcmp(m1, m2) != 0){
        printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL manifest_determinism\n"); return 1; }
    if (mrliou_mrl_memoryvault_restore(99, r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL not_found\n"); return 1; }
    if (mrliou_mrl_memoryvault_archive("", d, 4, &id1) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL empty_tag\n"); return 1; }
    if (mrliou_mrl_memoryvault_manifest(m1, 8) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL manifest_cap\n"); return 1; }
    if (mrliou_mrl_memoryvault_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL reset\n"); return 1; }
    if (mrliou_mrl_memoryvault_restore(1, r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL reset_restore\n"); return 1; }
    if (mrliou_mrl_memoryvault_archive("again", d, 1, &id1) != MRLIOU_MRL_E_OK || id1 != 1){
        printf("GATE mrliou_mrl_memoryvault_archive_restore FAIL deterministic_id\n"); return 1; }   /* reset 後 id 重新自 1 起 */
    printf("GATE mrliou_mrl_memoryvault_archive_restore PASS (archive/restore, deterministic manifest, origin preserved, reset)\n");
    return 0;
}
