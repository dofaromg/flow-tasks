#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_collapse_engine.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_collapse_result_t r1, r2, r3, r4, r5;
    if (mrliou_mrl_collapse_imagine(42ULL, 7u, 5, &r1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL call\n"); return 1; }
    if (mrliou_mrl_collapse_imagine(42ULL, 7u, 5, &r2) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL call2\n"); return 1; }
    if (r1.imagined_state != r2.imagined_state || r1.trace_len != 5 ||
        memcmp(r1.collapse_trace, r2.collapse_trace, sizeof r1.collapse_trace) != 0){
        printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL nondeterministic\n"); return 1; }
    if (strcmp(r1.scope, "skeleton_imagination") != 0){ printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL scope\n"); return 1; }
    if (mrliou_mrl_collapse_imagine(43ULL, 7u, 5, &r3) != MRLIOU_MRL_E_OK || r3.imagined_state == r1.imagined_state){
        printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL seed sensitivity\n"); return 1; }
    if (mrliou_mrl_collapse_imagine(1ULL, 1u, 100, &r4) != MRLIOU_MRL_E_OK || r4.trace_len != MRLIOU_MRL_COLLAPSE_TRACE_MAX){
        printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL clamp high\n"); return 1; }
    if (mrliou_mrl_collapse_imagine(1ULL, 1u, 0, &r5) != MRLIOU_MRL_E_OK || r5.trace_len != 1){
        printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL clamp low\n"); return 1; }
    if (mrliou_mrl_collapse_imagine(1ULL, 1u, 3, NULL) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL null arg\n"); return 1; }
    if (mrliou_mrl_collapse_search(3) != MRLIOU_MRL_E_P1){ printf("GATE mrliou_mrl_collapse_imagine_deterministic FAIL search honest hook\n"); return 1; }
    printf("GATE mrliou_mrl_collapse_imagine_deterministic PASS (deterministic state+trace, scope=skeleton_imagination, clamp, search=E_P1)\n");
    return 0;
}
