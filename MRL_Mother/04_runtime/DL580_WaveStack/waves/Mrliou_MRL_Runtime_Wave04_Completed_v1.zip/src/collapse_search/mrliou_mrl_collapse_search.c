#include <string.h>
#include "mrliou_mrl/mrliou_mrl_collapse_search.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
static uint64_t g_cs_count = 0;
static uint64_t cs_mix64(uint64_t x){
    x ^= x >> 33; x *= 0xFF51AFD7ED558CCDULL;
    x ^= x >> 33; x *= 0xC4CEB9FE1A85EC53ULL;
    x ^= x >> 33; return x;
}
int mrliou_mrl_collapse_search_init(void){
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    g_cs_count = 0;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_collapse_search_query(const mrliou_mrl_collapse_search_query_t *q, mrliou_mrl_collapse_search_result_t *out){
    if (!q || !out) return MRLIOU_MRL_E_ARG;
    if (q->memory_trace_len < 0 || q->collapse_trace_len < 0) return MRLIOU_MRL_E_ARG;
    if (q->memory_trace_len == 0 && q->collapse_trace_len == 0) return MRLIOU_MRL_E_ARG;       /* 空查詢 */
    if (q->memory_trace_len > 0 && !q->memory_trace) return MRLIOU_MRL_E_NOT_FOUND;            /* 記憶軌跡缺失 */
    if (q->collapse_trace_len > 0 && !q->collapse_trace) return MRLIOU_MRL_E_NOT_FOUND;
    if (q->memory_trace_len > MRLIOU_MRL_CSEARCH_MEMTRACE_MAX ||
        q->collapse_trace_len > MRLIOU_MRL_CSEARCH_CTRACE_MAX) return MRLIOU_MRL_E_BOUNDARY;
    g_cs_count++;
    uint64_t fold = cs_mix64(q->seed ^ cs_mix64(q->context ^ 0x4D524C30ULL));                  /* 'MRL0' salt */
    for (int i = 0; i < q->memory_trace_len; i++)
        fold = cs_mix64(fold ^ ((uint64_t)q->memory_trace[i] + 0x9E3779B97F4A7C15ULL * (uint64_t)(i + 1)));
    for (int i = 0; i < q->collapse_trace_len; i++)
        fold = cs_mix64(fold ^ ((uint64_t)q->collapse_trace[i] + 0xC2B2AE3D27D4EB4FULL * (uint64_t)(i + 1)));
    memset(out, 0, sizeof *out);
    out->count = 4 + (int)(fold % 5ULL);                                                       /* 4..8 確定性 */
    for (int k = 0; k < out->count; k++){
        out->candidate_state[k] = cs_mix64(fold + 0x9E3779B97F4A7C15ULL * (uint64_t)(k + 1));
        out->score[k]           = cs_mix64(out->candidate_state[k] ^ q->context);
        out->ranked_idx[k]      = k;
    }
    out->search_fp = cs_mix64(fold ^ (uint64_t)out->count);
    out->ranked = 0;
    return MRLIOU_MRL_E_OK;
}
static int cs_before(const mrliou_mrl_collapse_search_result_t *r, int a, int b){
    if (r->score[a] != r->score[b]) return r->score[a] > r->score[b];                          /* 分數降冪 */
    if (r->candidate_state[a] != r->candidate_state[b]) return r->candidate_state[a] < r->candidate_state[b];
    return a < b;                                                                              /* 穩定 */
}
int mrliou_mrl_collapse_search_rank(mrliou_mrl_collapse_search_result_t *r){
    if (!r) return MRLIOU_MRL_E_ARG;
    if (r->count < 1 || r->count > MRLIOU_MRL_CSEARCH_CAND_MAX) return MRLIOU_MRL_E_BOUNDARY;
    for (int a = 1; a < r->count; a++){                                                        /* 插入排序=穩定 */
        int v = r->ranked_idx[a], b = a - 1;
        while (b >= 0 && cs_before(r, v, r->ranked_idx[b])){ r->ranked_idx[b + 1] = r->ranked_idx[b]; b--; }
        r->ranked_idx[b + 1] = v;
    }
    r->ranked = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_collapse_search_trace(const mrliou_mrl_collapse_search_result_t *r, uint64_t *out_trace, int cap, int *out_len){
    if (!r || !out_trace || !out_len || cap < 1) return MRLIOU_MRL_E_ARG;
    if (r->count < 1) return MRLIOU_MRL_E_NOT_FOUND;
    if (r->count > MRLIOU_MRL_CSEARCH_CAND_MAX) return MRLIOU_MRL_E_BOUNDARY;
    if (cap < r->count) return MRLIOU_MRL_E_ARG;
    for (int i = 0; i < r->count; i++) out_trace[i] = r->candidate_state[r->ranked_idx[i]];    /* ranked_path 可回放 */
    *out_len = r->count;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_collapse_search_reset(void){
    g_cs_count = 0;
    return MRLIOU_MRL_E_OK;
}
uint64_t mrliou_mrl_collapse_search_query_count(void){ return g_cs_count; }
