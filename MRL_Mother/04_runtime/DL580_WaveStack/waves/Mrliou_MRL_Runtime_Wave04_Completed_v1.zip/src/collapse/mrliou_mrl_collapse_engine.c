#include <string.h>
#include "mrliou_mrl/mrliou_mrl_collapse_engine.h"
#include "mrliou_mrl/mrliou_mrl_collapse_search.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
static uint64_t mrliou_mrl_mix64(uint64_t x){
    x ^= x >> 33; x *= 0xff51afd7ed558ccdULL;
    x ^= x >> 33; x *= 0xc4ceb9fe1a85ec53ULL;
    x ^= x >> 33; return x;          /* 純函數確定性混淆;非亂數 */
}
int mrliou_mrl_collapse_imagine(uint64_t seed, uint32_t context, int depth, mrliou_mrl_collapse_result_t *out){
    if (!out) return MRLIOU_MRL_E_ARG;
    memset(out, 0, sizeof *out);
    if (depth < 1) depth = 1;
    if (depth > MRLIOU_MRL_COLLAPSE_TRACE_MAX) depth = MRLIOU_MRL_COLLAPSE_TRACE_MAX; /* 骨架邊界 */
    uint64_t s = mrliou_mrl_mix64(seed ^ 0x4D524C30ULL /* 'MRL0' */);
    for (int i = 0; i < depth; i++){
        s = mrliou_mrl_mix64(s ^ ((uint64_t)context + (uint64_t)i + 1ULL));
        out->collapse_trace[i] = (uint32_t)(s & 0xFFFFFFFFu);
    }
    out->imagined_state = s;
    out->trace_len = depth;
    out->scope = "skeleton_imagination";
    return MRLIOU_MRL_E_OK;
}
/* Wave_04: collapse_search 正式退役 E_P1 → 委派 Mrliou_MRL_Collapse_Search(結果可 trace) */
int mrliou_mrl_collapse_engine_search_traced(uint64_t seed, uint32_t context, int width,
                                             mrliou_mrl_collapse_search_result_t *out){
    if (!out) return MRLIOU_MRL_E_ARG;
    if (width < 1 || width > MRLIOU_MRL_COLLAPSE_TRACE_MAX) return MRLIOU_MRL_E_ARG;
    mrliou_mrl_collapse_result_t im;
    int rc = mrliou_mrl_collapse_imagine(seed, context, width, &im);
    if (rc != MRLIOU_MRL_E_OK) return rc;
    mrliou_mrl_collapse_search_query_t q;
    q.seed = seed;
    q.context = (uint64_t)context;
    q.memory_trace = 0;                       /* 內生查詢:無外部記憶軌跡(len=0 合法缺席) */
    q.memory_trace_len = 0;
    q.collapse_trace = im.collapse_trace;     /* imagine trace = 搜尋輸入(可回放) */
    q.collapse_trace_len = im.trace_len;
    rc = mrliou_mrl_collapse_search_query(&q, out);
    if (rc != MRLIOU_MRL_E_OK) return rc;
    return mrliou_mrl_collapse_search_rank(out);
}
int mrliou_mrl_collapse_search(int width){
    mrliou_mrl_collapse_search_result_t res;
    return mrliou_mrl_collapse_engine_search_traced(0x4D524C30ULL + (uint64_t)width,
                                                    0x57303400u ^ (uint32_t)width, width, &res);
}
