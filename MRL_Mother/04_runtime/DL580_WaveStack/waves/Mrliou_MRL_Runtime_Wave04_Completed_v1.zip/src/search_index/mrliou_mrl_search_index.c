#include <string.h>
#include "mrliou_mrl/mrliou_mrl_search_index.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
typedef struct {
    int used;
    char key[MRLIOU_MRL_SIDX_KEY_MAX];
    uint64_t len;
    uint8_t val[MRLIOU_MRL_SIDX_VAL_MAX];
} mrliou_mrl_sidx_slot_t;
static mrliou_mrl_sidx_slot_t g_sidx[MRLIOU_MRL_SIDX_SLOTS]; /* process-local;no external DB */
static int g_sidx_init = 0;
static void sidx_ensure(void){ if (!g_sidx_init){ memset(g_sidx, 0, sizeof g_sidx); g_sidx_init = 1; } }
static int sidx_check_key(const char *key){
    if (!key || key[0] == '\0') return -1;
    if (strlen(key) >= MRLIOU_MRL_SIDX_KEY_MAX) return -1;
    return 0;
}
static mrliou_mrl_sidx_slot_t *sidx_find(const char *key){
    for (int i = 0; i < MRLIOU_MRL_SIDX_SLOTS; i++)
        if (g_sidx[i].used && strcmp(g_sidx[i].key, key) == 0) return &g_sidx[i];
    return 0;
}
int mrliou_mrl_search_index_init(void){
    memset(g_sidx, 0, sizeof g_sidx);
    g_sidx_init = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_search_index_add(const char *key, const void *val, uint64_t n){
    if (sidx_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (!val || n == 0 || n > MRLIOU_MRL_SIDX_VAL_MAX) return MRLIOU_MRL_E_ARG;
    sidx_ensure();
    mrliou_mrl_sidx_slot_t *s = sidx_find(key);                                  /* duplicate = update */
    if (!s){
        for (int i = 0; i < MRLIOU_MRL_SIDX_SLOTS; i++) if (!g_sidx[i].used){ s = &g_sidx[i]; break; }
        if (!s) return MRLIOU_MRL_E_ARG;                                         /* capacity check */
        memset(s, 0, sizeof *s);
        size_t kl = strlen(key);
        memcpy(s->key, key, kl); s->key[kl] = '\0';
        s->used = 1;
    }
    memcpy(s->val, val, (size_t)n);
    s->len = n;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_search_index_get(const char *key, void *buf, uint64_t cap, uint64_t *out_n){
    if (sidx_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (!buf || !out_n) return MRLIOU_MRL_E_ARG;
    sidx_ensure();
    mrliou_mrl_sidx_slot_t *s = sidx_find(key);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;
    if (cap < s->len) return MRLIOU_MRL_E_ARG;
    memcpy(buf, s->val, (size_t)s->len);
    *out_n = s->len;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_search_index_prefix(const char *prefix, mrliou_mrl_search_index_result_t *out){
    if (!prefix || prefix[0] == '\0' || !out) return MRLIOU_MRL_E_ARG;
    sidx_ensure();
    memset(out, 0, sizeof *out);
    size_t pl = strlen(prefix);
    int idx[MRLIOU_MRL_SIDX_SLOTS], cnt = 0;
    for (int i = 0; i < MRLIOU_MRL_SIDX_SLOTS; i++)
        if (g_sidx[i].used && strncmp(g_sidx[i].key, prefix, pl) == 0) idx[cnt++] = i;
    if (cnt == 0) return MRLIOU_MRL_E_NOT_FOUND;
    if (cnt > MRLIOU_MRL_SIDX_RESULT_MAX) return MRLIOU_MRL_E_BOUNDARY;
    for (int a = 1; a < cnt; a++){                                               /* key 升冪 = 確定序 */
        int v = idx[a], b = a - 1;
        while (b >= 0 && strcmp(g_sidx[idx[b]].key, g_sidx[v].key) > 0){ idx[b + 1] = idx[b]; b--; }
        idx[b + 1] = v;
    }
    for (int i = 0; i < cnt; i++){
        size_t kl = strlen(g_sidx[idx[i]].key);
        memcpy(out->keys[i], g_sidx[idx[i]].key, kl);
        out->keys[i][kl] = '\0';
    }
    out->count = cnt;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_search_index_reset(void){
    memset(g_sidx, 0, sizeof g_sidx);
    g_sidx_init = 1;
    return MRLIOU_MRL_E_OK;
}
