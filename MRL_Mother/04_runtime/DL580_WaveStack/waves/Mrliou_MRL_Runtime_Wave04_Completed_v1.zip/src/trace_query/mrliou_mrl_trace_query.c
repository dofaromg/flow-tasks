#include <string.h>
#include "mrliou_mrl/mrliou_mrl_trace_query.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
typedef struct { int used; uint64_t id; uint64_t parent; uint64_t fp; } mrliou_mrl_tq_slot_t;
static mrliou_mrl_tq_slot_t g_tq[MRLIOU_MRL_TQ_SLOTS];
static int g_tq_init = 0;
static void tq_ensure(void){ if (!g_tq_init){ memset(g_tq, 0, sizeof g_tq); g_tq_init = 1; } }
static mrliou_mrl_tq_slot_t *tq_find(uint64_t id){
    for (int i = 0; i < MRLIOU_MRL_TQ_SLOTS; i++)
        if (g_tq[i].used && g_tq[i].id == id) return &g_tq[i];
    return 0;
}
int mrliou_mrl_trace_query_init(void){
    memset(g_tq, 0, sizeof g_tq);
    g_tq_init = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_trace_query_add(uint64_t trace_id, uint64_t parent_id, uint64_t payload_fp){
    if (trace_id == 0) return MRLIOU_MRL_E_ARG;                       /* 0 = root 哨兵 */
    if (trace_id == parent_id) return MRLIOU_MRL_E_CYCLE;             /* 自指即環 */
    tq_ensure();
    if (tq_find(trace_id)) return MRLIOU_MRL_E_DUP;
    mrliou_mrl_tq_slot_t *s = 0;
    for (int i = 0; i < MRLIOU_MRL_TQ_SLOTS; i++) if (!g_tq[i].used){ s = &g_tq[i]; break; }
    if (!s) return MRLIOU_MRL_E_ARG;                                  /* 容量滿 */
    s->id = trace_id; s->parent = parent_id; s->fp = payload_fp; s->used = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_trace_query_find(uint64_t trace_id, uint64_t *out_parent, uint64_t *out_fp){
    if (trace_id == 0) return MRLIOU_MRL_E_ARG;
    tq_ensure();
    mrliou_mrl_tq_slot_t *s = tq_find(trace_id);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;
    if (out_parent) *out_parent = s->parent;
    if (out_fp) *out_fp = s->fp;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_trace_query_chain(uint64_t trace_id, uint64_t *out_chain, int cap, int *out_len){
    if (trace_id == 0 || !out_chain || !out_len || cap < 1) return MRLIOU_MRL_E_ARG;
    tq_ensure();
    uint64_t visited[MRLIOU_MRL_TQ_CHAIN_MAX];
    uint64_t cur = trace_id;
    int idx = 0;
    for (;;){
        mrliou_mrl_tq_slot_t *s = tq_find(cur);
        if (!s) return MRLIOU_MRL_E_NOT_FOUND;                        /* 缺節點/鏈不完整 */
        for (int j = 0; j < idx; j++)
            if (visited[j] == cur) return MRLIOU_MRL_E_CYCLE;         /* 環防護 */
        if (idx >= MRLIOU_MRL_TQ_CHAIN_MAX) return MRLIOU_MRL_E_BOUNDARY; /* 鏈深邊界 */
        visited[idx] = cur;
        if (idx >= cap) return MRLIOU_MRL_E_ARG;
        out_chain[idx] = cur;
        idx++;
        if (s->parent == 0) break;                                    /* root */
        cur = s->parent;
    }
    *out_len = idx;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_trace_query_reset(void){
    memset(g_tq, 0, sizeof g_tq);
    g_tq_init = 1;
    return MRLIOU_MRL_E_OK;
}
