#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_collapse_search_runtime_assembly.h"
#include "mrliou_mrl/mrliou_mrl_collapse_search.h"
#include "mrliou_mrl/mrliou_mrl_search_index.h"
#include "mrliou_mrl/mrliou_mrl_trace_query.h"
#include "mrliou_mrl/mrliou_mrl_collapse_engine.h"
#include "mrliou_mrl/mrliou_mrl_memorycube.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
static const char *k_w4_nodes[MRLIOU_MRL_CS_ASM_STAGES] = {
    "Mrliou_MRL_Collapse_Search", "Mrliou_MRL_Search_Index", "Mrliou_MRL_Trace_Query",
    "Mrliou_MRL_Collapse_Search_Runtime_Assembly"
};
static void cs_mark(mrliou_mrl_collapse_search_assembly_report_t *r, int idx, const char *line){
    printf("[collapse_search_assembly] %s\n", line);
    if (r && idx >= 0 && idx < MRLIOU_MRL_CS_ASM_STAGES){
        snprintf(r->collapse_search_trace[idx], sizeof r->collapse_search_trace[idx], "%s", line);
        r->trace_len = idx + 1;
    }
}
int mrliou_mrl_collapse_search_runtime_assembly_boot(mrliou_mrl_collapse_search_assembly_report_t *out){
    if (out) memset(out, 0, sizeof *out);
    /* --- LAW 前置門(Guardian-backed) --- */
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return -1;
    for (int i = 0; i < MRLIOU_MRL_CS_ASM_STAGES; i++)
        if (mrliou_mrl_law_check_module_name(k_w4_nodes[i]) != 0) return -1;
    if (mrliou_mrl_law_check_module_name("External_Search") == 0) return -1;
    if (mrliou_mrl_law_check_runtime_flag(1) != 0) return -1;
    printf("[collapse_search_assembly] LAW gate: origin+naming+flag verified (guardian-backed)\n");

    /* 0 Collapse_Search: 真實 memory_trace + collapse_trace 輸入 */
    if (mrliou_mrl_collapse_search_init() != MRLIOU_MRL_E_OK) return -2;
    mrliou_mrl_cube_coord_t ca = {0, 0, 1}, cb = {1, 2, 3};
    uint8_t pay[3] = {4, 5, 6};
    uint32_t mtrace[8]; int mlen = 0;
    if (mrliou_mrl_memorycube_reset() != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_memorycube_store(1, &ca, pay, 3) != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_memorycube_store(1, &cb, pay, 2) != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_memorycube_trace(1, mtrace, 8, &mlen) != MRLIOU_MRL_E_OK || mlen != 2) return -2;
    mrliou_mrl_collapse_result_t im;
    if (mrliou_mrl_collapse_imagine(77ULL, 9u, 4, &im) != MRLIOU_MRL_E_OK) return -2;
    mrliou_mrl_collapse_search_query_t q;
    q.seed = 77ULL; q.context = 9ULL;
    q.memory_trace = mtrace;            q.memory_trace_len = mlen;
    q.collapse_trace = im.collapse_trace; q.collapse_trace_len = im.trace_len;
    mrliou_mrl_collapse_search_result_t res, res2;
    uint64_t path[MRLIOU_MRL_CSEARCH_CAND_MAX]; int plen = 0;
    if (mrliou_mrl_collapse_search_query(&q, &res) != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_collapse_search_rank(&res) != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_collapse_search_trace(&res, path, MRLIOU_MRL_CSEARCH_CAND_MAX, &plen) != MRLIOU_MRL_E_OK || plen != res.count) return -2;
    if (mrliou_mrl_collapse_search_query(&q, &res2) != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_collapse_search_rank(&res2) != MRLIOU_MRL_E_OK) return -2;
    if (memcmp(&res, &res2, sizeof res) != 0) return -2;                       /* 確定性 */
    cs_mark(out, 0, "0 Mrliou_MRL_Collapse_Search: query/rank/trace OK");

    /* 1 Search_Index: ranked path 入索引 */
    if (mrliou_mrl_search_index_init() != MRLIOU_MRL_E_OK) return -3;
    char key[24]; uint8_t rb[16]; uint64_t rn = 0;
    for (int i = 0; i < res.count; i++){
        snprintf(key, sizeof key, "cs:cand:%d", i);
        if (mrliou_mrl_search_index_add(key, &path[i], sizeof path[i]) != MRLIOU_MRL_E_OK) return -3;
    }
    if (mrliou_mrl_search_index_get("cs:cand:0", rb, sizeof rb, &rn) != MRLIOU_MRL_E_OK || rn != 8) return -3;
    if (memcmp(rb, &path[0], 8) != 0) return -3;
    mrliou_mrl_search_index_result_t sr;
    if (mrliou_mrl_search_index_prefix("cs:cand:", &sr) != MRLIOU_MRL_E_OK || sr.count != res.count) return -3;
    cs_mark(out, 1, "1 Mrliou_MRL_Search_Index: add/get/prefix OK");

    /* 2 Trace_Query: search_fp 為 root 的 ranked 鏈 */
    if (mrliou_mrl_trace_query_init() != MRLIOU_MRL_E_OK) return -4;
    if (mrliou_mrl_trace_query_add(1, 0, res.search_fp) != MRLIOU_MRL_E_OK) return -4;
    for (int i = 0; i < res.count; i++)
        if (mrliou_mrl_trace_query_add((uint64_t)(i + 2), (uint64_t)(i + 1), path[i]) != MRLIOU_MRL_E_OK) return -4;
    uint64_t chain[MRLIOU_MRL_TQ_CHAIN_MAX]; int clen = 0;
    if (mrliou_mrl_trace_query_chain((uint64_t)(res.count + 1), chain, MRLIOU_MRL_TQ_CHAIN_MAX, &clen) != MRLIOU_MRL_E_OK) return -4;
    if (clen != res.count + 1 || chain[clen - 1] != 1) return -4;
    uint64_t pa = 0, fp = 0;
    if (mrliou_mrl_trace_query_find(2, &pa, &fp) != MRLIOU_MRL_E_OK || pa != 1 || fp != path[0]) return -4;
    cs_mark(out, 2, "2 Mrliou_MRL_Trace_Query: chain/find OK");

    /* 3 SEAL */
    cs_mark(out, 3, "3 Mrliou_MRL_Collapse_Search_Runtime_Assembly: SEAL OK");
    if (out){
        out->collapse_search_status = "wave04_closed(collapse_search_foundation_completed;runtime_not_complete=true)";
        out->remaining_wave05_hooks =
            "wave05: Runtime_Service_Foundation(integration/boot/service surface);"
            "ed25519_sign_hook(deploy-side);DL580_deploy(pending Bridge_API_Key)";
    }
    return 0;
}
