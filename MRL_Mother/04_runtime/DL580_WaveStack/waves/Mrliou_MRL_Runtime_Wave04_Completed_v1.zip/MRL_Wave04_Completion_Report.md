# MRL_Wave04_Completion_Report
origin_signature: MrLiouWord
seal: Mrliou_MRL_Runtime_Wave04_v1.0
status: wave04_closed | runtime_scope: collapse_search_foundation_completed | runtime_not_complete: true | wave05_required: true
date: 2026-06-11
baseline: Mrliou_MRL_Runtime_Wave03_Completed_v1.zip(sha256=d7d3e742…0331 對帳通過;30/30 基線實跑)

## completed_components(canonical 全 Mrliou_MRL_)
1. Mrliou_MRL_Collapse_Search — 確定性坍縮搜尋核;輸入 seed/context/memory_trace/collapse_trace → search_result(4..8 候選+score+search_fp)/ranked_path/trace;空查詢=E_ARG、軌跡缺失=E_NOT_FOUND、越界=E_BOUNDARY;rank 穩定(降冪+平手定序+冪等);query_count 可驗;無網路/無外部模型/無外部搜尋
2. Mrliou_MRL_Search_Index — 搜尋索引層;add/get/prefix;重複 key=更新;64 槽容量檢查;key 升冪確定序;>16 匹配=E_BOUNDARY;process-local 無外部 DB
3. Mrliou_MRL_Trace_Query — 軌跡鏈查詢;parent/child 關係;chain 至 root;自指/環=E_CYCLE(-9 新增);鏈深>16=E_BOUNDARY;缺節點=E_NOT_FOUND;前向引用合法
4. Mrliou_MRL_Collapse_Search_Runtime_Assembly — LAW 前置門+4 階段 smoke;真實 MemoryCube trace + Imagine trace 輸入;ranked path 入索引;search_fp 為 root 之鏈;確定性 re-run 實證;輸出 collapse_search_trace/status/remaining_wave05_hooks
5. CollapseEngine 委派 — collapse_search 正式退役 E_P1(全 tree 0 使用點;僅 kernel.h 定義保留為 lineage);委派 Mrliou_MRL_Collapse_Search;新增 traced 介面(結果可回放);Imagine deterministic skeleton 不變

## files_changed
created(20): include/mrliou_mrl/{mrliou_mrl_collapse_search.h, mrliou_mrl_search_index.h, mrliou_mrl_trace_query.h, mrliou_mrl_collapse_search_runtime_assembly.h}; src/{collapse_search, search_index, trace_query, collapse_search_assembly}/mrliou_mrl_*.c(4); tests/acceptance/gate_mrliou_mrl_{collapse_search_query, collapse_search_rank, search_index_roundtrip, search_index_prefix, trace_query_chain, trace_query_cycle_guard, collapse_engine_search_delegation, collapse_search_runtime_assembly, wave04_sovereignty}.c(9); contracts/mrliou_mrl_wave04_contracts.yaml; MRL_Wave04_Completion_Log.md; MRL_Wave04_Completion_Report.md
modified(11): include/mrliou_mrl/mrliou_mrl_collapse_engine.h + src/collapse/mrliou_mrl_collapse_engine.c(E_P1 退役→委派+traced 介面); include/mrliou_mrl/mrliou_mrl_kernel.h(+E_CYCLE -9); include/mrliou_mrl/mrliou_mrl_law.h(+WAVE04 版本); src/assembly/mrliou_mrl_runtime_core_assembly.c + src/memory_assembly/mrliou_mrl_memory_runtime_assembly.c + src/guardian_assembly/mrliou_mrl_guardian_runtime_assembly.c(hooks 宣告 wave04_completed/wave05); src/runtime/mrliou_mrl_runtime_main.c(四組裝接線); Makefile(26 OBJ;39 GATES); README.md(wave04 封版); contracts/mrliou_mrl_wave03_contracts.yaml(僅追加 wave04_completed note)
strengthened_gates(4): gate_mrliou_mrl_collapse_imagine_deterministic(原斷言全保留;search!=E_P1 且==E_OK;width 0=E_ARG); gate_mrliou_mrl_runtime_core_assembly_wave01(+wave04_completed 宣告檢查); gate_mrliou_mrl_guardian_runtime_assembly(+wave05 待辦宣告檢查); gate_mrliou_mrl_law_struct(E_P1 斷言→W4 委派斷言;因 E_P1 退役強制同步)
unchanged: 其餘 W1/W2/W3 模組與 gate;libmrliou_mrl_runtime.a 主權命名未回退

## gates(39/39;原 30 全保留全通過;gcc -std=c11 -Wall -Wextra 零警告)
GATE mrliou_mrl_fluin_reversibility PASS (1000/1000 unbind(bind(x))==x)
GATE mrliou_mrl_kernel_delta_chain PASS (5 steps, delta=5, origin=MrLiouWord, memio not_found semantics)
GATE mrliou_mrl_kernel_memio_roundtrip PASS (roundtrip, empty/null key, not_found, size+cap checks, overwrite)
GATE mrliou_mrl_compiler_roundtrip PASS (5 atoms x 40B, compile<->decompile lossless, crc verified)
GATE mrliou_mrl_engine_genesis PASS (P_{k+1}=N*P*eta reproducible, delta tracked)
GATE mrliou_mrl_runtime_lifecycle PASS (init->run->suspend->resume->halt; illegal blocked)
GATE mrliou_mrl_flowagent_decide_deterministic PASS (same-in same-out, route in mask, confidence 0..65536, no-route case)
GATE mrliou_mrl_collapse_imagine_deterministic PASS (deterministic state+trace, scope=skeleton_imagination, clamp, search delegated W4)
GATE mrliou_mrl_optimizer_pass_stable PASS (required preserved, redundant folded, deterministic, idempotent, provenance kept)
GATE mrliou_mrl_law_struct PASS (atom=40B, guardian-backed origin/naming/flag/wave/escalation, sum=10.0, W4 search delegated)
GATE mrliou_mrl_runtime_core_assembly_wave01 PASS (10-stage smoke path ordered, status sealed, W2-W4 hooks declared)
GATE mrliou_mrl_memorylayer_roundtrip PASS (roundtrip, exists/delete, not_found, empty/null key, size+cap, reset)
GATE mrliou_mrl_memoryos_namespace PASS (create/lookup/delete, dup=E_DUP, not_found, size check, deterministic id)
GATE mrliou_mrl_memorycube_store_fetch PASS (store/fetch, boundary, deterministic ascending trace, reset)
GATE mrliou_mrl_memoryvault_archive_restore PASS (archive/restore, deterministic manifest, origin preserved, reset)
GATE mrliou_mrl_database_roundtrip PASS (put/get/delete, ascending iterate, early-stop, null cb, reset)
GATE mrliou_mrl_serializer_roundtrip PASS (atom 60B frame, memrec, cubeobj roundtrip; crc/truncate/magic/size guarded)
GATE mrliou_mrl_search_lookup PASS (exact/prefix/namespace, ascending order, not_found, arg checks, reset)
GATE mrliou_mrl_memory_runtime_assembly PASS (8-stage smoke path ordered, status sealed, W3 hooks declared)
GATE mrliou_mrl_sovereignty_naming_wave02 PASS (21 canonical legal incl W3, bare/external/brand blocked, seal names sovereign)
GATE mrliou_mrl_guardian_origin PASS (MrLiouWord allowed, foreign/brand blocked, arg guarded, audit count+reset)
GATE mrliou_mrl_guardian_sovereignty_name PASS (Mrliou_MRL_ allowed; bare/MRL_/External_/brand names blocked)
GATE mrliou_mrl_guardian_runtime_flag PASS (flag=1 only; tamper blocked; wave next/reentry/jump = allowed/warning/blocked)
GATE mrliou_mrl_guardian_external_escalation PASS (internal allowed; external observe/execute/canonical = allowed/warning/BLOCKED)
GATE mrliou_mrl_validator_atom PASS (40B size boundary, magic/type/crc malformed detection)
GATE mrliou_mrl_validator_memory_record PASS (schema ok; empty/no-nul key=malformed; len 0/257=boundary)
GATE mrliou_mrl_validator_cube_object PASS (coordinate/payload boundary checks, arg guarded)
GATE mrliou_mrl_validator_contract PASS (required/forbidden/not_found split; runtime_state ok/forbidden/boundary)
GATE mrliou_mrl_law_guardian_backed PASS (LAW delegates Guardian: origin/name/flag/wave/escalation; delegates Validator: payload)
GATE mrliou_mrl_guardian_runtime_assembly PASS (4-stage smoke path, status sealed, wave04_completed+wave05 hooks declared)
GATE mrliou_mrl_collapse_search_query PASS (deterministic result+fp, empty=E_ARG, missing trace=E_NOT_FOUND, boundary, reset)
GATE mrliou_mrl_collapse_search_rank PASS (score-desc stable rank, idempotent, ranked_path traceable, caps guarded)
GATE mrliou_mrl_search_index_roundtrip PASS (add/get, duplicate update, not_found, size/cap, 64-slot capacity, reset)
GATE mrliou_mrl_search_index_prefix PASS (ascending deterministic prefix, not_found, arg, >16 overflow=E_BOUNDARY)
GATE mrliou_mrl_trace_query_chain PASS (parent/child chain to root, find, dup/arg/cap, incomplete chain=not_found, reset)
GATE mrliou_mrl_trace_query_cycle_guard PASS (self/2-cycle=E_CYCLE, depth 16 ok, depth 17=E_BOUNDARY)
GATE mrliou_mrl_collapse_engine_search_delegation PASS (E_P1 retired, delegation proven by query_count, traced+deterministic)
GATE mrliou_mrl_collapse_search_runtime_assembly PASS (4-stage smoke path, status sealed, wave05 hooks declared)
GATE mrliou_mrl_wave04_sovereignty PASS (25 canonical legal incl W4, bare/external blocked, seal name sovereign, wave boundary)
ALL GATES PASS

## remaining_wave05_hooks
wave05: Runtime_Service_Foundation(integration/boot/service surface)— 未實作、未宣告;ed25519_sign_hook(deploy-side;Wave 內=NULL 不偽造);DL580_deploy(pending_authorization: Bridge_API_Key)

## boundaries(完成判定對應)
- collapse_search 不再回 E_P1 ✓(殘留掃描 0 使用點;判定 1);CollapseEngine 委派 Mrliou_MRL_Collapse_Search(query_count 計數實證)✓(判定 2)
- Collapse_Search query/rank/trace ✓(判定 3);Search_Index add/get/prefix ✓(判定 4);Trace_Query chain/環防護 ✓(判定 5)
- Collapse_Search_Runtime_Assembly smoke ✓(判定 6);原 30 gates 未破壞 ✓(判定 7);ALL GATES PASS 39/39 ✓(判定 8)
- README runtime_not_complete=true ✓ wave05_required=true ✓(判定 9–10)
- DL580: 未寫入、未宣告完成(判定 11);本輪全程 local workspace + Notion 鏡像

## sha256_manifest
全樹逐檔 SHA256 = SHA256SUMS.txt(封入交付包;含本報告);交付 zip sha256 於封版回報註記。

origin_signature: MrLiouWord
