#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_trace_query.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint64_t chain[MRLIOU_MRL_TQ_CHAIN_MAX], pa = 0, fp = 0;
    int len = 0;
    if (mrliou_mrl_trace_query_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_trace_query_chain FAIL init\n"); return 1; }
    if (mrliou_mrl_trace_query_add(1, 0, 111) != MRLIOU_MRL_E_OK ||
        mrliou_mrl_trace_query_add(2, 1, 222) != MRLIOU_MRL_E_OK ||
        mrliou_mrl_trace_query_add(3, 2, 333) != MRLIOU_MRL_E_OK){
        printf("GATE mrliou_mrl_trace_query_chain FAIL add\n"); return 1; }
    if (mrliou_mrl_trace_query_find(2, &pa, &fp) != MRLIOU_MRL_E_OK || pa != 1 || fp != 222){
        printf("GATE mrliou_mrl_trace_query_chain FAIL find\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(3, chain, MRLIOU_MRL_TQ_CHAIN_MAX, &len) != MRLIOU_MRL_E_OK ||
        len != 3 || chain[0] != 3 || chain[1] != 2 || chain[2] != 1){
        printf("GATE mrliou_mrl_trace_query_chain FAIL chain\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(1, chain, MRLIOU_MRL_TQ_CHAIN_MAX, &len) != MRLIOU_MRL_E_OK || len != 1 || chain[0] != 1){
        printf("GATE mrliou_mrl_trace_query_chain FAIL root_chain\n"); return 1; }
    if (mrliou_mrl_trace_query_find(99, &pa, &fp) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_trace_query_chain FAIL find_missing\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(99, chain, MRLIOU_MRL_TQ_CHAIN_MAX, &len) != MRLIOU_MRL_E_NOT_FOUND){
        printf("GATE mrliou_mrl_trace_query_chain FAIL chain_missing\n"); return 1; }
    if (mrliou_mrl_trace_query_add(2, 1, 0) != MRLIOU_MRL_E_DUP){ printf("GATE mrliou_mrl_trace_query_chain FAIL dup\n"); return 1; }
    if (mrliou_mrl_trace_query_add(0, 0, 0) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_trace_query_chain FAIL id0\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(3, chain, 1, &len) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_trace_query_chain FAIL cap\n"); return 1; }
    if (mrliou_mrl_trace_query_add(50, 99, 0) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_trace_query_chain FAIL forward_ref\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(50, chain, MRLIOU_MRL_TQ_CHAIN_MAX, &len) != MRLIOU_MRL_E_NOT_FOUND){
        printf("GATE mrliou_mrl_trace_query_chain FAIL incomplete_chain\n"); return 1; }
    if (mrliou_mrl_trace_query_reset() != MRLIOU_MRL_E_OK ||
        mrliou_mrl_trace_query_find(1, &pa, &fp) != MRLIOU_MRL_E_NOT_FOUND){
        printf("GATE mrliou_mrl_trace_query_chain FAIL reset\n"); return 1; }
    printf("GATE mrliou_mrl_trace_query_chain PASS (parent/child chain to root, find, dup/arg/cap, incomplete chain=not_found, reset)\n");
    return 0;
}
