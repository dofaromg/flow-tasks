#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_collapse_engine.h"
#include "mrliou_mrl/mrliou_mrl_collapse_search.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    if (mrliou_mrl_collapse_search_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL reset\n"); return 1; }
    int s = mrliou_mrl_collapse_search(1);
    if (s == MRLIOU_MRL_E_P1){ printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL still_E_P1\n"); return 1; }
    if (s != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL search\n"); return 1; }
    if (mrliou_mrl_collapse_search_query_count() < 1){ printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL delegation_proof\n"); return 1; }
    if (mrliou_mrl_collapse_search(0) != MRLIOU_MRL_E_ARG || mrliou_mrl_collapse_search(99) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL width_arg\n"); return 1; }
    mrliou_mrl_collapse_search_result_t r1, r2;
    uint64_t t1[MRLIOU_MRL_CSEARCH_CAND_MAX]; int l1 = 0;
    if (mrliou_mrl_collapse_engine_search_traced(99ULL, 5u, 4, &r1) != MRLIOU_MRL_E_OK || r1.count < 1 || r1.ranked != 1){
        printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL traced\n"); return 1; }
    if (mrliou_mrl_collapse_engine_search_traced(99ULL, 5u, 4, &r2) != MRLIOU_MRL_E_OK || memcmp(&r1, &r2, sizeof r1) != 0){
        printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL traced_determinism\n"); return 1; }
    if (mrliou_mrl_collapse_search_trace(&r1, t1, MRLIOU_MRL_CSEARCH_CAND_MAX, &l1) != MRLIOU_MRL_E_OK || l1 != r1.count){
        printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL result_traceable\n"); return 1; }
    if (mrliou_mrl_collapse_engine_search_traced(99ULL, 5u, 4, 0) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_collapse_engine_search_delegation FAIL null_out\n"); return 1; }
    printf("GATE mrliou_mrl_collapse_engine_search_delegation PASS (E_P1 retired, delegation proven by query_count, traced+deterministic)\n");
    return 0;
}
