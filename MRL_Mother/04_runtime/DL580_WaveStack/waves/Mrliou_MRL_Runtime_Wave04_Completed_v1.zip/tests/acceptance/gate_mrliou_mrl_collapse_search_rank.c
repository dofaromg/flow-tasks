#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_collapse_search.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint32_t ct[4] = {11, 22, 33, 44};
    mrliou_mrl_collapse_search_query_t q = {7ULL, 3ULL, 0, 0, ct, 4};
    mrliou_mrl_collapse_search_result_t r1, r2;
    uint64_t t1[MRLIOU_MRL_CSEARCH_CAND_MAX], t2[MRLIOU_MRL_CSEARCH_CAND_MAX];
    int l1 = 0, l2 = 0;
    if (mrliou_mrl_collapse_search_query(&q, &r1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_collapse_search_rank FAIL query\n"); return 1; }
    if (mrliou_mrl_collapse_search_rank(&r1) != MRLIOU_MRL_E_OK || r1.ranked != 1){ printf("GATE mrliou_mrl_collapse_search_rank FAIL rank\n"); return 1; }
    for (int i = 1; i < r1.count; i++){
        uint64_t sa = r1.score[r1.ranked_idx[i - 1]], sb = r1.score[r1.ranked_idx[i]];
        if (sa < sb){ printf("GATE mrliou_mrl_collapse_search_rank FAIL order\n"); return 1; }   /* 分數非遞增 */
    }
    mrliou_mrl_collapse_search_result_t rcopy = r1;
    if (mrliou_mrl_collapse_search_rank(&r1) != MRLIOU_MRL_E_OK || memcmp(&rcopy, &r1, sizeof r1) != 0){
        printf("GATE mrliou_mrl_collapse_search_rank FAIL idempotent\n"); return 1; }            /* rank 穩定 */
    if (mrliou_mrl_collapse_search_query(&q, &r2) != MRLIOU_MRL_E_OK || mrliou_mrl_collapse_search_rank(&r2) != MRLIOU_MRL_E_OK ||
        memcmp(&r1, &r2, sizeof r1) != 0){
        printf("GATE mrliou_mrl_collapse_search_rank FAIL stability\n"); return 1; }             /* 同入同序 */
    if (mrliou_mrl_collapse_search_trace(&r1, t1, MRLIOU_MRL_CSEARCH_CAND_MAX, &l1) != MRLIOU_MRL_E_OK || l1 != r1.count){
        printf("GATE mrliou_mrl_collapse_search_rank FAIL trace\n"); return 1; }
    if (t1[0] != r1.candidate_state[r1.ranked_idx[0]]){ printf("GATE mrliou_mrl_collapse_search_rank FAIL trace_path\n"); return 1; }
    if (mrliou_mrl_collapse_search_trace(&r1, t2, MRLIOU_MRL_CSEARCH_CAND_MAX, &l2) != MRLIOU_MRL_E_OK ||
        l2 != l1 || memcmp(t1, t2, sizeof(uint64_t) * (size_t)l1) != 0){
        printf("GATE mrliou_mrl_collapse_search_rank FAIL trace_determinism\n"); return 1; }
    if (mrliou_mrl_collapse_search_trace(&r1, t1, 2, &l1) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_collapse_search_rank FAIL trace_cap\n"); return 1; }
    if (mrliou_mrl_collapse_search_rank(0) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_collapse_search_rank FAIL arg\n"); return 1; }
    mrliou_mrl_collapse_search_result_t rz; memset(&rz, 0, sizeof rz);
    if (mrliou_mrl_collapse_search_rank(&rz) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_collapse_search_rank FAIL empty_bound\n"); return 1; }
    if (mrliou_mrl_collapse_search_trace(&rz, t1, 8, &l1) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_collapse_search_rank FAIL trace_empty\n"); return 1; }
    printf("GATE mrliou_mrl_collapse_search_rank PASS (score-desc stable rank, idempotent, ranked_path traceable, caps guarded)\n");
    return 0;
}
