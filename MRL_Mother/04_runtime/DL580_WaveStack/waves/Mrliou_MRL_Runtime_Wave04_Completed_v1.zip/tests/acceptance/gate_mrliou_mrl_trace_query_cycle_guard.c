#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_trace_query.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint64_t chain[MRLIOU_MRL_TQ_CHAIN_MAX + 2];
    int len = 0;
    if (mrliou_mrl_trace_query_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL init\n"); return 1; }
    if (mrliou_mrl_trace_query_add(5, 5, 0) != MRLIOU_MRL_E_CYCLE){ printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL self\n"); return 1; }
    if (mrliou_mrl_trace_query_add(10, 20, 0) != MRLIOU_MRL_E_OK ||
        mrliou_mrl_trace_query_add(20, 10, 0) != MRLIOU_MRL_E_OK){
        printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL build\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(10, chain, MRLIOU_MRL_TQ_CHAIN_MAX, &len) != MRLIOU_MRL_E_CYCLE){
        printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL cycle10\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(20, chain, MRLIOU_MRL_TQ_CHAIN_MAX, &len) != MRLIOU_MRL_E_CYCLE){
        printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL cycle20\n"); return 1; }
    /* 邊界: 鏈深 17 > 16 */
    if (mrliou_mrl_trace_query_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL reset\n"); return 1; }
    if (mrliou_mrl_trace_query_add(1, 0, 0) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL root\n"); return 1; }
    for (uint64_t i = 2; i <= 17; i++)
        if (mrliou_mrl_trace_query_add(i, i - 1, 0) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL chain_build\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(16, chain, MRLIOU_MRL_TQ_CHAIN_MAX, &len) != MRLIOU_MRL_E_OK || len != 16){
        printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL depth16\n"); return 1; }
    if (mrliou_mrl_trace_query_chain(17, chain, MRLIOU_MRL_TQ_CHAIN_MAX, &len) != MRLIOU_MRL_E_BOUNDARY){
        printf("GATE mrliou_mrl_trace_query_cycle_guard FAIL depth17_boundary\n"); return 1; }
    printf("GATE mrliou_mrl_trace_query_cycle_guard PASS (self/2-cycle=E_CYCLE, depth 16 ok, depth 17=E_BOUNDARY)\n");
    return 0;
}
