#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_search_index.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint8_t w[1] = {1};
    char key[24];
    mrliou_mrl_search_index_result_t s1, s2;
    if (mrliou_mrl_search_index_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_search_index_prefix FAIL setup\n"); return 1; }
    if (mrliou_mrl_search_index_add("idx:b", w, 1) != MRLIOU_MRL_E_OK ||
        mrliou_mrl_search_index_add("idx:a", w, 1) != MRLIOU_MRL_E_OK ||
        mrliou_mrl_search_index_add("zz", w, 1) != MRLIOU_MRL_E_OK){
        printf("GATE mrliou_mrl_search_index_prefix FAIL add\n"); return 1; }
    if (mrliou_mrl_search_index_prefix("idx:", &s1) != MRLIOU_MRL_E_OK || s1.count != 2 ||
        strcmp(s1.keys[0], "idx:a") != 0 || strcmp(s1.keys[1], "idx:b") != 0){
        printf("GATE mrliou_mrl_search_index_prefix FAIL order\n"); return 1; }
    if (mrliou_mrl_search_index_prefix("idx:", &s2) != MRLIOU_MRL_E_OK || memcmp(&s1, &s2, sizeof s1) != 0){
        printf("GATE mrliou_mrl_search_index_prefix FAIL determinism\n"); return 1; }
    if (mrliou_mrl_search_index_prefix("qq", &s1) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_search_index_prefix FAIL miss\n"); return 1; }
    if (mrliou_mrl_search_index_prefix("", &s1) != MRLIOU_MRL_E_ARG || mrliou_mrl_search_index_prefix("idx:", 0) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_search_index_prefix FAIL arg\n"); return 1; }
    for (int i = 0; i < 17; i++){
        snprintf(key, sizeof key, "p:%02d", i);
        if (mrliou_mrl_search_index_add(key, w, 1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_search_index_prefix FAIL bulk\n"); return 1; }
    }
    if (mrliou_mrl_search_index_prefix("p:", &s1) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_search_index_prefix FAIL overflow\n"); return 1; }
    printf("GATE mrliou_mrl_search_index_prefix PASS (ascending deterministic prefix, not_found, arg, >16 overflow=E_BOUNDARY)\n");
    return 0;
}
