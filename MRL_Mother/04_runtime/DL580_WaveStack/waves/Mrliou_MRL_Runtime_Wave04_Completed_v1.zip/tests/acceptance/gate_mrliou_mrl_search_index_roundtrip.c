#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_search_index.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    uint8_t w[4] = {1, 2, 3, 4}, w2[2] = {9, 9}, r[MRLIOU_MRL_SIDX_VAL_MAX]; uint64_t n = 0;
    char key[24];
    if (mrliou_mrl_search_index_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL init\n"); return 1; }
    if (mrliou_mrl_search_index_add("alpha", w, 4) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL add\n"); return 1; }
    if (mrliou_mrl_search_index_get("alpha", r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 4 || memcmp(w, r, 4) != 0){
        printf("GATE mrliou_mrl_search_index_roundtrip FAIL roundtrip\n"); return 1; }
    if (mrliou_mrl_search_index_add("alpha", w2, 2) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL dup_update\n"); return 1; }
    if (mrliou_mrl_search_index_get("alpha", r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 2 || memcmp(w2, r, 2) != 0){
        printf("GATE mrliou_mrl_search_index_roundtrip FAIL updated_val\n"); return 1; }
    if (mrliou_mrl_search_index_get("ghost", r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL not_found\n"); return 1; }
    if (mrliou_mrl_search_index_add("", w, 4) != MRLIOU_MRL_E_ARG || mrliou_mrl_search_index_add(0, w, 4) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_search_index_roundtrip FAIL key_arg\n"); return 1; }
    if (mrliou_mrl_search_index_add("big", w, (uint64_t)MRLIOU_MRL_SIDX_VAL_MAX + 1) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_search_index_roundtrip FAIL size\n"); return 1; }
    if (mrliou_mrl_search_index_get("alpha", r, 1, &n) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL cap\n"); return 1; }
    for (int i = 1; i < MRLIOU_MRL_SIDX_SLOTS; i++){                    /* alpha 占 1 槽,補滿至 64 */
        snprintf(key, sizeof key, "fill:%02d", i);
        if (mrliou_mrl_search_index_add(key, w, 1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL fill\n"); return 1; }
    }
    if (mrliou_mrl_search_index_add("overflow_key", w, 1) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL capacity\n"); return 1; }
    if (mrliou_mrl_search_index_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL reset\n"); return 1; }
    if (mrliou_mrl_search_index_get("alpha", r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_search_index_roundtrip FAIL reset_get\n"); return 1; }
    printf("GATE mrliou_mrl_search_index_roundtrip PASS (add/get, duplicate update, not_found, size/cap, 64-slot capacity, reset)\n");
    return 0;
}
