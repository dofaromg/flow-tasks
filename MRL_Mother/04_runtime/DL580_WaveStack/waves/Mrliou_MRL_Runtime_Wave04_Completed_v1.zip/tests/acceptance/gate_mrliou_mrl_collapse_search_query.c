#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_collapse_search.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    if (mrliou_mrl_collapse_search_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_collapse_search_query FAIL init\n"); return 1; }
    uint32_t mt[3] = {100, 200, 300}, ct[2] = {7, 8};
    mrliou_mrl_collapse_search_query_t q = {42ULL, 9ULL, mt, 3, ct, 2};
    mrliou_mrl_collapse_search_result_t r1, r2;
    if (mrliou_mrl_collapse_search_query(&q, &r1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_collapse_search_query FAIL query\n"); return 1; }
    if (r1.count < 4 || r1.count > MRLIOU_MRL_CSEARCH_CAND_MAX || r1.search_fp == 0){
        printf("GATE mrliou_mrl_collapse_search_query FAIL result_shape\n"); return 1; }
    if (mrliou_mrl_collapse_search_query(&q, &r2) != MRLIOU_MRL_E_OK || memcmp(&r1, &r2, sizeof r1) != 0){
        printf("GATE mrliou_mrl_collapse_search_query FAIL determinism\n"); return 1; }
    mrliou_mrl_collapse_search_query_t q3 = {43ULL, 9ULL, mt, 3, ct, 2};
    mrliou_mrl_collapse_search_result_t r3;
    if (mrliou_mrl_collapse_search_query(&q3, &r3) != MRLIOU_MRL_E_OK || r3.search_fp == r1.search_fp){
        printf("GATE mrliou_mrl_collapse_search_query FAIL seed_sensitivity\n"); return 1; }
    mrliou_mrl_collapse_search_query_t qe = {1ULL, 1ULL, 0, 0, 0, 0};
    if (mrliou_mrl_collapse_search_query(&qe, &r1) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_collapse_search_query FAIL empty_query\n"); return 1; }
    mrliou_mrl_collapse_search_query_t qm = {1ULL, 1ULL, 0, 3, ct, 2};
    if (mrliou_mrl_collapse_search_query(&qm, &r1) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_collapse_search_query FAIL missing_memtrace\n"); return 1; }
    mrliou_mrl_collapse_search_query_t qc = {1ULL, 1ULL, mt, 3, 0, 2};
    if (mrliou_mrl_collapse_search_query(&qc, &r1) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_collapse_search_query FAIL missing_ctrace\n"); return 1; }
    mrliou_mrl_collapse_search_query_t qb = {1ULL, 1ULL, mt, 65, ct, 2};
    if (mrliou_mrl_collapse_search_query(&qb, &r1) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_collapse_search_query FAIL boundary\n"); return 1; }
    if (mrliou_mrl_collapse_search_query(0, &r1) != MRLIOU_MRL_E_ARG || mrliou_mrl_collapse_search_query(&q, 0) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_collapse_search_query FAIL arg\n"); return 1; }
    if (mrliou_mrl_collapse_search_query_count() < 3){ printf("GATE mrliou_mrl_collapse_search_query FAIL count\n"); return 1; }
    if (mrliou_mrl_collapse_search_reset() != MRLIOU_MRL_E_OK || mrliou_mrl_collapse_search_query_count() != 0){
        printf("GATE mrliou_mrl_collapse_search_query FAIL reset\n"); return 1; }
    printf("GATE mrliou_mrl_collapse_search_query PASS (deterministic result+fp, empty=E_ARG, missing trace=E_NOT_FOUND, boundary, reset)\n");
    return 0;
}
