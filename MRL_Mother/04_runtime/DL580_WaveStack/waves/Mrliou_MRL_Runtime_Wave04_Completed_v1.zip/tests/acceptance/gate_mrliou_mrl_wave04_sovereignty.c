#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_law.h"
int main(void){
    static const char *canonical[25] = {
        "Mrliou_MRL_Fluin", "Mrliou_MRL_Kernel", "Mrliou_MRL_Compiler", "Mrliou_MRL_Engine",
        "Mrliou_MRL_Runtime", "Mrliou_MRL_FlowAgent", "Mrliou_MRL_CollapseEngine",
        "Mrliou_MRL_WeightSystem", "Mrliou_MRL_Optimizer", "Mrliou_MRL_Runtime_Core_Assembly",
        "Mrliou_MRL_MemoryLayer", "Mrliou_MRL_MemoryOS", "Mrliou_MRL_MemoryCube", "Mrliou_MRL_MemoryVault",
        "Mrliou_MRL_Database", "Mrliou_MRL_Serializer", "Mrliou_MRL_Search", "Mrliou_MRL_Memory_Runtime_Assembly",
        "Mrliou_MRL_Guardian", "Mrliou_MRL_Validator", "Mrliou_MRL_Guardian_Runtime_Assembly",
        "Mrliou_MRL_Collapse_Search", "Mrliou_MRL_Search_Index", "Mrliou_MRL_Trace_Query",
        "Mrliou_MRL_Collapse_Search_Runtime_Assembly"
    };
    for (int i = 0; i < 25; i++){
        if (mrliou_mrl_law_check_module_name(canonical[i]) != 0){
            printf("GATE mrliou_mrl_wave04_sovereignty FAIL canonical %d\n", i); return 1; }
    }
    static const char *illegal[6] = {
        "Collapse_Search", "Search_Index", "Google_Search", "External_Trace_Query", "GitHub_Index", "OpenAI_Rank"
    };
    for (int i = 0; i < 6; i++){
        if (mrliou_mrl_law_check_module_name(illegal[i]) == 0){
            printf("GATE mrliou_mrl_wave04_sovereignty FAIL illegal %d\n", i); return 1; }
    }
    if (strncmp(MRLIOU_MRL_WAVE04_VERSION, "Mrliou_MRL_", 11) != 0){
        printf("GATE mrliou_mrl_wave04_sovereignty FAIL version_name\n"); return 1; }
    if (mrliou_mrl_law_verify("MrLiouWord") != MRLIOU_MRL_GATE_ALLOW){
        printf("GATE mrliou_mrl_wave04_sovereignty FAIL origin\n"); return 1; }
    if (mrliou_mrl_law_check_runtime_flag(1) != 0 || mrliou_mrl_law_check_runtime_flag(0) == 0){
        printf("GATE mrliou_mrl_wave04_sovereignty FAIL flag\n"); return 1; }
    if (mrliou_mrl_law_check_wave_boundary(4, 5) != 0 || mrliou_mrl_law_check_wave_boundary(3, 5) != -1){
        printf("GATE mrliou_mrl_wave04_sovereignty FAIL wave_boundary\n"); return 1; }
    printf("GATE mrliou_mrl_wave04_sovereignty PASS (25 canonical legal incl W4, bare/external blocked, seal name sovereign, wave boundary)\n");
    return 0;
}
