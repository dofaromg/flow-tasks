#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_collapse_search_runtime_assembly.h"
int main(void){
    mrliou_mrl_collapse_search_assembly_report_t rep;
    if (mrliou_mrl_collapse_search_runtime_assembly_boot(&rep) != 0){ printf("GATE mrliou_mrl_collapse_search_runtime_assembly FAIL boot\n"); return 1; }
    if (rep.trace_len != MRLIOU_MRL_CS_ASM_STAGES){ printf("GATE mrliou_mrl_collapse_search_runtime_assembly FAIL trace_len\n"); return 1; }
    static const char *expect[MRLIOU_MRL_CS_ASM_STAGES] = {
        "Mrliou_MRL_Collapse_Search:", "Mrliou_MRL_Search_Index", "Mrliou_MRL_Trace_Query",
        "Mrliou_MRL_Collapse_Search_Runtime_Assembly"
    };
    for (int i = 0; i < MRLIOU_MRL_CS_ASM_STAGES; i++){
        if (!strstr(rep.collapse_search_trace[i], expect[i])){
            printf("GATE mrliou_mrl_collapse_search_runtime_assembly FAIL stage %d\n", i); return 1; }
    }
    if (!rep.collapse_search_status || !strstr(rep.collapse_search_status, "wave04_closed") ||
        !strstr(rep.collapse_search_status, "runtime_not_complete=true")){
        printf("GATE mrliou_mrl_collapse_search_runtime_assembly FAIL status\n"); return 1; }
    if (!rep.remaining_wave05_hooks || !strstr(rep.remaining_wave05_hooks, "wave05")){
        printf("GATE mrliou_mrl_collapse_search_runtime_assembly FAIL hooks\n"); return 1; }
    if (mrliou_mrl_collapse_search_runtime_assembly_boot(0) != 0){ printf("GATE mrliou_mrl_collapse_search_runtime_assembly FAIL null_out\n"); return 1; }
    printf("GATE mrliou_mrl_collapse_search_runtime_assembly PASS (4-stage smoke path, status sealed, wave05 hooks declared)\n");
    return 0;
}
