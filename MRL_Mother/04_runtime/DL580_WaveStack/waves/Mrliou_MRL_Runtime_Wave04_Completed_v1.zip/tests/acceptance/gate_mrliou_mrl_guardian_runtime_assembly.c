#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_guardian_runtime_assembly.h"
int main(void){
    mrliou_mrl_guardian_assembly_report_t rep;
    if (mrliou_mrl_guardian_runtime_assembly_boot(&rep) != 0){ printf("GATE mrliou_mrl_guardian_runtime_assembly FAIL boot\n"); return 1; }
    if (rep.trace_len != MRLIOU_MRL_GRD_ASM_STAGES){ printf("GATE mrliou_mrl_guardian_runtime_assembly FAIL trace_len\n"); return 1; }
    static const char *expect[MRLIOU_MRL_GRD_ASM_STAGES] = {
        "Mrliou_MRL_Guardian:", "Mrliou_MRL_Validator", "Mrliou_MRL_LAW_Verify", "Mrliou_MRL_Guardian_Runtime_Assembly"
    };
    for (int i = 0; i < MRLIOU_MRL_GRD_ASM_STAGES; i++){
        if (!strstr(rep.guardian_trace[i], expect[i])){
            printf("GATE mrliou_mrl_guardian_runtime_assembly FAIL stage %d\n", i); return 1; }
    }
    if (!rep.guardian_status || !strstr(rep.guardian_status, "wave03_closed") ||
        !strstr(rep.guardian_status, "runtime_not_complete=true")){
        printf("GATE mrliou_mrl_guardian_runtime_assembly FAIL status\n"); return 1; }
    if (!rep.validation_status || !strstr(rep.validation_status, "validator_active")){
        printf("GATE mrliou_mrl_guardian_runtime_assembly FAIL validation\n"); return 1; }
    if (!rep.remaining_wave04_hooks || !strstr(rep.remaining_wave04_hooks, "wave04") ||
        !strstr(rep.remaining_wave04_hooks, "wave05")){
        printf("GATE mrliou_mrl_guardian_runtime_assembly FAIL hooks\n"); return 1; }
    if (mrliou_mrl_guardian_runtime_assembly_boot(0) != 0){ printf("GATE mrliou_mrl_guardian_runtime_assembly FAIL null_out\n"); return 1; }
    printf("GATE mrliou_mrl_guardian_runtime_assembly PASS (4-stage smoke path, status sealed, wave04_completed+wave05 hooks declared)\n");
    return 0;
}
