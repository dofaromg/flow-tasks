#ifndef MRLIOU_MRL_SEARCH_INDEX_H
#define MRLIOU_MRL_SEARCH_INDEX_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Search_Index | Wave_04 搜尋索引層
 * process-local / deterministic order / no external DB;duplicate add = 更新;容量檢查。 */
#define MRLIOU_MRL_SIDX_SLOTS   64
#define MRLIOU_MRL_SIDX_KEY_MAX 48
#define MRLIOU_MRL_SIDX_VAL_MAX 128
#define MRLIOU_MRL_SIDX_RESULT_MAX 16
typedef struct {
    char keys[MRLIOU_MRL_SIDX_RESULT_MAX][MRLIOU_MRL_SIDX_KEY_MAX];
    int count;
} mrliou_mrl_search_index_result_t;
int mrliou_mrl_search_index_init(void);
int mrliou_mrl_search_index_add(const char *key, const void *val, uint64_t n);   /* 重複 key = 更新 */
int mrliou_mrl_search_index_get(const char *key, void *buf, uint64_t cap, uint64_t *out_n);
int mrliou_mrl_search_index_prefix(const char *prefix, mrliou_mrl_search_index_result_t *out); /* key 升冪 */
int mrliou_mrl_search_index_reset(void);
#endif
