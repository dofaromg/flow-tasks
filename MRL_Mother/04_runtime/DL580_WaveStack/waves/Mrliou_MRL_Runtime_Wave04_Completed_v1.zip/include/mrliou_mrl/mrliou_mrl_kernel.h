#ifndef MRLIOU_MRL_KERNEL_H
#define MRLIOU_MRL_KERNEL_H
#include <stdint.h>
#include "mrliou_mrl/mrliou_mrl_fluin.h"
/* canonical_name: Mrliou_MRL_Kernel | 認知核:latent + Δ 追蹤(LAW-3)+ origin_signature(LAW-0) */
#define MRLIOU_MRL_E_OK         0
#define MRLIOU_MRL_E_LAW       -1
#define MRLIOU_MRL_E_WAVE02    -2   /* 邊界標記(歷史;W2 已落地) */
#define MRLIOU_MRL_E_NOT_FOUND -3
#define MRLIOU_MRL_E_ARG       -4
#define MRLIOU_MRL_E_DUP       -5
#define MRLIOU_MRL_E_MALFORMED -6
#define MRLIOU_MRL_E_FORBIDDEN -7
#define MRLIOU_MRL_E_BOUNDARY  -8
#define MRLIOU_MRL_E_CYCLE     -9
#define MRLIOU_MRL_E_P1      -100
/* MemIO(W1 contract): key≤31 / val≤256;W2 起儲存委派 Mrliou_MRL_MemoryLayer(canonical 記憶層)。
 * 不接外部 Storage / 不接 network。 */
#define MRLIOU_MRL_MEMIO_KEY_MAX 32
#define MRLIOU_MRL_MEMIO_VAL_MAX 256
#define MRLIOU_MRL_MEMIO_SLOTS   64
typedef struct {
    mrliou_mrl_fluin_vec_t latent;   /* Mrliou_MRL_Kernel_LatentState */
    uint64_t delta_count;            /* LAW-3 */
    char origin_signature[16];       /* LAW-0 */
} mrliou_mrl_kernel_t;
int mrliou_mrl_kernel_init(mrliou_mrl_kernel_t *k);
int mrliou_mrl_kernel_step(mrliou_mrl_kernel_t *k, const mrliou_mrl_fluin_vec_t *input);
int mrliou_mrl_kernel_memio_write(mrliou_mrl_kernel_t *k, const char *key, const void *buf, uint64_t n);
int mrliou_mrl_kernel_memio_read (mrliou_mrl_kernel_t *k, const char *key, void *buf, uint64_t cap, uint64_t *out_n);
#endif
