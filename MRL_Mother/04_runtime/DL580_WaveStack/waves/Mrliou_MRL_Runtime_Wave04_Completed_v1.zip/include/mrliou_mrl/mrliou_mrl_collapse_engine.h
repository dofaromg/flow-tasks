#ifndef MRLIOU_MRL_COLLAPSE_ENGINE_H
#define MRLIOU_MRL_COLLAPSE_ENGINE_H
#include <stdint.h>
#include "mrliou_mrl/mrliou_mrl_collapse_search.h"
/* canonical_name: Mrliou_MRL_CollapseEngine | 世界模型(內可逆坑縮/外不可逆)。
 * Wave_01 補滿: deterministic skeleton imagine(seed+context → imagined_state + collapse_trace)。
 * scope=skeleton_imagination — 不聲稱真正推理完成;trace 可回放(LAW-2 對照)。
 * Wave_04: collapse_search 已退役 E_P1 → 委派 Mrliou_MRL_Collapse_Search(結果可 trace)。 */
#define MRLIOU_MRL_COLLAPSE_TRACE_MAX 16
typedef struct {
    uint64_t imagined_state;
    uint32_t collapse_trace[MRLIOU_MRL_COLLAPSE_TRACE_MAX];
    int trace_len;
    const char *scope;   /* = "skeleton_imagination" */
} mrliou_mrl_collapse_result_t;
int mrliou_mrl_collapse_imagine(uint64_t seed, uint32_t context, int depth, mrliou_mrl_collapse_result_t *out);
int mrliou_mrl_collapse_search (int width);   /* W4: 委派 Mrliou_MRL_Collapse_Search(不再回 E_P1) */
int mrliou_mrl_collapse_engine_search_traced(uint64_t seed, uint32_t context, int width, mrliou_mrl_collapse_search_result_t *out);
#endif
