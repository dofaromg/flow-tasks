#ifndef MRLIOU_MRL_TRACE_QUERY_H
#define MRLIOU_MRL_TRACE_QUERY_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Trace_Query | Wave_04 軌跡鏈查詢層
 * parent/child 關係;chain=沿 parent 走至 root(parent_id=0);deterministic。
 * 錯誤: E_ARG/E_DUP/E_NOT_FOUND(缺節點或鏈不完整)/E_CYCLE(環防護)/E_BOUNDARY(鏈深>16)。 */
#define MRLIOU_MRL_TQ_SLOTS     64
#define MRLIOU_MRL_TQ_CHAIN_MAX 16
int mrliou_mrl_trace_query_init(void);
int mrliou_mrl_trace_query_add(uint64_t trace_id, uint64_t parent_id, uint64_t payload_fp); /* id!=0;前向引用合法 */
int mrliou_mrl_trace_query_find(uint64_t trace_id, uint64_t *out_parent, uint64_t *out_fp);
int mrliou_mrl_trace_query_chain(uint64_t trace_id, uint64_t *out_chain, int cap, int *out_len);
int mrliou_mrl_trace_query_reset(void);
#endif
