#ifndef MRLIOU_MRL_COLLAPSE_SEARCH_RUNTIME_ASSEMBLY_H
#define MRLIOU_MRL_COLLAPSE_SEARCH_RUNTIME_ASSEMBLY_H
/* canonical_name: Mrliou_MRL_Collapse_Search_Runtime_Assembly | Wave_04 搜尋組裝 smoke path
 * Collapse_Search → Search_Index → Trace_Query → Collapse_Search_Runtime_Assembly */
#define MRLIOU_MRL_CS_ASM_STAGES 4
typedef struct {
    char collapse_search_trace[MRLIOU_MRL_CS_ASM_STAGES][56];
    int  trace_len;
    const char *collapse_search_status;
    const char *remaining_wave05_hooks;
} mrliou_mrl_collapse_search_assembly_report_t;
int mrliou_mrl_collapse_search_runtime_assembly_boot(mrliou_mrl_collapse_search_assembly_report_t *out); /* out 可為 NULL */
#endif
