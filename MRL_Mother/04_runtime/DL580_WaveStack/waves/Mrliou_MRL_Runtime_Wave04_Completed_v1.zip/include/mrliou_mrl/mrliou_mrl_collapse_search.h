#ifndef MRLIOU_MRL_COLLAPSE_SEARCH_H
#define MRLIOU_MRL_COLLAPSE_SEARCH_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Collapse_Search | Wave_04 坍縮搜尋核(E_P1 正式退役)
 * deterministic / no network / no external model / no external search。
 * 輸入: seed/context/memory_trace/collapse_trace;輸出: search_result/ranked_path/trace。
 * 空查詢=E_ARG;宣告長度>0 但軌跡缺失=E_NOT_FOUND;越界=E_BOUNDARY;rank 穩定。 */
#define MRLIOU_MRL_CSEARCH_CAND_MAX     8
#define MRLIOU_MRL_CSEARCH_MEMTRACE_MAX 64
#define MRLIOU_MRL_CSEARCH_CTRACE_MAX   16
typedef struct {
    uint64_t seed;
    uint64_t context;
    const uint32_t *memory_trace;     /* 例: Mrliou_MRL_MemoryCube trace */
    int memory_trace_len;
    const uint32_t *collapse_trace;   /* 例: Mrliou_MRL_CollapseEngine imagine trace */
    int collapse_trace_len;
} mrliou_mrl_collapse_search_query_t;
typedef struct {
    uint64_t candidate_state[MRLIOU_MRL_CSEARCH_CAND_MAX];   /* search_result */
    uint64_t score[MRLIOU_MRL_CSEARCH_CAND_MAX];
    int      ranked_idx[MRLIOU_MRL_CSEARCH_CAND_MAX];        /* ranked_path(索引) */
    int      count;
    int      ranked;
    uint64_t search_fp;
} mrliou_mrl_collapse_search_result_t;
int mrliou_mrl_collapse_search_init(void);
int mrliou_mrl_collapse_search_query(const mrliou_mrl_collapse_search_query_t *q, mrliou_mrl_collapse_search_result_t *out);
int mrliou_mrl_collapse_search_rank(mrliou_mrl_collapse_search_result_t *r);    /* 分數降冪;平手 state 升冪;穩定 */
int mrliou_mrl_collapse_search_trace(const mrliou_mrl_collapse_search_result_t *r, uint64_t *out_trace, int cap, int *out_len);
int mrliou_mrl_collapse_search_reset(void);
uint64_t mrliou_mrl_collapse_search_query_count(void);
#endif
