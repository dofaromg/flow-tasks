#ifndef MRLIOU_MRL_LAW_H
#define MRLIOU_MRL_LAW_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_LAW_Interface | origin_signature: MrLiouWord
 * Wave_03 起: LAW_Verify = Guardian-backed gate(治理檢查委派 Mrliou_MRL_Guardian;
 * schema/payload 檢查委派 Mrliou_MRL_Validator)。介面回傳語義不變(W1/W2 gate 不破壞)。 */
#define MRLIOU_MRL_ORIGIN_SIGNATURE "MrLiouWord"
#define MRLIOU_MRL_WAVE01_VERSION   "MRL_Runtime_Wave01_v1.0"   /* W1 封版標籤(lineage) */
#define MRLIOU_MRL_WAVE02_VERSION   "Mrliou_MRL_Runtime_Wave02_v1.0"
#define MRLIOU_MRL_WAVE03_VERSION   "Mrliou_MRL_Runtime_Wave03_v1.0"
#define MRLIOU_MRL_WAVE04_VERSION   "Mrliou_MRL_Runtime_Wave04_v1.0"
typedef enum { MRLIOU_MRL_GATE_ALLOW = 0, MRLIOU_MRL_GATE_BLOCK = 1 } mrliou_mrl_gate_t;
/* LAW-0: origin 驗證(委派 Guardian) */
mrliou_mrl_gate_t mrliou_mrl_law_verify(const char *origin_signature);
/* 繼承律命名檢查(委派 Guardian)。0=合法, -1=違規 */
int mrliou_mrl_law_check_module_name(const char *module_name);
/* runtime_not_complete 旗標保護(委派 Guardian)。0=合法, -1=違規 */
int mrliou_mrl_law_check_runtime_flag(int runtime_not_complete_flag);
/* wave 邊界(委派 Guardian)。ALLOWED/WARNING=0;BLOCKED/E_ARG=-1 */
int mrliou_mrl_law_check_wave_boundary(int wave_completed, int wave_requested);
/* 外部升格(委派 Guardian)。ALLOWED/WARNING=0;BLOCKED/E_ARG=-1 */
int mrliou_mrl_law_check_external_escalation(const char *actor_name, int requested_authority);
/* atom payload 驗證(委派 Validator)。回傳 Validator 錯誤碼 */
int mrliou_mrl_law_validate_atom_payload(const void *buf, uint64_t n);
#endif
