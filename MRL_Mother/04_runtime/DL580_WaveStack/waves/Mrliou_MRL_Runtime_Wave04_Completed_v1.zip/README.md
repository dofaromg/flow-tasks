# Mrliou_MRL_Runtime - Mrliou_MRL_Runtime_Wave04_v1.0
origin_signature: MrLiouWord
status: wave04_closed
runtime_scope: collapse_search_foundation_completed
runtime_not_complete: true
wave05_required: true
sovereignty: 全部正式節點/介面/檔案/Gate/契約/Manifest = Mrliou_MRL_ 主權命名;外部主權名僅存 deny-list;舊名僅存 legacy_alias/lineage_ref
build: make clean && make && make gates   (=> ALL GATES PASS)

## Changelog
- Wave04 v1.0 (2026-06-11) Wave04 Collapse Search Foundation Completion:
  - collapse_search 正式退役 E_P1(全 tree 無使用點)→ CollapseEngine 委派 Mrliou_MRL_Collapse_Search;新增 traced 介面(結果可回放);Imagine skeleton 不變
  - Mrliou_MRL_Collapse_Search: 確定性搜尋核(seed/context/memory_trace/collapse_trace → 4..8 候選+search_fp;rank 穩定排序;ranked_path 可 trace;空查詢/缺軌跡/越界三類錯誤)
  - Mrliou_MRL_Search_Index: 搜尋索引層(add/get/prefix;重複=更新;64 槽容量檢查;key 升冪確定序;>16=E_BOUNDARY)
  - Mrliou_MRL_Trace_Query: 軌跡鏈查詢(parent/child;chain 至 root;自指/環=E_CYCLE 新增 -9;鏈深>16=E_BOUNDARY;前向引用+鏈不完整=E_NOT_FOUND)
  - Mrliou_MRL_Collapse_Search_Runtime_Assembly: 4 階段 smoke(真實 MemoryCube trace + Imagine trace 輸入;索引入庫;search_fp 為 root 之 ranked 鏈)
  - Runtime boot: 四組裝接線(Core→Memory→Guardian→CollapseSearch);三組裝 hooks 宣告 wave04_completed
  - gates: 30 → 39(新增 9;補強 collapse_imagine/core_assembly/guardian_assembly/law_struct;原 30 全保留)
- Wave03 v1.0 (2026-06-11) Wave03 Guardian Foundation Completion: Guardian/Validator/LAW 接管/Guardian_Runtime_Assembly;錯誤碼 +E_MALFORMED/E_FORBIDDEN/E_BOUNDARY;gates 20→30
- Wave02 v1.0 (2026-06-11) Wave02 Memory Foundation Completion: MemoryLayer/MemoryOS/MemoryCube/MemoryVault/Database/Serializer/Search/Memory_Runtime_Assembly;Kernel_MemIO 委派;主權命名回歸;gates 11→20
- Wave01 v1.0 (2026-06-11) Wave01 Completion: Kernel_MemIO(W1 暫存)/FlowAgent_Decide/CollapseEngine_Imagine/Optimizer_Pass/LAW 補強/Assembly 10 階段;gates 6→11(seal: MRL_Runtime_Wave01_v1.0;lineage)
- v0.9 (2026-06-11) Wave01 skeleton baseline(6 gates)
