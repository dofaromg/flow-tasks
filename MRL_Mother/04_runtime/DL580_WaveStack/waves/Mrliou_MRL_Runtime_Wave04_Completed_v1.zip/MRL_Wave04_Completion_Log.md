
## STEPS 1–10 — 執行紀錄
- STEP 1 Mrliou_MRL_Collapse_Search: query(輸入 seed/context/memory_trace/collapse_trace → 4..8 候選+score+search_fp;空查詢=E_ARG;宣告長度>0 但軌跡缺失=E_NOT_FOUND;越界=E_BOUNDARY)/rank(分數降冪、平手 state 升冪再索引升冪;插入排序=穩定、冪等)/trace(ranked_path 可回放;cap 防護)/reset(query_count 可驗);deterministic/無網路/無外部模型/無外部搜尋
- STEP 2 Mrliou_MRL_Search_Index: 64 槽 key<48/val 1..128;add 重複 key=更新、容量滿=E_ARG;get missing=E_NOT_FOUND;prefix key 升冪確定序、0 匹配=E_NOT_FOUND、>16=E_BOUNDARY;process-local 無外部 DB
- STEP 3 Mrliou_MRL_Trace_Query: 64 槽 {id,parent,fp};id!=0;自指=E_CYCLE(kernel.h 新增 -9);dup=E_DUP;前向引用合法;chain 沿 parent 走至 root(0);環防護=E_CYCLE;鏈深>16=E_BOUNDARY;缺節點/鏈不完整=E_NOT_FOUND
- STEP 4 Mrliou_MRL_Collapse_Search_Runtime_Assembly: LAW 前置門(Guardian-backed)+ 4 階段(Collapse_Search→Search_Index→Trace_Query→SEAL);輸入採真實 MemoryCube trace + CollapseEngine imagine trace;ranked path 入索引(cs:cand:*);search_fp 為 root 之 ranked 鏈;確定性 re-run memcmp;輸出 collapse_search_trace/collapse_search_status/remaining_wave05_hooks
- STEP 5 CollapseEngine 接回: E_P1 一行正式移除;mrliou_mrl_collapse_search(width)=委派包裝(width 1..16 否則 E_ARG;imagine trace 為輸入);新增 mrliou_mrl_collapse_engine_search_traced(結果可 trace、deterministic);CollapseEngine_Imagine skeleton 不變
- STEP 6 接線: main 四組裝(Core→Memory→Guardian→CollapseSearch);core/memory/guardian 三組裝 hooks 宣告 wave04_completed(guardian 並宣告 wave05 待辦);W1/W2/W3 path 全保留
- STEP 7 契約: 新增 mrliou_mrl_wave04_contracts.yaml(collapse_search/search_index/trace_query/cs_assembly 四契約+collapse_engine_delegation+wave05_boundary+runtime_not_complete_policy;error_codes 註記 E_P1 已無使用點);wave03 契約僅追加 wave04_completed note(append-only)
- STEP 8 Gates: 新增 9(collapse_search_query/rank、search_index_roundtrip/prefix、trace_query_chain/cycle_guard、collapse_engine_search_delegation、collapse_search_runtime_assembly、wave04_sovereignty 25 canonical);補強 4(collapse_imagine_deterministic、runtime_core_assembly_wave01、guardian_runtime_assembly + law_struct 因 E_P1 退役強制同步);總 39;無永遠 PASS
- STEP 9 文件: README 封版 wave04_closed/collapse_search_foundation_completed/runtime_not_complete=true/wave05_required=true + changelog;Makefile 26 OBJ/39 GATES;law.h +WAVE04 版本
- STEP 10 驗收: make clean && make && make gates = 39/39 + ALL GATES PASS;-std=c11 -Wall -Wextra 零警告;原 30 gates 全保留全通過;E_P1 殘留掃描=0 使用點(僅 kernel.h 定義保留為 lineage)

## Gate 結果(實跑 2026-06-11)
GATE mrliou_mrl_fluin_reversibility PASS (1000/1000 unbind(bind(x))==x)
GATE mrliou_mrl_kernel_delta_chain PASS (5 steps, delta=5, origin=MrLiouWord, memio not_found semantics)
GATE mrliou_mrl_kernel_memio_roundtrip PASS (roundtrip, empty/null key, not_found, size+cap checks, overwrite)
GATE mrliou_mrl_compiler_roundtrip PASS (5 atoms x 40B, compile<->decompile lossless, crc verified)
GATE mrliou_mrl_engine_genesis PASS (P_{k+1}=N*P*eta reproducible, delta tracked)
GATE mrliou_mrl_runtime_lifecycle PASS (init->run->suspend->resume->halt; illegal blocked)
GATE mrliou_mrl_flowagent_decide_deterministic PASS (same-in same-out, route in mask, confidence 0..65536, no-route case)
GATE mrliou_mrl_collapse_imagine_deterministic PASS (deterministic state+trace, scope=skeleton_imagination, clamp, search delegated W4)
GATE mrliou_mrl_optimizer_pass_stable PASS (required preserved, redundant folded, deterministic, idempotent, provenance kept)
GATE mrliou_mrl_law_struct PASS (atom=40B, guardian-backed origin/naming/flag/wave/escalation, sum=10.0, W4 search delegated)
GATE mrliou_mrl_runtime_core_assembly_wave01 PASS (10-stage smoke path ordered, status sealed, W2-W4 hooks declared)
GATE mrliou_mrl_memorylayer_roundtrip PASS (roundtrip, exists/delete, not_found, empty/null key, size+cap, reset)
GATE mrliou_mrl_memoryos_namespace PASS (create/lookup/delete, dup=E_DUP, not_found, size check, deterministic id)
GATE mrliou_mrl_memorycube_store_fetch PASS (store/fetch, boundary, deterministic ascending trace, reset)
GATE mrliou_mrl_memoryvault_archive_restore PASS (archive/restore, deterministic manifest, origin preserved, reset)
GATE mrliou_mrl_database_roundtrip PASS (put/get/delete, ascending iterate, early-stop, null cb, reset)
GATE mrliou_mrl_serializer_roundtrip PASS (atom 60B frame, memrec, cubeobj roundtrip; crc/truncate/magic/size guarded)
GATE mrliou_mrl_search_lookup PASS (exact/prefix/namespace, ascending order, not_found, arg checks, reset)
GATE mrliou_mrl_memory_runtime_assembly PASS (8-stage smoke path ordered, status sealed, W3 hooks declared)
GATE mrliou_mrl_sovereignty_naming_wave02 PASS (21 canonical legal incl W3, bare/external/brand blocked, seal names sovereign)
GATE mrliou_mrl_guardian_origin PASS (MrLiouWord allowed, foreign/brand blocked, arg guarded, audit count+reset)
GATE mrliou_mrl_guardian_sovereignty_name PASS (Mrliou_MRL_ allowed; bare/MRL_/External_/brand names blocked)
GATE mrliou_mrl_guardian_runtime_flag PASS (flag=1 only; tamper blocked; wave next/reentry/jump = allowed/warning/blocked)
GATE mrliou_mrl_guardian_external_escalation PASS (internal allowed; external observe/execute/canonical = allowed/warning/BLOCKED)
GATE mrliou_mrl_validator_atom PASS (40B size boundary, magic/type/crc malformed detection)
GATE mrliou_mrl_validator_memory_record PASS (schema ok; empty/no-nul key=malformed; len 0/257=boundary)
GATE mrliou_mrl_validator_cube_object PASS (coordinate/payload boundary checks, arg guarded)
GATE mrliou_mrl_validator_contract PASS (required/forbidden/not_found split; runtime_state ok/forbidden/boundary)
GATE mrliou_mrl_law_guardian_backed PASS (LAW delegates Guardian: origin/name/flag/wave/escalation; delegates Validator: payload)
GATE mrliou_mrl_guardian_runtime_assembly PASS (4-stage smoke path, status sealed, wave04_completed+wave05 hooks declared)
GATE mrliou_mrl_collapse_search_query PASS (deterministic result+fp, empty=E_ARG, missing trace=E_NOT_FOUND, boundary, reset)
GATE mrliou_mrl_collapse_search_rank PASS (score-desc stable rank, idempotent, ranked_path traceable, caps guarded)
GATE mrliou_mrl_search_index_roundtrip PASS (add/get, duplicate update, not_found, size/cap, 64-slot capacity, reset)
GATE mrliou_mrl_search_index_prefix PASS (ascending deterministic prefix, not_found, arg, >16 overflow=E_BOUNDARY)
GATE mrliou_mrl_trace_query_chain PASS (parent/child chain to root, find, dup/arg/cap, incomplete chain=not_found, reset)
GATE mrliou_mrl_trace_query_cycle_guard PASS (self/2-cycle=E_CYCLE, depth 16 ok, depth 17=E_BOUNDARY)
GATE mrliou_mrl_collapse_engine_search_delegation PASS (E_P1 retired, delegation proven by query_count, traced+deterministic)
GATE mrliou_mrl_collapse_search_runtime_assembly PASS (4-stage smoke path, status sealed, wave05 hooks declared)
GATE mrliou_mrl_wave04_sovereignty PASS (25 canonical legal incl W4, bare/external blocked, seal name sovereign, wave boundary)
ALL GATES PASS
