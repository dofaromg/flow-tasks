#include <string.h>
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
int mrliou_mrl_kernel_init(mrliou_mrl_kernel_t *k){
    if (!k) return MRLIOU_MRL_E_ARG;
    memset(&k->latent, 0, sizeof k->latent);
    k->delta_count = 0;
    memset(k->origin_signature, 0, sizeof k->origin_signature);
    strncpy(k->origin_signature, MRLIOU_MRL_ORIGIN_SIGNATURE, sizeof k->origin_signature - 1);
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_kernel_step(mrliou_mrl_kernel_t *k, const mrliou_mrl_fluin_vec_t *input){
    if (!k || !input) return MRLIOU_MRL_E_ARG;
    if (mrliou_mrl_law_verify(k->origin_signature) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    mrliou_mrl_fluin_vec_t next;
    mrliou_mrl_fluin_bind(&k->latent, input, &next); /* 可逆變換骨架 */
    k->latent = next;
    k->delta_count++; /* LAW-3 */
    return MRLIOU_MRL_E_OK;
}
/* ---- Wave_01 MemIO: process-local static KV(不接 DB/MemoryLayer/外部 Storage) ---- */
typedef struct {
    int used;
    char key[MRLIOU_MRL_MEMIO_KEY_MAX];
    uint64_t len;
    uint8_t val[MRLIOU_MRL_MEMIO_VAL_MAX];
} mrliou_mrl_memio_slot_t;
static mrliou_mrl_memio_slot_t g_memio[MRLIOU_MRL_MEMIO_SLOTS]; /* Wave_02 MemoryLayer 接管點 */
static mrliou_mrl_memio_slot_t *memio_find(const char *key){
    for (int i = 0; i < MRLIOU_MRL_MEMIO_SLOTS; i++)
        if (g_memio[i].used && strcmp(g_memio[i].key, key) == 0) return &g_memio[i];
    return 0;
}
static int memio_check_key(const char *key){
    if (!key || key[0] == '\0') return -1;            /* 空 key = error */
    if (strlen(key) >= MRLIOU_MRL_MEMIO_KEY_MAX) return -1;
    return 0;
}
int mrliou_mrl_kernel_memio_write(mrliou_mrl_kernel_t *k, const char *key, const void *buf, uint64_t n){
    if (!k || !buf) return MRLIOU_MRL_E_ARG;
    if (memio_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (n == 0 || n > MRLIOU_MRL_MEMIO_VAL_MAX) return MRLIOU_MRL_E_ARG;   /* size 檢查 */
    if (mrliou_mrl_law_verify(k->origin_signature) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    mrliou_mrl_memio_slot_t *s = memio_find(key);
    if (!s){
        for (int i = 0; i < MRLIOU_MRL_MEMIO_SLOTS; i++) if (!g_memio[i].used){ s = &g_memio[i]; break; }
        if (!s) return MRLIOU_MRL_E_ARG; /* 容量滿(Wave_01 暫存上限) */
        memset(s, 0, sizeof *s);
        strncpy(s->key, key, MRLIOU_MRL_MEMIO_KEY_MAX - 1);
        s->used = 1;
    }
    memcpy(s->val, buf, (size_t)n);
    s->len = n;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_kernel_memio_read(mrliou_mrl_kernel_t *k, const char *key, void *buf, uint64_t cap, uint64_t *out_n){
    if (!k || !buf || !out_n) return MRLIOU_MRL_E_ARG;
    if (memio_check_key(key) != 0) return MRLIOU_MRL_E_ARG;
    if (mrliou_mrl_law_verify(k->origin_signature) != MRLIOU_MRL_GATE_ALLOW) return MRLIOU_MRL_E_LAW;
    mrliou_mrl_memio_slot_t *s = memio_find(key);
    if (!s) return MRLIOU_MRL_E_NOT_FOUND;            /* missing key = not_found */
    if (cap < s->len) return MRLIOU_MRL_E_ARG;        /* size 檢查 */
    memcpy(buf, s->val, (size_t)s->len);
    *out_n = s->len;
    return MRLIOU_MRL_E_OK;
}
