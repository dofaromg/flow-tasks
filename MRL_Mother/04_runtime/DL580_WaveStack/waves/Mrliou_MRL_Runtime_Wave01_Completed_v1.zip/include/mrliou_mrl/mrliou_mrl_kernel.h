#ifndef MRLIOU_MRL_KERNEL_H
#define MRLIOU_MRL_KERNEL_H
#include <stdint.h>
#include "mrliou_mrl/mrliou_mrl_fluin.h"
/* canonical_name: Mrliou_MRL_Kernel | 認知核:latent + Δ 追蹤(LAW-3)+ origin_signature(LAW-0) */
#define MRLIOU_MRL_E_OK         0
#define MRLIOU_MRL_E_LAW       -1
#define MRLIOU_MRL_E_WAVE02    -2   /* Wave_02 邊界標記(MemoryLayer 等) */
#define MRLIOU_MRL_E_NOT_FOUND -3
#define MRLIOU_MRL_E_ARG       -4
#define MRLIOU_MRL_E_P1      -100
/* MemIO(Wave_01 層): process-local in-memory KV 暫存。
 * 不接 Database / 不接 MemoryLayer / 不接外部 Storage;Wave_02 MemoryLayer 為正式接管點。 */
#define MRLIOU_MRL_MEMIO_KEY_MAX 32
#define MRLIOU_MRL_MEMIO_VAL_MAX 256
#define MRLIOU_MRL_MEMIO_SLOTS   64
typedef struct {
    mrliou_mrl_fluin_vec_t latent;   /* Mrliou_MRL_Kernel_LatentState */
    uint64_t delta_count;            /* LAW-3 */
    char origin_signature[16];       /* LAW-0 */
} mrliou_mrl_kernel_t;
int mrliou_mrl_kernel_init(mrliou_mrl_kernel_t *k);
int mrliou_mrl_kernel_step(mrliou_mrl_kernel_t *k, const mrliou_mrl_fluin_vec_t *input);
int mrliou_mrl_kernel_memio_write(mrliou_mrl_kernel_t *k, const char *key, const void *buf, uint64_t n);
int mrliou_mrl_kernel_memio_read (mrliou_mrl_kernel_t *k, const char *key, void *buf, uint64_t cap, uint64_t *out_n);
#endif
