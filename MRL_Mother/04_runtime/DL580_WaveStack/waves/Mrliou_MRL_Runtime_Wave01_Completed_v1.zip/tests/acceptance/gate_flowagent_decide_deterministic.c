#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_flowagent.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_flow_context_t c1 = { 123456u, 0x2Du }; /* 0b101101 -> 4 legal */
    mrliou_mrl_flow_decision_t d1, d2;
    if (mrliou_mrl_flowagent_decide(&c1, &d1) != MRLIOU_MRL_E_OK){ printf("GATE flowagent_decide_deterministic FAIL call\n"); return 1; }
    if (mrliou_mrl_flowagent_decide(&c1, &d2) != MRLIOU_MRL_E_OK){ printf("GATE flowagent_decide_deterministic FAIL call2\n"); return 1; }
    if (memcmp(&d1, &d2, sizeof d1) != 0){ printf("GATE flowagent_decide_deterministic FAIL nondeterministic\n"); return 1; }
    if (d1.decision_code != 0 || d1.route < 0 || !(c1.legal_mask & (1u << d1.route))){ printf("GATE flowagent_decide_deterministic FAIL route\n"); return 1; }
    if (d1.legal_count != 4){ printf("GATE flowagent_decide_deterministic FAIL legal_count\n"); return 1; }
    if (d1.confidence_q16 == 0 || d1.confidence_q16 > 65536u){ printf("GATE flowagent_decide_deterministic FAIL confidence range\n"); return 1; }
    mrliou_mrl_flow_context_t c0 = { 9u, 0u };
    mrliou_mrl_flow_decision_t d0;
    if (mrliou_mrl_flowagent_decide(&c0, &d0) != MRLIOU_MRL_E_OK || d0.decision_code != 1 || d0.route != -1 || d0.confidence_q16 != 0){
        printf("GATE flowagent_decide_deterministic FAIL no_route\n"); return 1; }
    mrliou_mrl_flow_context_t c5 = { 777u, (1u << 5) };
    mrliou_mrl_flow_decision_t d5;
    if (mrliou_mrl_flowagent_decide(&c5, &d5) != MRLIOU_MRL_E_OK || d5.route != 5 || d5.confidence_q16 != 65536u){
        printf("GATE flowagent_decide_deterministic FAIL single route\n"); return 1; }
    if (mrliou_mrl_flowagent_decide(NULL, &d1) != MRLIOU_MRL_E_ARG){ printf("GATE flowagent_decide_deterministic FAIL null arg\n"); return 1; }
    printf("GATE flowagent_decide_deterministic PASS (same-in same-out, route in mask, confidence 0..65536, no-route case)\n");
    return 0;
}
