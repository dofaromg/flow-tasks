#include <stdio.h>
#include <stdlib.h>
#include "mrliou_mrl/mrliou_mrl_fluin.h"
int main(void){
    srand(20260611);
    for (int it = 0; it < 1000; it++){
        mrliou_mrl_fluin_vec_t role, filler, bound, rec;
        for (int i = 0; i < MRLIOU_MRL_FLUIN_DIM; i++){ role.v[i] = (uint8_t)(rand() & 0xFF); filler.v[i] = (uint8_t)(rand() & 0xFF); }
        mrliou_mrl_fluin_bind(&role, &filler, &bound);
        mrliou_mrl_fluin_unbind(&bound, &role, &rec);
        if (!mrliou_mrl_fluin_equal(&filler, &rec)){ printf("GATE fluin_reversibility FAIL @%d\n", it); return 1; }
    }
    printf("GATE fluin_reversibility PASS (1000/1000 unbind(bind(x))==x)\n");
    return 0;
}
