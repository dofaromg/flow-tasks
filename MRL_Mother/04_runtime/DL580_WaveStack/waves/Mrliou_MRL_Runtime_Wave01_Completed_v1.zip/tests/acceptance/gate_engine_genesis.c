#include <stdio.h>
#include <math.h>
#include "mrliou_mrl/mrliou_mrl_engine.h"
int main(void){
    double p = mrliou_mrl_engine_evolve(2.0, 3.0, 0.5); /* N*P*eta = 3 */
    if (fabs(p - 3.0) > 1e-12){ printf("GATE engine_genesis FAIL p\n"); return 1; }
    double chain = 1.0;
    for (int k = 0; k < 3; k++) chain = mrliou_mrl_engine_evolve(chain, 2.0, 1.0); /* 1->2->4->8 */
    if (fabs(chain - 8.0) > 1e-12){ printf("GATE engine_genesis FAIL chain\n"); return 1; }
    if (mrliou_mrl_engine_delta_count() < 4){ printf("GATE engine_genesis FAIL delta\n"); return 1; }
    printf("GATE engine_genesis PASS (P_{k+1}=N*P*eta reproducible, delta tracked)\n");
    return 0;
}
