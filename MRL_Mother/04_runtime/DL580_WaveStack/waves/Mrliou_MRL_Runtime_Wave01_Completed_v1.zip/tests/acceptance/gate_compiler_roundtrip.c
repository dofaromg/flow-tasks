#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_compiler.h"
int main(void){
    const char *src = "LAW-1: Mrliou_MRL canonical sample / how it went is how it returns";
    mrliou_mrl_atom_t atoms[64];
    size_t n = 0;
    if (mrliou_mrl_compiler_compile(src, atoms, 64, &n) != 0){ printf("GATE compiler_roundtrip FAIL compile\n"); return 1; }
    char out[64 * 16 + 1];
    if (mrliou_mrl_compiler_decompile(atoms, n, out, sizeof out) != 0){ printf("GATE compiler_roundtrip FAIL decompile\n"); return 1; }
    if (strcmp(src, out) != 0){ printf("GATE compiler_roundtrip FAIL mismatch\n"); return 1; }
    if (sizeof(mrliou_mrl_atom_t) != 40){ printf("GATE compiler_roundtrip FAIL atom size\n"); return 1; }
    printf("GATE compiler_roundtrip PASS (%zu atoms x 40B, compile<->decompile lossless, crc verified)\n", n);
    return 0;
}
