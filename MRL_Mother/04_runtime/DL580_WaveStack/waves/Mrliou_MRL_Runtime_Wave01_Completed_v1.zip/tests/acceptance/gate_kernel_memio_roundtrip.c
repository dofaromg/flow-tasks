#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_kernel_t k;
    if (mrliou_mrl_kernel_init(&k) != MRLIOU_MRL_E_OK){ printf("GATE kernel_memio_roundtrip FAIL init\n"); return 1; }
    uint8_t w[5] = {1,2,3,4,5}, r[MRLIOU_MRL_MEMIO_VAL_MAX]; uint64_t n = 0;
    if (mrliou_mrl_kernel_memio_write(&k, "alpha", w, 5) != MRLIOU_MRL_E_OK){ printf("GATE kernel_memio_roundtrip FAIL write\n"); return 1; }
    if (mrliou_mrl_kernel_memio_read(&k, "alpha", r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 5 || memcmp(w, r, 5) != 0){
        printf("GATE kernel_memio_roundtrip FAIL roundtrip\n"); return 1; }
    if (mrliou_mrl_kernel_memio_write(&k, "", w, 5) != MRLIOU_MRL_E_ARG){ printf("GATE kernel_memio_roundtrip FAIL empty key\n"); return 1; }
    if (mrliou_mrl_kernel_memio_write(&k, NULL, w, 5) != MRLIOU_MRL_E_ARG){ printf("GATE kernel_memio_roundtrip FAIL null key\n"); return 1; }
    if (mrliou_mrl_kernel_memio_read(&k, "missing", r, sizeof r, &n) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE kernel_memio_roundtrip FAIL not_found\n"); return 1; }
    if (mrliou_mrl_kernel_memio_write(&k, "big", w, (uint64_t)MRLIOU_MRL_MEMIO_VAL_MAX + 1) != MRLIOU_MRL_E_ARG){
        printf("GATE kernel_memio_roundtrip FAIL size check\n"); return 1; }
    uint8_t full[MRLIOU_MRL_MEMIO_VAL_MAX]; memset(full, 0x5A, sizeof full);
    if (mrliou_mrl_kernel_memio_write(&k, "cap", full, sizeof full) != MRLIOU_MRL_E_OK){ printf("GATE kernel_memio_roundtrip FAIL max write\n"); return 1; }
    if (mrliou_mrl_kernel_memio_read(&k, "cap", r, 8, &n) != MRLIOU_MRL_E_ARG){ printf("GATE kernel_memio_roundtrip FAIL cap check\n"); return 1; }
    uint8_t w2[3] = {9,9,9};
    if (mrliou_mrl_kernel_memio_write(&k, "alpha", w2, 3) != MRLIOU_MRL_E_OK){ printf("GATE kernel_memio_roundtrip FAIL overwrite\n"); return 1; }
    if (mrliou_mrl_kernel_memio_read(&k, "alpha", r, sizeof r, &n) != MRLIOU_MRL_E_OK || n != 3 || r[0] != 9){
        printf("GATE kernel_memio_roundtrip FAIL overwrite read\n"); return 1; }
    printf("GATE kernel_memio_roundtrip PASS (roundtrip, empty/null key, not_found, size+cap checks, overwrite)\n");
    return 0;
}
