#include <string.h>
#include "mrliou_mrl/mrliou_mrl_validator.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_compiler.h"   /* mrliou_mrl_crc32 */
#include "mrliou_mrl/mrliou_mrl_memorycube.h"
static uint64_t g_validator_count = 0;
/* 已登錄 canonical 節點(前綴比對;含 LAW 介面族) */
static const char *k_node_registry[] = {
    "Mrliou_MRL_Fluin", "Mrliou_MRL_Kernel", "Mrliou_MRL_Compiler", "Mrliou_MRL_Engine",
    "Mrliou_MRL_Runtime", "Mrliou_MRL_FlowAgent", "Mrliou_MRL_CollapseEngine",
    "Mrliou_MRL_WeightSystem", "Mrliou_MRL_Optimizer",
    "Mrliou_MRL_MemoryLayer", "Mrliou_MRL_MemoryOS", "Mrliou_MRL_MemoryCube", "Mrliou_MRL_MemoryVault",
    "Mrliou_MRL_Database", "Mrliou_MRL_Serializer", "Mrliou_MRL_Search", "Mrliou_MRL_Memory_Runtime_Assembly",
    "Mrliou_MRL_Guardian", "Mrliou_MRL_Validator", "Mrliou_MRL_LAW"
};
static const char *k_ext_tokens[] = {
    "External_", "Claude", "ChatGPT", "OpenAI", "Google", "Firebase", "Azure", "Notion", "GitHub", "AWS"
};
static int validator_has_external(const char *s){
    for (unsigned i = 0; i < sizeof k_ext_tokens / sizeof k_ext_tokens[0]; i++)
        if (strstr(s, k_ext_tokens[i])) return 1;
    return 0;
}
int mrliou_mrl_validator_init(void){
    if (strcmp(MRLIOU_MRL_ORIGIN_SIGNATURE, "MrLiouWord") != 0) return MRLIOU_MRL_E_LAW;
    g_validator_count = 0;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_validator_validate_atom(const void *buf, uint64_t n){
    if (!buf) return MRLIOU_MRL_E_ARG;
    g_validator_count++;
    if (n != sizeof(mrliou_mrl_atom_t)) return MRLIOU_MRL_E_BOUNDARY;                /* atom size check */
    const mrliou_mrl_atom_t *a = (const mrliou_mrl_atom_t *)buf;
    if (a->magic != 0x304C524Du) return MRLIOU_MRL_E_MALFORMED;
    if (a->type_id == 0) return MRLIOU_MRL_E_MALFORMED;
    uint8_t chunk[16];
    memcpy(chunk, &a->payload_lo, 8);
    memcpy(chunk + 8, &a->payload_hi, 8);
    if (mrliou_mrl_crc32(chunk, 16) != a->sig_crc) return MRLIOU_MRL_E_MALFORMED;    /* payload 完整性 */
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_validator_validate_memory_record(const mrliou_mrl_memory_record_t *r){
    if (!r) return MRLIOU_MRL_E_ARG;
    g_validator_count++;
    const void *z = memchr(r->key, 0, sizeof r->key);
    if (!z) return MRLIOU_MRL_E_MALFORMED;                                           /* key 無終止 = 畸形 */
    if (((const char *)z - r->key) == 0) return MRLIOU_MRL_E_MALFORMED;              /* 空 key = 畸形 */
    if (r->len == 0 || r->len > sizeof r->val) return MRLIOU_MRL_E_BOUNDARY;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_validator_validate_cube_object(const mrliou_mrl_cube_object_t *o){
    if (!o) return MRLIOU_MRL_E_ARG;
    g_validator_count++;
    if (o->cube_id >= MRLIOU_MRL_CUBE_MAX) return MRLIOU_MRL_E_BOUNDARY;
    if (o->coord.x >= MRLIOU_MRL_CUBE_AXIS || o->coord.y >= MRLIOU_MRL_CUBE_AXIS ||
        o->coord.z >= MRLIOU_MRL_CUBE_AXIS) return MRLIOU_MRL_E_BOUNDARY;            /* 座標越界 */
    if (o->len == 0 || o->len > sizeof o->payload) return MRLIOU_MRL_E_BOUNDARY;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_validator_validate_contract(const mrliou_mrl_contract_t *c){
    if (!c) return MRLIOU_MRL_E_ARG;
    g_validator_count++;
    if (!c->interface_name || c->interface_name[0] == '\0' ||
        !c->c_symbol || c->c_symbol[0] == '\0' ||
        !c->law || c->law[0] == '\0' ||
        !c->origin_signature || c->origin_signature[0] == '\0') return MRLIOU_MRL_E_MALFORMED; /* 必填欄缺 */
    if (strcmp(c->origin_signature, MRLIOU_MRL_ORIGIN_SIGNATURE) != 0) return MRLIOU_MRL_E_FORBIDDEN;
    if (validator_has_external(c->interface_name) || validator_has_external(c->c_symbol)) return MRLIOU_MRL_E_FORBIDDEN;
    if (strncmp(c->interface_name, "Mrliou_MRL_", 11) != 0) return MRLIOU_MRL_E_FORBIDDEN;
    if (strncmp(c->c_symbol, "mrliou_mrl_", 11) != 0) return MRLIOU_MRL_E_FORBIDDEN;
    for (unsigned i = 0; i < sizeof k_node_registry / sizeof k_node_registry[0]; i++)
        if (strncmp(c->interface_name, k_node_registry[i], strlen(k_node_registry[i])) == 0)
            return MRLIOU_MRL_E_OK;
    return MRLIOU_MRL_E_NOT_FOUND;                                                   /* 未登錄節點 */
}
int mrliou_mrl_validator_validate_runtime_state(const mrliou_mrl_runtime_t *rt, int runtime_not_complete_flag){
    if (!rt) return MRLIOU_MRL_E_ARG;
    g_validator_count++;
    int s = (int)rt->state;
    if (s < (int)MRLIOU_MRL_RT_INIT || s > (int)MRLIOU_MRL_RT_HALT) return MRLIOU_MRL_E_BOUNDARY;
    if (runtime_not_complete_flag != 1) return MRLIOU_MRL_E_FORBIDDEN;               /* 宣告完成 = 禁制 */
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_validator_reset(void){
    g_validator_count = 0;
    return MRLIOU_MRL_E_OK;
}
uint64_t mrliou_mrl_validator_validation_count(void){ return g_validator_count; }
