#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_guardian_runtime_assembly.h"
#include "mrliou_mrl/mrliou_mrl_guardian.h"
#include "mrliou_mrl/mrliou_mrl_validator.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_compiler.h"
#include "mrliou_mrl/mrliou_mrl_runtime.h"
static void grd_mark(mrliou_mrl_guardian_assembly_report_t *r, int idx, const char *line){
    printf("[guardian_assembly] %s\n", line);
    if (r && idx >= 0 && idx < MRLIOU_MRL_GRD_ASM_STAGES){
        snprintf(r->guardian_trace[idx], sizeof r->guardian_trace[idx], "%s", line);
        r->trace_len = idx + 1;
    }
}
int mrliou_mrl_guardian_runtime_assembly_boot(mrliou_mrl_guardian_assembly_report_t *out){
    if (out) memset(out, 0, sizeof *out);

    /* 0 Guardian */
    if (mrliou_mrl_guardian_init() != MRLIOU_MRL_E_OK) return -1;
    if (mrliou_mrl_guardian_check_origin("MrLiouWord") != MRLIOU_MRL_GUARDIAN_ALLOWED) return -1;
    if (mrliou_mrl_guardian_check_origin("External_X") != MRLIOU_MRL_GUARDIAN_BLOCKED) return -1;
    if (mrliou_mrl_guardian_check_sovereignty_name("Mrliou_MRL_Guardian") != MRLIOU_MRL_GUARDIAN_ALLOWED) return -1;
    if (mrliou_mrl_guardian_check_sovereignty_name("MemoryLayer") != MRLIOU_MRL_GUARDIAN_BLOCKED) return -1;
    if (mrliou_mrl_guardian_check_runtime_flag(1) != MRLIOU_MRL_GUARDIAN_ALLOWED) return -1;
    if (mrliou_mrl_guardian_check_runtime_flag(0) != MRLIOU_MRL_GUARDIAN_BLOCKED) return -1;
    if (mrliou_mrl_guardian_check_wave_boundary(3, 4) != MRLIOU_MRL_GUARDIAN_ALLOWED) return -1;
    if (mrliou_mrl_guardian_check_wave_boundary(3, 3) != MRLIOU_MRL_GUARDIAN_WARNING) return -1;
    if (mrliou_mrl_guardian_check_wave_boundary(2, 4) != MRLIOU_MRL_GUARDIAN_BLOCKED) return -1;
    if (mrliou_mrl_guardian_check_external_escalation("MrLiouWord", MRLIOU_MRL_AUTH_CANONICAL) != MRLIOU_MRL_GUARDIAN_ALLOWED) return -1;
    if (mrliou_mrl_guardian_check_external_escalation("Claude_Execution", MRLIOU_MRL_AUTH_CANONICAL) != MRLIOU_MRL_GUARDIAN_BLOCKED) return -1;
    if (mrliou_mrl_guardian_decide("MrLiouWord", "Mrliou_MRL_Guardian", 1, 2, 3) != MRLIOU_MRL_GUARDIAN_ALLOWED) return -1;
    grd_mark(out, 0, "0 Mrliou_MRL_Guardian: origin/name/flag/boundary OK");

    /* 1 Validator */
    if (mrliou_mrl_validator_init() != MRLIOU_MRL_E_OK) return -2;
    mrliou_mrl_atom_t atoms[4]; size_t na = 0;
    if (mrliou_mrl_compiler_compile("LAW-1: w3", atoms, 4, &na) != MRLIOU_MRL_E_OK || na < 1) return -2;
    if (mrliou_mrl_validator_validate_atom(&atoms[0], sizeof atoms[0]) != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_validator_validate_atom(&atoms[0], 39) != MRLIOU_MRL_E_BOUNDARY) return -2;
    mrliou_mrl_memory_record_t mr; memset(&mr, 0, sizeof mr);
    memcpy(mr.key, "grd_rec", 7); mr.len = 2; mr.val[0] = 1; mr.val[1] = 2;
    if (mrliou_mrl_validator_validate_memory_record(&mr) != MRLIOU_MRL_E_OK) return -2;
    mrliou_mrl_cube_object_t co; memset(&co, 0, sizeof co);
    co.cube_id = 1; co.coord.x = 1; co.coord.y = 2; co.coord.z = 3; co.len = 2;
    if (mrliou_mrl_validator_validate_cube_object(&co) != MRLIOU_MRL_E_OK) return -2;
    mrliou_mrl_contract_t ct = { "Mrliou_MRL_Guardian_Check_Origin", "mrliou_mrl_guardian_check_origin",
                                 "LAW-0 origin 委派裁決", "MrLiouWord" };
    if (mrliou_mrl_validator_validate_contract(&ct) != MRLIOU_MRL_E_OK) return -2;
    mrliou_mrl_runtime_t rt; mrliou_mrl_runtime_init(&rt);
    if (mrliou_mrl_validator_validate_runtime_state(&rt, 1) != MRLIOU_MRL_E_OK) return -2;
    if (mrliou_mrl_validator_validate_runtime_state(&rt, 0) != MRLIOU_MRL_E_FORBIDDEN) return -2;
    grd_mark(out, 1, "1 Mrliou_MRL_Validator: atom/record/cube/contract/state OK");

    /* 2 LAW_Verify(Guardian/Validator-backed 委派實證) */
    if (mrliou_mrl_guardian_reset() != MRLIOU_MRL_E_OK) return -3;
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return -3;
    if (mrliou_mrl_guardian_decision_count() < 1) return -3;                /* 委派 Guardian 實證 */
    if (mrliou_mrl_law_check_module_name("Mrliou_MRL_Validator") != 0) return -3;
    if (mrliou_mrl_law_check_wave_boundary(2, 4) != -1) return -3;
    if (mrliou_mrl_law_check_external_escalation("ChatGPT_Arch", MRLIOU_MRL_AUTH_CANONICAL) != -1) return -3;
    if (mrliou_mrl_validator_reset() != MRLIOU_MRL_E_OK) return -3;
    if (mrliou_mrl_law_validate_atom_payload(&atoms[0], sizeof atoms[0]) != MRLIOU_MRL_E_OK) return -3;
    if (mrliou_mrl_validator_validation_count() < 1) return -3;             /* 委派 Validator 實證 */
    grd_mark(out, 2, "2 Mrliou_MRL_LAW_Verify: guardian/validator-backed OK");

    /* 3 SEAL */
    grd_mark(out, 3, "3 Mrliou_MRL_Guardian_Runtime_Assembly: SEAL OK");
    if (out){
        out->guardian_status   = "wave03_closed(guardian_foundation_completed;runtime_not_complete=true)";
        out->validation_status = "validator_active(atom/memory_record/cube_object/contract/runtime_state)";
        out->remaining_wave04_hooks =
            "wave04: Runtime_Service_Foundation(integration/boot/service surface);"
            "collapse_search(P1);ed25519_sign_hook(deploy-side);DL580_deploy(pending Bridge_API_Key)";
    }
    return 0;
}
