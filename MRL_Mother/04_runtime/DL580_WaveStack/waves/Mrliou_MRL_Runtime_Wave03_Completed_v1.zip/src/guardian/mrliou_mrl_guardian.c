#include <string.h>
#include "mrliou_mrl/mrliou_mrl_guardian.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
static uint64_t g_guardian_count = 0;
static int g_guardian_init_flag = 0;
/* 外部主權 token deny-list(僅此用途;不作 canonical) */
static const char *k_external_tokens[] = {
    "External_", "Claude", "ChatGPT", "OpenAI", "Google", "Firebase", "Azure", "Notion", "GitHub", "AWS"
};
static int guardian_is_external(const char *name){
    for (unsigned i = 0; i < sizeof k_external_tokens / sizeof k_external_tokens[0]; i++)
        if (strstr(name, k_external_tokens[i])) return 1;
    return 0;
}
int mrliou_mrl_guardian_init(void){
    if (strcmp(MRLIOU_MRL_ORIGIN_SIGNATURE, "MrLiouWord") != 0) return MRLIOU_MRL_E_LAW; /* 自證 origin */
    g_guardian_count = 0;
    g_guardian_init_flag = 1;
    return MRLIOU_MRL_E_OK;
}
int mrliou_mrl_guardian_check_origin(const char *origin_signature){
    if (!origin_signature || origin_signature[0] == '\0') return MRLIOU_MRL_E_ARG;
    g_guardian_count++;
    if (strcmp(origin_signature, MRLIOU_MRL_ORIGIN_SIGNATURE) == 0) return MRLIOU_MRL_GUARDIAN_ALLOWED;
    return MRLIOU_MRL_GUARDIAN_BLOCKED;
}
int mrliou_mrl_guardian_check_sovereignty_name(const char *module_name){
    if (!module_name || module_name[0] == '\0') return MRLIOU_MRL_E_ARG;
    g_guardian_count++;
    if (guardian_is_external(module_name)) return MRLIOU_MRL_GUARDIAN_BLOCKED;       /* 外部主權名禁入 core */
    if (strncmp(module_name, "Mrliou_MRL_", 11) != 0) return MRLIOU_MRL_GUARDIAN_BLOCKED; /* 繼承律 */
    return MRLIOU_MRL_GUARDIAN_ALLOWED;
}
int mrliou_mrl_guardian_check_runtime_flag(int runtime_not_complete_flag){
    g_guardian_count++;
    return (runtime_not_complete_flag == 1) ? MRLIOU_MRL_GUARDIAN_ALLOWED : MRLIOU_MRL_GUARDIAN_BLOCKED;
}
int mrliou_mrl_guardian_check_wave_boundary(int wave_completed, int wave_requested){
    if (wave_completed < 0 || wave_requested < 1) return MRLIOU_MRL_E_ARG;
    g_guardian_count++;
    if (wave_requested == wave_completed + 1) return MRLIOU_MRL_GUARDIAN_ALLOWED;   /* 合法推進 */
    if (wave_requested <= wave_completed)     return MRLIOU_MRL_GUARDIAN_WARNING;   /* 重入(可疑非違規) */
    return MRLIOU_MRL_GUARDIAN_BLOCKED;                                             /* 跳波 = 違規 */
}
int mrliou_mrl_guardian_check_external_escalation(const char *actor_name, int requested_authority){
    if (!actor_name || actor_name[0] == '\0') return MRLIOU_MRL_E_ARG;
    if (requested_authority < MRLIOU_MRL_AUTH_OBSERVE || requested_authority > MRLIOU_MRL_AUTH_CANONICAL) return MRLIOU_MRL_E_ARG;
    g_guardian_count++;
    int internal = (strcmp(actor_name, MRLIOU_MRL_ORIGIN_SIGNATURE) == 0) ||
                   (!guardian_is_external(actor_name) && strncmp(actor_name, "Mrliou_MRL_", 11) == 0);
    if (internal) return MRLIOU_MRL_GUARDIAN_ALLOWED;
    switch (requested_authority){                                                   /* 外部/未知行動者 */
        case MRLIOU_MRL_AUTH_OBSERVE:   return MRLIOU_MRL_GUARDIAN_ALLOWED;
        case MRLIOU_MRL_AUTH_EXECUTE:   return MRLIOU_MRL_GUARDIAN_WARNING;         /* 受命執行,記警 */
        default:                        return MRLIOU_MRL_GUARDIAN_BLOCKED;         /* 主權升格 = 阻擋 */
    }
}
int mrliou_mrl_guardian_decide(const char *origin_signature, const char *module_name,
                               int runtime_not_complete_flag, int wave_completed, int wave_requested){
    int v, worst = MRLIOU_MRL_GUARDIAN_ALLOWED;
    v = mrliou_mrl_guardian_check_origin(origin_signature);          if (v < 0) return v; if (v > worst) worst = v;
    v = mrliou_mrl_guardian_check_sovereignty_name(module_name);     if (v < 0) return v; if (v > worst) worst = v;
    v = mrliou_mrl_guardian_check_runtime_flag(runtime_not_complete_flag); if (v < 0) return v; if (v > worst) worst = v;
    v = mrliou_mrl_guardian_check_wave_boundary(wave_completed, wave_requested); if (v < 0) return v; if (v > worst) worst = v;
    return worst;                                                    /* 最嚴重者裁決(deterministic) */
}
int mrliou_mrl_guardian_reset(void){
    g_guardian_count = 0;
    g_guardian_init_flag = 1;
    return MRLIOU_MRL_E_OK;
}
uint64_t mrliou_mrl_guardian_decision_count(void){ return g_guardian_count; }
