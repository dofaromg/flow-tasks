#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_runtime_core_assembly.h"
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_fluin.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
#include "mrliou_mrl/mrliou_mrl_compiler.h"
#include "mrliou_mrl/mrliou_mrl_engine.h"
#include "mrliou_mrl/mrliou_mrl_runtime.h"
#include "mrliou_mrl/mrliou_mrl_flowagent.h"
#include "mrliou_mrl/mrliou_mrl_collapse_engine.h"
#include "mrliou_mrl/mrliou_mrl_weight_system.h"
#include "mrliou_mrl/mrliou_mrl_optimizer.h"

static const char *k_core_nodes[MRLIOU_MRL_ASM_STAGES] = {
    "Mrliou_MRL_Fluin", "Mrliou_MRL_Kernel", "Mrliou_MRL_Compiler", "Mrliou_MRL_Engine",
    "Mrliou_MRL_Runtime", "Mrliou_MRL_FlowAgent", "Mrliou_MRL_CollapseEngine",
    "Mrliou_MRL_WeightSystem", "Mrliou_MRL_Optimizer", "Mrliou_MRL_Runtime_Core_Assembly"
};
static void asm_mark(mrliou_mrl_assembly_report_t *r, int idx, const char *line){
    printf("[assembly] %s\n", line);
    if (r && idx >= 0 && idx < MRLIOU_MRL_ASM_STAGES){
        snprintf(r->assembly_trace[idx], sizeof r->assembly_trace[idx], "%s", line);
        r->trace_len = idx + 1;
    }
}
int mrliou_mrl_runtime_core_assembly_boot(mrliou_mrl_assembly_report_t *out){
    if (out) memset(out, 0, sizeof *out);
    /* --- LAW 前置門(skeleton-level;Guardian=Wave_03 接管) --- */
    if (mrliou_mrl_law_verify(MRLIOU_MRL_ORIGIN_SIGNATURE) != MRLIOU_MRL_GATE_ALLOW) return -1;
    for (int i = 0; i < MRLIOU_MRL_ASM_STAGES; i++)
        if (mrliou_mrl_law_check_module_name(k_core_nodes[i]) != 0) return -1;
    if (mrliou_mrl_law_check_module_name("External_MRL_X") == 0) return -1; /* 反向自檢:外名必須被擋 */
    if (mrliou_mrl_law_check_runtime_flag(1) != 0) return -1;
    printf("[assembly] LAW gate: origin+naming+flag verified (Guardian=Wave_03 hook)\n");

    /* 0 Fluin */
    mrliou_mrl_fluin_vec_t a = {{0}}, b = {{0}}, c, r;
    a.v[0] = 0x5A; b.v[0] = 0xA5;
    mrliou_mrl_fluin_bind(&a, &b, &c);
    mrliou_mrl_fluin_unbind(&c, &a, &r);
    if (!mrliou_mrl_fluin_equal(&b, &r)) return -2;
    asm_mark(out, 0, "0 Mrliou_MRL_Fluin: bind/unbind OK");

    /* 1 Kernel(init + step + memio roundtrip) */
    mrliou_mrl_kernel_t k;
    if (mrliou_mrl_kernel_init(&k) != MRLIOU_MRL_E_OK) return -3;
    mrliou_mrl_fluin_vec_t in0 = {{0}}; in0.v[1] = 3;
    if (mrliou_mrl_kernel_step(&k, &in0) != MRLIOU_MRL_E_OK || k.delta_count != 1) return -3;
    uint8_t w[2] = {0xA, 0xB}, rb[8]; uint64_t rn = 0;
    if (mrliou_mrl_kernel_memio_write(&k, "asm_probe", w, 2) != MRLIOU_MRL_E_OK) return -3;
    if (mrliou_mrl_kernel_memio_read(&k, "asm_probe", rb, sizeof rb, &rn) != MRLIOU_MRL_E_OK) return -3;
    if (rn != 2 || memcmp(w, rb, 2) != 0) return -3;
    asm_mark(out, 1, "1 Mrliou_MRL_Kernel: init+step+memio OK");

    /* 2 Compiler */
    mrliou_mrl_atom_t atoms[8]; size_t na = 0; char dec[8 * 16 + 1];
    if (mrliou_mrl_compiler_compile("LAW-1: asm probe", atoms, 8, &na) != MRLIOU_MRL_E_OK) return -4;
    if (mrliou_mrl_compiler_decompile(atoms, na, dec, sizeof dec) != MRLIOU_MRL_E_OK) return -4;
    if (strcmp(dec, "LAW-1: asm probe") != 0) return -4;
    asm_mark(out, 2, "2 Mrliou_MRL_Compiler: roundtrip OK");

    /* 3 Engine */
    if (mrliou_mrl_engine_evolve(1.0, 2.0, 0.5) != 1.0) return -5;
    asm_mark(out, 3, "3 Mrliou_MRL_Engine: genesis OK");

    /* 4 Runtime */
    mrliou_mrl_runtime_t rt;
    mrliou_mrl_runtime_init(&rt);
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_SUSPEND) == 0) return -6; /* 非法須擋 */
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_RUN) != 0) return -6;
    if (mrliou_mrl_runtime_transition(&rt, MRLIOU_MRL_RT_HALT) != 0) return -6;
    asm_mark(out, 4, "4 Mrliou_MRL_Runtime: lifecycle OK");

    /* 5 FlowAgent(deterministic) */
    mrliou_mrl_flow_context_t fc = { 7u, 0xBu };
    mrliou_mrl_flow_decision_t d1, d2;
    if (mrliou_mrl_flowagent_decide(&fc, &d1) != MRLIOU_MRL_E_OK) return -7;
    if (mrliou_mrl_flowagent_decide(&fc, &d2) != MRLIOU_MRL_E_OK) return -7;
    if (memcmp(&d1, &d2, sizeof d1) != 0 || d1.decision_code != 0) return -7;
    if (d1.route < 0 || !(fc.legal_mask & (1u << d1.route))) return -7;
    asm_mark(out, 5, "5 Mrliou_MRL_FlowAgent: deterministic OK");

    /* 6 CollapseEngine(imagine) */
    mrliou_mrl_collapse_result_t cr;
    if (mrliou_mrl_collapse_imagine(42ULL, 7u, 4, &cr) != MRLIOU_MRL_E_OK) return -8;
    if (cr.trace_len != 4 || strcmp(cr.scope, "skeleton_imagination") != 0) return -8;
    asm_mark(out, 6, "6 Mrliou_MRL_CollapseEngine: imagine OK");

    /* 7 WeightSystem */
    double ten[10] = {1,1,1,1,1,1,1,1,1,1};
    if (mrliou_mrl_weight_system_validate(ten) != 0) return -9;
    asm_mark(out, 7, "7 Mrliou_MRL_WeightSystem: sum10 OK");

    /* 8 Optimizer */
    mrliou_mrl_plan_t pin, pout;
    memset(&pin, 0, sizeof pin);
    pin.nodes[0].node_id = 1; pin.nodes[0].weight = 0; pin.nodes[0].required = 1;
    pin.nodes[1].node_id = 2; pin.nodes[1].weight = 0; pin.nodes[1].required = 0; /* 冗餘 */
    pin.nodes[2].node_id = 3; pin.nodes[2].weight = 5; pin.nodes[2].required = 0;
    pin.n = 3;
    if (mrliou_mrl_optimizer_pass(&pin, &pout) != MRLIOU_MRL_E_OK) return -10;
    if (pout.n != 2 || pout.nodes[0].node_id != 1 || pout.provenance_fp == 0) return -10;
    asm_mark(out, 8, "8 Mrliou_MRL_Optimizer: pass OK");

    /* 9 Assembly seal */
    asm_mark(out, 9, "9 Mrliou_MRL_Runtime_Core_Assembly: SEAL OK");
    if (out){
        out->wave01_status = "wave01_closed(skeleton_completed;runtime_not_complete=true)";
        out->missing_wave02_hooks =
            "wave02_completed(Mrliou_MRL_MemoryLayer 已接管 Kernel_MemIO);"
            "wave03_completed(Mrliou_MRL_Guardian/Validator 已接管 LAW);collapse_search(P1);ed25519_sign_hook(deploy-side)";
    }
    return 0;
}
