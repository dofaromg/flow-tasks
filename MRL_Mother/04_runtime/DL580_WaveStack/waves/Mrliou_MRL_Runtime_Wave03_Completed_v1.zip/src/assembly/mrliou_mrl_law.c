#include <string.h>
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_guardian.h"
#include "mrliou_mrl/mrliou_mrl_validator.h"
/* Wave_03: skeleton-level 檢查升級為 Guardian-backed(實際委派;非複本邏輯) */
mrliou_mrl_gate_t mrliou_mrl_law_verify(const char *origin_signature){
    return (mrliou_mrl_guardian_check_origin(origin_signature) == MRLIOU_MRL_GUARDIAN_ALLOWED)
           ? MRLIOU_MRL_GATE_ALLOW : MRLIOU_MRL_GATE_BLOCK;
}
int mrliou_mrl_law_check_module_name(const char *module_name){
    return (mrliou_mrl_guardian_check_sovereignty_name(module_name) == MRLIOU_MRL_GUARDIAN_ALLOWED) ? 0 : -1;
}
int mrliou_mrl_law_check_runtime_flag(int runtime_not_complete_flag){
    return (mrliou_mrl_guardian_check_runtime_flag(runtime_not_complete_flag) == MRLIOU_MRL_GUARDIAN_ALLOWED) ? 0 : -1;
}
int mrliou_mrl_law_check_wave_boundary(int wave_completed, int wave_requested){
    int v = mrliou_mrl_guardian_check_wave_boundary(wave_completed, wave_requested);
    return (v == MRLIOU_MRL_GUARDIAN_ALLOWED || v == MRLIOU_MRL_GUARDIAN_WARNING) ? 0 : -1;
}
int mrliou_mrl_law_check_external_escalation(const char *actor_name, int requested_authority){
    int v = mrliou_mrl_guardian_check_external_escalation(actor_name, requested_authority);
    return (v == MRLIOU_MRL_GUARDIAN_ALLOWED || v == MRLIOU_MRL_GUARDIAN_WARNING) ? 0 : -1;
}
int mrliou_mrl_law_validate_atom_payload(const void *buf, uint64_t n){
    return mrliou_mrl_validator_validate_atom(buf, n);
}
