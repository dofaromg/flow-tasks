#ifndef MRLIOU_MRL_GUARDIAN_H
#define MRLIOU_MRL_GUARDIAN_H
#include <stdint.h>
/* canonical_name: Mrliou_MRL_Guardian | Wave_03 治理守門核
 * deterministic / no network / no external model / no external authority。
 * 裁決: ALLOWED(0) / WARNING(1) / BLOCKED(2);參數違規回負值 error code(E_ARG)。
 * 外部主權名(Claude/ChatGPT/OpenAI/Google/Firebase/Azure/Notion/GitHub/AWS/External_)
 * 僅存在於 deny-list,永不作 canonical;origin_signature: MrLiouWord。 */
typedef enum {
    MRLIOU_MRL_GUARDIAN_ALLOWED = 0,
    MRLIOU_MRL_GUARDIAN_WARNING = 1,
    MRLIOU_MRL_GUARDIAN_BLOCKED = 2
} mrliou_mrl_guardian_verdict_t;
typedef enum {
    MRLIOU_MRL_AUTH_OBSERVE   = 0,   /* 讀取/鏡像 */
    MRLIOU_MRL_AUTH_EXECUTE   = 1,   /* 受命執行 */
    MRLIOU_MRL_AUTH_CANONICAL = 2    /* 正本/主權寫入 */
} mrliou_mrl_authority_t;
int mrliou_mrl_guardian_init(void);
int mrliou_mrl_guardian_check_origin(const char *origin_signature);
int mrliou_mrl_guardian_check_sovereignty_name(const char *module_name);
int mrliou_mrl_guardian_check_runtime_flag(int runtime_not_complete_flag);
int mrliou_mrl_guardian_check_wave_boundary(int wave_completed, int wave_requested);
int mrliou_mrl_guardian_check_external_escalation(const char *actor_name, int requested_authority);
int mrliou_mrl_guardian_decide(const char *origin_signature, const char *module_name,
                               int runtime_not_complete_flag, int wave_completed, int wave_requested);
int mrliou_mrl_guardian_reset(void);
uint64_t mrliou_mrl_guardian_decision_count(void);
#endif
