#ifndef MRLIOU_MRL_VALIDATOR_H
#define MRLIOU_MRL_VALIDATOR_H
#include <stdint.h>
#include "mrliou_mrl/mrliou_mrl_atom.h"
#include "mrliou_mrl/mrliou_mrl_serializer.h"
#include "mrliou_mrl/mrliou_mrl_runtime.h"
/* canonical_name: Mrliou_MRL_Validator | Wave_03 結構/契約驗證核(deterministic)
 * 錯誤區分: E_ARG(參數) / E_MALFORMED(畸形) / E_BOUNDARY(越界) / E_FORBIDDEN(禁制) / E_NOT_FOUND(未登錄) */
typedef struct {
    const char *interface_name;    /* 必填;Mrliou_MRL_ 前綴且屬已登錄節點 */
    const char *c_symbol;          /* 必填;mrliou_mrl_ 前綴 */
    const char *law;               /* 必填;非空 */
    const char *origin_signature;  /* 必填;= MrLiouWord */
} mrliou_mrl_contract_t;
int mrliou_mrl_validator_init(void);
int mrliou_mrl_validator_validate_atom(const void *buf, uint64_t n);
int mrliou_mrl_validator_validate_memory_record(const mrliou_mrl_memory_record_t *r);
int mrliou_mrl_validator_validate_cube_object(const mrliou_mrl_cube_object_t *o);
int mrliou_mrl_validator_validate_contract(const mrliou_mrl_contract_t *c);
int mrliou_mrl_validator_validate_runtime_state(const mrliou_mrl_runtime_t *rt, int runtime_not_complete_flag);
int mrliou_mrl_validator_reset(void);
uint64_t mrliou_mrl_validator_validation_count(void);
#endif
