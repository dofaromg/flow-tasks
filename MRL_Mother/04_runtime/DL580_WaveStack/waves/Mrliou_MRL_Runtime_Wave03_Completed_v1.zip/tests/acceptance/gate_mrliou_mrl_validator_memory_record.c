#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_validator.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_memory_record_t r; memset(&r, 0, sizeof r);
    memcpy(r.key, "rec_ok", 6); r.len = 3; r.val[0] = 1;
    if (mrliou_mrl_validator_validate_memory_record(&r) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_validator_memory_record FAIL valid\n"); return 1; }
    mrliou_mrl_memory_record_t e; memset(&e, 0, sizeof e); e.len = 1;
    if (mrliou_mrl_validator_validate_memory_record(&e) != MRLIOU_MRL_E_MALFORMED){ printf("GATE mrliou_mrl_validator_memory_record FAIL empty_key\n"); return 1; }
    mrliou_mrl_memory_record_t u; memset(&u, 0x41, sizeof u); u.len = 1;          /* key 無 NUL = 畸形 */
    if (mrliou_mrl_validator_validate_memory_record(&u) != MRLIOU_MRL_E_MALFORMED){ printf("GATE mrliou_mrl_validator_memory_record FAIL no_nul\n"); return 1; }
    r.len = 0;
    if (mrliou_mrl_validator_validate_memory_record(&r) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_validator_memory_record FAIL len0\n"); return 1; }
    r.len = 257;
    if (mrliou_mrl_validator_validate_memory_record(&r) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_validator_memory_record FAIL len257\n"); return 1; }
    if (mrliou_mrl_validator_validate_memory_record(0) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_validator_memory_record FAIL arg\n"); return 1; }
    printf("GATE mrliou_mrl_validator_memory_record PASS (schema ok; empty/no-nul key=malformed; len 0/257=boundary)\n");
    return 0;
}
