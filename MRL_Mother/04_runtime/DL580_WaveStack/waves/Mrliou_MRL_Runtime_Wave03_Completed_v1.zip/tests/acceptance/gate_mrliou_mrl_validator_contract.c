#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_validator.h"
#include "mrliou_mrl/mrliou_mrl_runtime.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_contract_t ok = { "Mrliou_MRL_MemoryLayer_Write", "mrliou_mrl_memorylayer_write",
                                 "key<48/val 1..512;roundtrip", "MrLiouWord" };
    if (mrliou_mrl_validator_validate_contract(&ok) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_validator_contract FAIL valid\n"); return 1; }
    mrliou_mrl_contract_t m1 = ok; m1.law = "";
    if (mrliou_mrl_validator_validate_contract(&m1) != MRLIOU_MRL_E_MALFORMED){ printf("GATE mrliou_mrl_validator_contract FAIL law_missing\n"); return 1; }
    mrliou_mrl_contract_t m2 = ok; m2.c_symbol = 0;
    if (mrliou_mrl_validator_validate_contract(&m2) != MRLIOU_MRL_E_MALFORMED){ printf("GATE mrliou_mrl_validator_contract FAIL field_missing\n"); return 1; }
    mrliou_mrl_contract_t f1 = ok; f1.interface_name = "External_API";
    if (mrliou_mrl_validator_validate_contract(&f1) != MRLIOU_MRL_E_FORBIDDEN){ printf("GATE mrliou_mrl_validator_contract FAIL external\n"); return 1; }
    mrliou_mrl_contract_t f2 = ok; f2.interface_name = "Firebase_Store_Put";
    if (mrliou_mrl_validator_validate_contract(&f2) != MRLIOU_MRL_E_FORBIDDEN){ printf("GATE mrliou_mrl_validator_contract FAIL brand\n"); return 1; }
    mrliou_mrl_contract_t f3 = ok; f3.c_symbol = "memorylayer_write";
    if (mrliou_mrl_validator_validate_contract(&f3) != MRLIOU_MRL_E_FORBIDDEN){ printf("GATE mrliou_mrl_validator_contract FAIL symbol_prefix\n"); return 1; }
    mrliou_mrl_contract_t f4 = ok; f4.origin_signature = "OpenAI";
    if (mrliou_mrl_validator_validate_contract(&f4) != MRLIOU_MRL_E_FORBIDDEN){ printf("GATE mrliou_mrl_validator_contract FAIL origin\n"); return 1; }
    mrliou_mrl_contract_t nf = ok; nf.interface_name = "Mrliou_MRL_Ghost_Module_X";
    if (mrliou_mrl_validator_validate_contract(&nf) != MRLIOU_MRL_E_NOT_FOUND){ printf("GATE mrliou_mrl_validator_contract FAIL not_found\n"); return 1; }
    if (mrliou_mrl_validator_validate_contract(0) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_validator_contract FAIL arg\n"); return 1; }
    /* runtime_state 驗證 */
    mrliou_mrl_runtime_t rt; mrliou_mrl_runtime_init(&rt);
    if (mrliou_mrl_validator_validate_runtime_state(&rt, 1) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_validator_contract FAIL state_ok\n"); return 1; }
    if (mrliou_mrl_validator_validate_runtime_state(&rt, 0) != MRLIOU_MRL_E_FORBIDDEN){ printf("GATE mrliou_mrl_validator_contract FAIL state_flag\n"); return 1; }
    rt.state = (mrliou_mrl_rt_state_t)99;
    if (mrliou_mrl_validator_validate_runtime_state(&rt, 1) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_validator_contract FAIL state_bound\n"); return 1; }
    if (mrliou_mrl_validator_validate_runtime_state(0, 1) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_validator_contract FAIL state_arg\n"); return 1; }
    printf("GATE mrliou_mrl_validator_contract PASS (required/forbidden/not_found split; runtime_state ok/forbidden/boundary)\n");
    return 0;
}
