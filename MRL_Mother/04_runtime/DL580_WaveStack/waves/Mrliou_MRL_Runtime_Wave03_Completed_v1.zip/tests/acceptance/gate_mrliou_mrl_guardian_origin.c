#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_guardian.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    if (mrliou_mrl_guardian_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_guardian_origin FAIL init\n"); return 1; }
    if (mrliou_mrl_guardian_check_origin("MrLiouWord") != MRLIOU_MRL_GUARDIAN_ALLOWED){ printf("GATE mrliou_mrl_guardian_origin FAIL allow\n"); return 1; }
    if (mrliou_mrl_guardian_check_origin("External_X") != MRLIOU_MRL_GUARDIAN_BLOCKED){ printf("GATE mrliou_mrl_guardian_origin FAIL block\n"); return 1; }
    if (mrliou_mrl_guardian_check_origin("ChatGPT") != MRLIOU_MRL_GUARDIAN_BLOCKED){ printf("GATE mrliou_mrl_guardian_origin FAIL brand\n"); return 1; }
    if (mrliou_mrl_guardian_check_origin("") != MRLIOU_MRL_E_ARG || mrliou_mrl_guardian_check_origin(0) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_guardian_origin FAIL arg\n"); return 1; }
    if (mrliou_mrl_guardian_decision_count() < 3){ printf("GATE mrliou_mrl_guardian_origin FAIL count\n"); return 1; }
    if (mrliou_mrl_guardian_reset() != MRLIOU_MRL_E_OK || mrliou_mrl_guardian_decision_count() != 0){
        printf("GATE mrliou_mrl_guardian_origin FAIL reset\n"); return 1; }
    printf("GATE mrliou_mrl_guardian_origin PASS (MrLiouWord allowed, foreign/brand blocked, arg guarded, audit count+reset)\n");
    return 0;
}
