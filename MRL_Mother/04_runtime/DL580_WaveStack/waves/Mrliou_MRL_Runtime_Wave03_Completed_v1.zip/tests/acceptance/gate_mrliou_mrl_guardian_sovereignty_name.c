#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_guardian.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    static const char *legal[4] = {"Mrliou_MRL_Guardian", "Mrliou_MRL_Kernel", "Mrliou_MRL_MemoryLayer", "Mrliou_MRL_Validator"};
    for (int i = 0; i < 4; i++)
        if (mrliou_mrl_guardian_check_sovereignty_name(legal[i]) != MRLIOU_MRL_GUARDIAN_ALLOWED){
            printf("GATE mrliou_mrl_guardian_sovereignty_name FAIL legal %d\n", i); return 1; }
    static const char *bad[7] = {"MemoryLayer", "MRL_Database", "External_Bridge", "Firebase_Store", "Claude_Core", "GitHub_Sync", "Notion_Mirror"};
    for (int i = 0; i < 7; i++)
        if (mrliou_mrl_guardian_check_sovereignty_name(bad[i]) != MRLIOU_MRL_GUARDIAN_BLOCKED){
            printf("GATE mrliou_mrl_guardian_sovereignty_name FAIL bad %d\n", i); return 1; }
    if (mrliou_mrl_guardian_check_sovereignty_name("") != MRLIOU_MRL_E_ARG ||
        mrliou_mrl_guardian_check_sovereignty_name(0) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_guardian_sovereignty_name FAIL arg\n"); return 1; }
    printf("GATE mrliou_mrl_guardian_sovereignty_name PASS (Mrliou_MRL_ allowed; bare/MRL_/External_/brand names blocked)\n");
    return 0;
}
