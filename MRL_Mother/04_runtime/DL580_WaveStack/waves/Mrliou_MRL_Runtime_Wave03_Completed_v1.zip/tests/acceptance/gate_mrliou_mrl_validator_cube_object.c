#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_validator.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    mrliou_mrl_cube_object_t o; memset(&o, 0, sizeof o);
    o.cube_id = 2; o.coord.x = 1; o.coord.y = 2; o.coord.z = 3; o.len = 4;
    if (mrliou_mrl_validator_validate_cube_object(&o) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_validator_cube_object FAIL valid\n"); return 1; }
    o.cube_id = 8;
    if (mrliou_mrl_validator_validate_cube_object(&o) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_validator_cube_object FAIL cube_id\n"); return 1; }
    o.cube_id = 2; o.coord.x = 4;
    if (mrliou_mrl_validator_validate_cube_object(&o) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_validator_cube_object FAIL coord\n"); return 1; }
    o.coord.x = 1; o.len = 0;
    if (mrliou_mrl_validator_validate_cube_object(&o) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_validator_cube_object FAIL len0\n"); return 1; }
    o.len = 65;
    if (mrliou_mrl_validator_validate_cube_object(&o) != MRLIOU_MRL_E_BOUNDARY){ printf("GATE mrliou_mrl_validator_cube_object FAIL len65\n"); return 1; }
    if (mrliou_mrl_validator_validate_cube_object(0) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_validator_cube_object FAIL arg\n"); return 1; }
    printf("GATE mrliou_mrl_validator_cube_object PASS (coordinate/payload boundary checks, arg guarded)\n");
    return 0;
}
