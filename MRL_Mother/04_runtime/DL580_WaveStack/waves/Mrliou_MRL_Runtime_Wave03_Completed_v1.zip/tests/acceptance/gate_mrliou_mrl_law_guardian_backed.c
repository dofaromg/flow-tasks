#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_law.h"
#include "mrliou_mrl/mrliou_mrl_guardian.h"
#include "mrliou_mrl/mrliou_mrl_validator.h"
#include "mrliou_mrl/mrliou_mrl_compiler.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    if (mrliou_mrl_guardian_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_law_guardian_backed FAIL g_reset\n"); return 1; }
    if (mrliou_mrl_law_verify("MrLiouWord") != MRLIOU_MRL_GATE_ALLOW){ printf("GATE mrliou_mrl_law_guardian_backed FAIL verify\n"); return 1; }
    if (mrliou_mrl_guardian_decision_count() < 1){ printf("GATE mrliou_mrl_law_guardian_backed FAIL delegation\n"); return 1; }  /* LAW→Guardian 實證 */
    if (mrliou_mrl_law_verify("External_X") != MRLIOU_MRL_GATE_BLOCK){ printf("GATE mrliou_mrl_law_guardian_backed FAIL block\n"); return 1; }
    if (mrliou_mrl_law_check_module_name("Mrliou_MRL_Guardian") != 0){ printf("GATE mrliou_mrl_law_guardian_backed FAIL name_ok\n"); return 1; }
    if (mrliou_mrl_law_check_module_name("Claude_Core") == 0){ printf("GATE mrliou_mrl_law_guardian_backed FAIL name_block\n"); return 1; }
    if (mrliou_mrl_law_check_runtime_flag(1) != 0 || mrliou_mrl_law_check_runtime_flag(0) == 0){
        printf("GATE mrliou_mrl_law_guardian_backed FAIL flag\n"); return 1; }
    if (mrliou_mrl_law_check_wave_boundary(2, 3) != 0){ printf("GATE mrliou_mrl_law_guardian_backed FAIL wave_next\n"); return 1; }
    if (mrliou_mrl_law_check_wave_boundary(3, 2) != 0){ printf("GATE mrliou_mrl_law_guardian_backed FAIL wave_reentry\n"); return 1; }
    if (mrliou_mrl_law_check_wave_boundary(1, 3) != -1){ printf("GATE mrliou_mrl_law_guardian_backed FAIL wave_jump\n"); return 1; }
    if (mrliou_mrl_law_check_external_escalation("Mrliou_MRL_Kernel", 2) != 0){ printf("GATE mrliou_mrl_law_guardian_backed FAIL esc_internal\n"); return 1; }
    if (mrliou_mrl_law_check_external_escalation("Claude_Execution", 2) != -1){ printf("GATE mrliou_mrl_law_guardian_backed FAIL esc_external\n"); return 1; }
    /* LAW→Validator 委派實證 */
    mrliou_mrl_atom_t atoms[4]; size_t na = 0;
    if (mrliou_mrl_compiler_compile("LAW-1: backed", atoms, 4, &na) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_law_guardian_backed FAIL compile\n"); return 1; }
    if (mrliou_mrl_validator_reset() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_law_guardian_backed FAIL v_reset\n"); return 1; }
    if (mrliou_mrl_law_validate_atom_payload(&atoms[0], sizeof atoms[0]) != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_law_guardian_backed FAIL payload_ok\n"); return 1; }
    if (mrliou_mrl_validator_validation_count() < 1){ printf("GATE mrliou_mrl_law_guardian_backed FAIL v_delegation\n"); return 1; }
    mrliou_mrl_atom_t bad = atoms[0]; bad.magic = 0;
    if (mrliou_mrl_law_validate_atom_payload(&bad, sizeof bad) != MRLIOU_MRL_E_MALFORMED){ printf("GATE mrliou_mrl_law_guardian_backed FAIL payload_bad\n"); return 1; }
    printf("GATE mrliou_mrl_law_guardian_backed PASS (LAW delegates Guardian: origin/name/flag/wave/escalation; delegates Validator: payload)\n");
    return 0;
}
