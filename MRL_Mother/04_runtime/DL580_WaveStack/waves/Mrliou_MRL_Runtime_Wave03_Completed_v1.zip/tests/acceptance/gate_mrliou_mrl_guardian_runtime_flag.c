#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_guardian.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    if (mrliou_mrl_guardian_check_runtime_flag(1) != MRLIOU_MRL_GUARDIAN_ALLOWED){ printf("GATE mrliou_mrl_guardian_runtime_flag FAIL keep\n"); return 1; }
    if (mrliou_mrl_guardian_check_runtime_flag(0) != MRLIOU_MRL_GUARDIAN_BLOCKED){ printf("GATE mrliou_mrl_guardian_runtime_flag FAIL tamper0\n"); return 1; }
    if (mrliou_mrl_guardian_check_runtime_flag(2) != MRLIOU_MRL_GUARDIAN_BLOCKED){ printf("GATE mrliou_mrl_guardian_runtime_flag FAIL tamper2\n"); return 1; }
    if (mrliou_mrl_guardian_check_runtime_flag(-1) != MRLIOU_MRL_GUARDIAN_BLOCKED){ printf("GATE mrliou_mrl_guardian_runtime_flag FAIL tamper_neg\n"); return 1; }
    /* wave boundary 保護(Guardian 可檢查 wave boundary) */
    if (mrliou_mrl_guardian_check_wave_boundary(3, 4) != MRLIOU_MRL_GUARDIAN_ALLOWED){ printf("GATE mrliou_mrl_guardian_runtime_flag FAIL wave_next\n"); return 1; }
    if (mrliou_mrl_guardian_check_wave_boundary(3, 3) != MRLIOU_MRL_GUARDIAN_WARNING){ printf("GATE mrliou_mrl_guardian_runtime_flag FAIL wave_reentry\n"); return 1; }
    if (mrliou_mrl_guardian_check_wave_boundary(2, 5) != MRLIOU_MRL_GUARDIAN_BLOCKED){ printf("GATE mrliou_mrl_guardian_runtime_flag FAIL wave_jump\n"); return 1; }
    if (mrliou_mrl_guardian_check_wave_boundary(-1, 2) != MRLIOU_MRL_E_ARG){ printf("GATE mrliou_mrl_guardian_runtime_flag FAIL wave_arg\n"); return 1; }
    printf("GATE mrliou_mrl_guardian_runtime_flag PASS (flag=1 only; tamper blocked; wave next/reentry/jump = allowed/warning/blocked)\n");
    return 0;
}
