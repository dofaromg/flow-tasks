#include <stdio.h>
#include "mrliou_mrl/mrliou_mrl_guardian.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    if (mrliou_mrl_guardian_check_external_escalation("MrLiouWord", MRLIOU_MRL_AUTH_CANONICAL) != MRLIOU_MRL_GUARDIAN_ALLOWED){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL root\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation("Mrliou_MRL_Kernel", MRLIOU_MRL_AUTH_CANONICAL) != MRLIOU_MRL_GUARDIAN_ALLOWED){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL internal\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation("Claude_Execution", MRLIOU_MRL_AUTH_OBSERVE) != MRLIOU_MRL_GUARDIAN_ALLOWED){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL observe\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation("Claude_Execution", MRLIOU_MRL_AUTH_EXECUTE) != MRLIOU_MRL_GUARDIAN_WARNING){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL execute\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation("Claude_Execution", MRLIOU_MRL_AUTH_CANONICAL) != MRLIOU_MRL_GUARDIAN_BLOCKED){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL claude_canon\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation("ChatGPT_Architecture", MRLIOU_MRL_AUTH_CANONICAL) != MRLIOU_MRL_GUARDIAN_BLOCKED){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL gpt_canon\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation("Firebase_Service", MRLIOU_MRL_AUTH_CANONICAL) != MRLIOU_MRL_GUARDIAN_BLOCKED){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL fb_canon\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation("Notion_Mirror", MRLIOU_MRL_AUTH_CANONICAL) != MRLIOU_MRL_GUARDIAN_BLOCKED){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL notion_canon\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation("Mrliou_MRL_Kernel", 9) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL auth_arg\n"); return 1; }
    if (mrliou_mrl_guardian_check_external_escalation(0, MRLIOU_MRL_AUTH_OBSERVE) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_guardian_external_escalation FAIL actor_arg\n"); return 1; }
    printf("GATE mrliou_mrl_guardian_external_escalation PASS (internal allowed; external observe/execute/canonical = allowed/warning/BLOCKED)\n");
    return 0;
}
