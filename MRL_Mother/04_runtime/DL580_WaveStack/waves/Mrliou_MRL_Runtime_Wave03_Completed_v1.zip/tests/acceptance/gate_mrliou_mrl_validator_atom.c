#include <stdio.h>
#include <string.h>
#include "mrliou_mrl/mrliou_mrl_validator.h"
#include "mrliou_mrl/mrliou_mrl_compiler.h"
#include "mrliou_mrl/mrliou_mrl_kernel.h"
int main(void){
    if (mrliou_mrl_validator_init() != MRLIOU_MRL_E_OK){ printf("GATE mrliou_mrl_validator_atom FAIL init\n"); return 1; }
    mrliou_mrl_atom_t atoms[4]; size_t na = 0;
    if (mrliou_mrl_compiler_compile("LAW-1: gate atom", atoms, 4, &na) != MRLIOU_MRL_E_OK || na < 1){
        printf("GATE mrliou_mrl_validator_atom FAIL compile\n"); return 1; }
    if (mrliou_mrl_validator_validate_atom(&atoms[0], sizeof atoms[0]) != MRLIOU_MRL_E_OK){
        printf("GATE mrliou_mrl_validator_atom FAIL valid\n"); return 1; }
    if (mrliou_mrl_validator_validate_atom(&atoms[0], 39) != MRLIOU_MRL_E_BOUNDARY){
        printf("GATE mrliou_mrl_validator_atom FAIL size\n"); return 1; }
    mrliou_mrl_atom_t bad = atoms[0]; bad.magic = 0;
    if (mrliou_mrl_validator_validate_atom(&bad, sizeof bad) != MRLIOU_MRL_E_MALFORMED){
        printf("GATE mrliou_mrl_validator_atom FAIL magic\n"); return 1; }
    bad = atoms[0]; bad.payload_lo ^= 0xFFULL;
    if (mrliou_mrl_validator_validate_atom(&bad, sizeof bad) != MRLIOU_MRL_E_MALFORMED){
        printf("GATE mrliou_mrl_validator_atom FAIL crc\n"); return 1; }
    bad = atoms[0]; bad.type_id = 0;
    if (mrliou_mrl_validator_validate_atom(&bad, sizeof bad) != MRLIOU_MRL_E_MALFORMED){
        printf("GATE mrliou_mrl_validator_atom FAIL type\n"); return 1; }
    if (mrliou_mrl_validator_validate_atom(0, sizeof bad) != MRLIOU_MRL_E_ARG){
        printf("GATE mrliou_mrl_validator_atom FAIL arg\n"); return 1; }
    printf("GATE mrliou_mrl_validator_atom PASS (40B size boundary, magic/type/crc malformed detection)\n");
    return 0;
}
