# 05_EXECUTION_TEST_REPORT

## 本地環境測試紀錄

### MRL 命名版

```bash
cd packages/MRL_3D_AI_Reconstruction_System_v1
python MRL_Main.py
python MRL_Main.py --config MRL_Config_mesh.yaml
python MRL_Main.py --config MRL_Config_video.yaml
```

結果：三項通過。

### Runtime 版

```bash
cd packages/MRL_3D_AI_Reconstruction_System_v1_REAL
python -m mrl3d.cli run --config config/demo_simulate.yaml
python -m mrl3d.cli run --config config/mesh_obj.yaml
python -m mrl3d.cli run --config config/video_frames.yaml
```

結果：三項通過。

## 注意

這些測試代表 sample data 與 adapter 管線可跑；不代表真 COLMAP / 真 OpenMVS 已完成。

