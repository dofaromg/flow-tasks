# 02_NO_REDUCTION_AUDIT｜不刪減交付紀錄

本包採取「保留既有版本 + 補齊缺口 + 標明驗證狀態」方式，不把其中一版擅自指定為唯一真實版。

## 未刪減原則

- 不刪 MRL 命名版。
- 不刪可安裝 runtime 版。
- 不刪公式文件。
- 不刪 sample outputs。
- 不把待驗證功能寫成已完成。
- 不把 `.lnk` 當成 3D 模型。
- 不把 video frame adapter 說成真 SfM。

## 已補上的缺口

- MRL 命名版新增 sample video：`sample_data/video/sample.mp4`
- REAL runtime 版新增 sample video：`data/2025_8_15.mp4`
- 已重新跑：demo / mesh / video adapter
- 已產出：video adapter outputs

## 仍待驗證

- 真實手機拍攝照片 → COLMAP → text model → heatmap 報告
- 真實影片 → frames → COLMAP → text model → heatmap 報告
- OpenMVS dense reconstruction / mesh reconstruction
- PLY / OBJ face normal / geometry surface heatmap
- NBV 具體外參建議
- GLB / textured mesh 主流輸出

