# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np


def MRL_Attention_Simple(imgs: dict, edge_weight: float = 0.35, center_weight: float = 0.65):
    maps = {}
    for cid, im in imgs.items():
        h, w = im.shape[:2]
        yy, xx = np.mgrid[0:h, 0:w]
        cx, cy = w / 2.0, h / 2.0
        center = 1.0 - np.sqrt(((xx - cx) / max(w / 2.0, 1e-6)) ** 2 + ((yy - cy) / max(h / 2.0, 1e-6)) ** 2)
        center = np.clip(center, 0.0, 1.0)
        edge = np.zeros((h, w), dtype=np.float32)
        try:
            import cv2
            gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY) if im.ndim == 3 else im
            sx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
            sy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
            edge = np.sqrt(sx * sx + sy * sy)
            edge = edge / (float(edge.max()) + 1e-6)
        except Exception:
            pass
        attn = center_weight * center + edge_weight * edge
        attn = attn / (float(attn.max()) + 1e-6)
        maps[cid] = attn.astype(np.float32)
    return maps
