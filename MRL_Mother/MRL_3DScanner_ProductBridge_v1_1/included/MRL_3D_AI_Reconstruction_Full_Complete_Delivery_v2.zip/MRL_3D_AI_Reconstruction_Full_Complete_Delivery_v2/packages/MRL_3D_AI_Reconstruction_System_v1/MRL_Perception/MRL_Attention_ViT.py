# -*- coding: utf-8 -*-
"""Optional ViT attention backend.

This module attempts to use torch/timm. If unavailable, caller should fall back to simple attention.
"""
from __future__ import annotations

import numpy as np


def MRL_Attention_ViT(imgs: dict, model_name: str = "vit_tiny_patch16_224"):
    try:
        import torch
        import torch.nn.functional as F
        from timm import create_model
        import cv2
    except Exception as exc:
        raise RuntimeError("ViT backend requires torch, timm and opencv-python") from exc

    model = create_model(model_name, pretrained=True).eval()
    maps = {}
    mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
    std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
    with torch.no_grad():
        for cid, im in imgs.items():
            H, W = im.shape[:2]
            x = cv2.resize(im, (224, 224)).astype(np.float32) / 255.0
            x = x[:, :, ::-1]
            x = (x - mean) / std
            xt = torch.from_numpy(x.transpose(2, 0, 1)).unsqueeze(0)
            feats = model.forward_features(xt)
            if feats.ndim == 3:
                B, N, C = feats.shape
                if N > 1:
                    P = int((N - 1) ** 0.5)
                    toks = feats[:, 1:1 + P * P, :].reshape(B, P, P, C)
                    cls = feats[:, 0:1, :].reshape(B, 1, 1, C)
                    sim = F.cosine_similarity(toks, cls, dim=-1).clamp(min=0)
                    sim = (sim - sim.min()) / (sim.max() - sim.min() + 1e-6)
                    small = sim[0].cpu().numpy()
                else:
                    small = np.ones((14, 14), dtype=np.float32)
            elif feats.ndim == 4:
                B, C, h, w = feats.shape
                cls = feats.mean(dim=(2, 3), keepdim=True)
                sim = F.cosine_similarity(feats, cls, dim=1).clamp(min=0)
                sim = (sim - sim.min()) / (sim.max() - sim.min() + 1e-6)
                small = sim[0].cpu().numpy()
            else:
                small = np.ones((14, 14), dtype=np.float32)
            small_t = torch.from_numpy(small)[None, None, :, :].float()
            up = F.interpolate(small_t, size=(H, W), mode="bilinear", align_corners=False)[0, 0].numpy()
            up = (up - up.min()) / (up.max() - up.min() + 1e-6)
            maps[cid] = up.astype(np.float32)
    return maps
