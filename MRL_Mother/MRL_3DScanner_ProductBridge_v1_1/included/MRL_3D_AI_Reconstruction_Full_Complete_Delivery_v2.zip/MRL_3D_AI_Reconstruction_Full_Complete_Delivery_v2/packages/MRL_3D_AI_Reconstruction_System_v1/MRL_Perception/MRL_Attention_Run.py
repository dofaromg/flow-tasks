# -*- coding: utf-8 -*-
from __future__ import annotations

from MRL_Perception.MRL_Attention_Simple import MRL_Attention_Simple


def MRL_Attention_Run(cfg: dict, imgs: dict):
    attn_cfg = cfg.get("attention", {})
    backend = attn_cfg.get("backend", "simple").lower()
    if backend == "vit":
        try:
            from MRL_Perception.MRL_Attention_ViT import MRL_Attention_ViT
            return MRL_Attention_ViT(imgs, attn_cfg.get("vit_model", "vit_tiny_patch16_224"))
        except Exception as exc:
            print(f"[MRL_Attention] ViT unavailable, fallback to simple: {exc}")
    return MRL_Attention_Simple(
        imgs,
        edge_weight=float(attn_cfg.get("edge_weight", 0.35)),
        center_weight=float(attn_cfg.get("center_weight", 0.65)),
    )
