# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import numpy as np


def _load_video_frames(video_path: str, images_dir: str, sample_fps: int = 2):
    try:
        import cv2
    except Exception as exc:
        raise RuntimeError("Video input requires opencv-python") from exc
    os.makedirs(images_dir, exist_ok=True)
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    step = max(int(round(src_fps / max(sample_fps, 1))), 1)
    imgs = {}
    idx = 0
    saved = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % step == 0:
            key = str(saved)
            imgs[key] = frame
            cv2.imwrite(os.path.join(images_dir, f"frame_{saved:04d}.jpg"), frame)
            saved += 1
        idx += 1
    cap.release()
    cams = {key: {"H": im.shape[0], "W": im.shape[1], "name": f"frame_{int(key):04d}.jpg"} for key, im in imgs.items()}
    tracks = {key: [] for key in imgs}
    points = {}
    return cams, points, tracks, imgs


def _simulate_scene():
    """Fallback minimal scene; useful when no external data is available."""
    cams = {"cam0": {"H": 64, "W": 64, "name": "sim0"}, "cam1": {"H": 64, "W": 64, "name": "sim1"}}
    points = {0: (0.0, 0.0, 1.0), 1: (0.5, 0.5, 1.0)}
    tracks = {"cam0": [(32, 32, 0, 1.0), (40, 40, 1, 2.0)], "cam1": [(30, 30, 0, 1.5), (45, 45, 1, 0.5)]}
    imgs = {"cam0": np.zeros((64, 64, 3), dtype=np.uint8), "cam1": np.zeros((64, 64, 3), dtype=np.uint8)}
    return cams, points, tracks, imgs


def MRL_Load_Input(cfg: dict):
    input_cfg = cfg.get("input", {})
    input_type = input_cfg.get("type", "colmap").lower()
    if input_type == "colmap":
        from MRL_Reconstruction.MRL_COLMAP_Loader import MRL_Load_COLMAP
        return MRL_Load_COLMAP(
            input_cfg.get("colmap_dir", "./sample_data/colmap"),
            input_cfg.get("images_dir", cfg.get("images_dir", "./sample_data/images")),
            bool(input_cfg.get("read_images", True)),
        )
    if input_type == "mesh_obj":
        from MRL_Reconstruction.MRL_Mesh_Loader import MRL_Project_OBJ_To_Synthetic_Cameras
        return MRL_Project_OBJ_To_Synthetic_Cameras(input_cfg.get("mesh_path", "./sample_data/mesh/cube.obj"), input_cfg.get("synth", {}))
    if input_type == "video":
        return _load_video_frames(input_cfg["video_path"], cfg.get("images_dir", "./sample_data/images"), int(input_cfg.get("sample_fps", 2)))
    if input_type == "simulate":
        return _simulate_scene()
    raise ValueError(f"Unsupported input.type: {input_type}")
