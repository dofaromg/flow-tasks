# -*- coding: utf-8 -*-
"""MRL 3D AI Reconstruction System v1 entrypoint."""
import argparse
import yaml
from MRL_Core.MRL_Pipeline_Core import MRL_Run


def main() -> None:
    parser = argparse.ArgumentParser(description="MRL 3D AI Reconstruction System v1")
    parser.add_argument("--config", default="MRL_Config.yaml", help="Path to YAML config")
    args = parser.parse_args()
    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    MRL_Run(cfg)


if __name__ == "__main__":
    main()
