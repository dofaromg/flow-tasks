# MRL 3D AI Reconstruction Run Report

Input objective: `error`

## Camera Metrics

| cam_id | p50 | p90 | max | mean | count | pixel_coverage |
|---|---:|---:|---:|---:|---:|---:|
| 0 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0 | 0.000000 |
| 1 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0 | 0.000000 |
| 2 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0 | 0.000000 |
| 3 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0 | 0.000000 |
| 4 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0 | 0.000000 |
| 5 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0 | 0.000000 |
| 6 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0 | 0.000000 |
| 7 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0 | 0.000000 |

## Suggestions

### Image 0
- tile=[0, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[0, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
### Image 1
- tile=[0, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[0, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
### Image 2
- tile=[0, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[0, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
### Image 3
- tile=[0, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[0, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
### Image 4
- tile=[0, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[0, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
### Image 5
- tile=[0, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[0, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
### Image 6
- tile=[0, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[0, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
### Image 7
- tile=[0, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[0, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region