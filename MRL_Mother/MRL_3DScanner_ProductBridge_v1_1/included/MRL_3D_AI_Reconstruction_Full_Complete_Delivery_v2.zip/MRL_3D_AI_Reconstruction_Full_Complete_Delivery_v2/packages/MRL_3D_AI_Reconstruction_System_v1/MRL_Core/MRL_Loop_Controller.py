# -*- coding: utf-8 -*-
from __future__ import annotations

from copy import deepcopy
from MRL_Core.MRL_Pipeline_Core import MRL_Run


def MRL_Run_Loop(cfg: dict, max_loop: int = 1):
    """Simple loop controller placeholder for repeated capture/re-run cycles."""
    results = []
    current = deepcopy(cfg)
    for _ in range(max_loop):
        results.append(MRL_Run(current))
    return results
