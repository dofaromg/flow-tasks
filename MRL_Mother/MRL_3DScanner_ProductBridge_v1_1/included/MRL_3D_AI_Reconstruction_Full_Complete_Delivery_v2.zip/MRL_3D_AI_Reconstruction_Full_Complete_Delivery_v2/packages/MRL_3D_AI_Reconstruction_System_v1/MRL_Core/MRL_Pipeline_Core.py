# -*- coding: utf-8 -*-
from __future__ import annotations

import logging

from MRL_Perception.MRL_Input_Loader import MRL_Load_Input
from MRL_Perception.MRL_Attention_Run import MRL_Attention_Run
from MRL_Error.MRL_Error_Map import MRL_Build_Error_Maps
from MRL_Fusion.MRL_Attention_Fusion import MRL_Fuse_Error_Attention
from MRL_Context.MRL_Camera_Graph import MRL_Build_Camera_Graph
from MRL_Decision.MRL_NBV_Generator import MRL_Generate_NBV
from MRL_Fix.MRL_Reshoot_Controller import MRL_Apply_Fix
from MRL_Visualization.MRL_Output_Exporter import MRL_Export

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")


def MRL_Run(cfg: dict):
    logging.info("MRL input loading started")
    cams, points, tracks, imgs = MRL_Load_Input(cfg)
    logging.info("Loaded cameras=%d points=%d track_views=%d", len(cams), len(points), len(tracks))

    logging.info("MRL attention started")
    attention_maps = MRL_Attention_Run(cfg, imgs)

    logging.info("MRL error/coverage map started")
    heatmaps, metrics = MRL_Build_Error_Maps(cfg, cams, tracks, attention_maps)
    fused = MRL_Fuse_Error_Attention(metrics, heatmaps)

    logging.info("MRL context graph started")
    links = MRL_Build_Camera_Graph(cfg, cams, fused["heatmaps"])

    logging.info("MRL NBV / gap suggestion started")
    suggestions = MRL_Generate_NBV(cfg, cams, fused["heatmaps"], links)
    MRL_Apply_Fix(suggestions)

    logging.info("MRL export started")
    out_dir = MRL_Export(cfg, cams, fused["metrics"], links, suggestions, fused["heatmaps"], imgs)
    logging.info("MRL completed. Output directory: %s", out_dir)
    return out_dir
