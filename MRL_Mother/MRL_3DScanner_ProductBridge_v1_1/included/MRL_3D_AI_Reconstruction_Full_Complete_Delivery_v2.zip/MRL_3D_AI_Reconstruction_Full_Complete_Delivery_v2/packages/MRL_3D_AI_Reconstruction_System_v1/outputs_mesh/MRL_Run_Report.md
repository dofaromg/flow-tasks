# MRL 3D AI Reconstruction Run Report

Input objective: `coverage`

## Camera Metrics

| cam_id | p50 | p90 | max | mean | count | pixel_coverage |
|---|---:|---:|---:|---:|---:|---:|
| 0 | 0.1627 | 0.4415 | 0.4415 | 0.2042 | 8 | 0.000026 |
| 1 | 0.0824 | 0.5067 | 0.6417 | 0.2003 | 7 | 0.000023 |
| 2 | 0.1627 | 0.4415 | 0.4415 | 0.2042 | 8 | 0.000026 |
| 3 | 0.0824 | 0.5067 | 0.6417 | 0.2003 | 7 | 0.000023 |
| 4 | 0.1627 | 0.4415 | 0.4415 | 0.2042 | 8 | 0.000026 |
| 5 | 0.0824 | 0.5067 | 0.6417 | 0.2003 | 7 | 0.000023 |
| 6 | 0.1627 | 0.4415 | 0.4415 | 0.2042 | 8 | 0.000026 |
| 7 | 0.0824 | 0.5067 | 0.6417 | 0.2003 | 7 | 0.000023 |

## Suggestions

### Image 0
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[2, 0] score=0.000000 hint=reshoot/inspect middle-left region
### Image 1
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 3] score=0.000000 hint=reshoot/inspect upper-right region
### Image 2
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[2, 0] score=0.000000 hint=reshoot/inspect middle-left region
### Image 3
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 3] score=0.000000 hint=reshoot/inspect upper-right region
### Image 4
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[2, 0] score=0.000000 hint=reshoot/inspect middle-left region
### Image 5
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 3] score=0.000000 hint=reshoot/inspect upper-right region
### Image 6
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 3] score=0.000000 hint=reshoot/inspect upper-right region
- tile=[2, 0] score=0.000000 hint=reshoot/inspect middle-left region
### Image 7
- tile=[0, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[0, 2] score=0.000000 hint=reshoot/inspect upper-center region
- tile=[1, 0] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 1] score=0.000000 hint=reshoot/inspect upper-left region
- tile=[1, 3] score=0.000000 hint=reshoot/inspect upper-right region