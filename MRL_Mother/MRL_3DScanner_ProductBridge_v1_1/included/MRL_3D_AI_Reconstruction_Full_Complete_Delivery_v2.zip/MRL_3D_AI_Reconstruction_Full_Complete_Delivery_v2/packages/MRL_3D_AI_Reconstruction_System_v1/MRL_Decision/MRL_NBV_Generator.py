# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np


def _tile_scores(hm: np.ndarray, tiles_rc, objective: str):
    r, c = int(tiles_rc[0]), int(tiles_rc[1])
    H, W = hm.shape
    rows = np.linspace(0, H, r + 1, dtype=int)
    cols = np.linspace(0, W, c + 1, dtype=int)
    scores = []
    for i in range(r):
        for j in range(c):
            sub = hm[rows[i]:rows[i+1], cols[j]:cols[j+1]]
            score = float(sub.mean()) if sub.size else 0.0
            scores.append(((i, j), score))
    scores.sort(key=lambda x: x[1], reverse=(objective != "coverage"))
    return scores


def _tile_hint(tile_rc, tiles_rc):
    i, j = tile_rc
    r, c = tiles_rc
    vertical = "upper" if i < r / 3 else "lower" if i >= 2 * r / 3 else "middle"
    horizontal = "left" if j < c / 3 else "right" if j >= 2 * c / 3 else "center"
    return f"reshoot/inspect {vertical}-{horizontal} region"


def MRL_Generate_NBV(cfg: dict, cams: dict, heatmaps: dict, links: dict):
    sug_cfg = cfg.get("suggestion", {})
    tiles = sug_cfg.get("tiles", [4, 4])
    topk = int(sug_cfg.get("topk", 5))
    objective = sug_cfg.get("objective", "error").lower()
    per_image = []
    for cam_id, hm in heatmaps.items():
        s = _tile_scores(hm, tiles, objective)[:topk]
        per_image.append({
            "image_id": cam_id,
            "top_tiles": [
                {"tile_rc": [int(i), int(j)], "score": float(score), "hint": _tile_hint((i, j), tiles)}
                for (i, j), score in s
            ]
        })
    return {"version": "1.0", "objective": objective, "per_image": per_image, "context_edges": links.get("edges", [])}
