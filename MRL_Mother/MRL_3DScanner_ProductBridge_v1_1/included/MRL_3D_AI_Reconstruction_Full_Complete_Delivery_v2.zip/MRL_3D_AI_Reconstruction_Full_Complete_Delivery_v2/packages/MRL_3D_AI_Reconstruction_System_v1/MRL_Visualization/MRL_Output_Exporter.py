# -*- coding: utf-8 -*-
from __future__ import annotations

import csv
import json
import os
from typing import Optional
import numpy as np


def _save_heatmap_png(path: str, heatmap: np.ndarray, image: Optional[np.ndarray] = None):
    try:
        import cv2
        hm = heatmap.astype(np.float32)
        hm = hm - hm.min()
        hm = hm / (hm.max() + 1e-6)
        color = cv2.applyColorMap((hm * 255).astype(np.uint8), cv2.COLORMAP_JET)
        if image is not None and image.shape[:2] == hm.shape:
            overlay = cv2.addWeighted(image, 0.55, color, 0.45, 0.0)
        else:
            overlay = color
        cv2.imwrite(path, overlay)
    except Exception:
        pass


def MRL_Export(cfg: dict, cams: dict, metrics: dict, links: dict, suggestions: dict, heatmaps: dict, imgs: dict):
    out_dir = cfg.get("output", {}).get("out_dir", "./outputs")
    save_png = bool(cfg.get("output", {}).get("save_png", True))
    save_overlay = bool(cfg.get("output", {}).get("save_overlay", True))
    os.makedirs(out_dir, exist_ok=True)

    def write_json(name, obj):
        with open(os.path.join(out_dir, name), "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)

    write_json("cameras.json", cams)
    write_json("metrics.json", metrics)
    write_json("links.json", links)
    write_json("suggestions.json", suggestions)

    with open(os.path.join(out_dir, "metrics_summary.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["cam_id", "p50", "p90", "max", "mean", "count", "pixel_coverage"])
        for cid, s in metrics.get("summary", {}).items():
            w.writerow([cid, s.get("p50", 0), s.get("p90", 0), s.get("max", 0), s.get("mean", 0), s.get("count", 0), s.get("pixel_coverage", 0)])

    for cid, hm in heatmaps.items():
        np.save(os.path.join(out_dir, f"heatmap_{cid}.npy"), hm)
        if save_png:
            img = imgs.get(cid) if save_overlay else None
            _save_heatmap_png(os.path.join(out_dir, f"heatmap_{cid}.png"), hm, img)

    report = [
        "# MRL 3D AI Reconstruction Run Report",
        "",
        f"Input objective: `{metrics.get('objective', 'unknown')}`",
        "",
        "## Camera Metrics",
        "",
        "| cam_id | p50 | p90 | max | mean | count | pixel_coverage |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for cid, s in metrics.get("summary", {}).items():
        report.append(f"| {cid} | {s.get('p50',0):.4f} | {s.get('p90',0):.4f} | {s.get('max',0):.4f} | {s.get('mean',0):.4f} | {s.get('count',0)} | {s.get('pixel_coverage',0):.6f} |")
    report.extend(["", "## Suggestions", ""])
    for item in suggestions.get("per_image", []):
        report.append(f"### Image {item['image_id']}")
        for tile in item.get("top_tiles", []):
            report.append(f"- tile={tile['tile_rc']} score={tile['score']:.6f} hint={tile.get('hint','')}")
    with open(os.path.join(out_dir, "MRL_Run_Report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(report))
    return out_dir
