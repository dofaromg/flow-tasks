# MRL_3D_AI_Reconstruction_System_v1｜True Delivery

這是一套可直接建檔、安裝、執行的最小實作版。它把前面商討的「3D 立體成像 + AI 注意力 + 上下文連結 + 誤差/覆蓋缺口建議」收斂成同一條管線。

## 目前支援

- COLMAP text model：`cameras.txt / images.txt / points3D.txt`
- OBJ mesh coverage：讀取 `.obj` 頂點並用合成環繞相機估算覆蓋缺口
- MP4 video adapter：切幀；若要真 3D 誤差，需要再跑 SfM/COLMAP
- AI attention backend：`simple` 可立即跑；`vit` 預留 PyTorch/timm 版本
- 產出：`metrics.json`, `metrics_summary.csv`, `links.json`, `suggestions.json`, `heatmap_*.npy`, `heatmap_*.png`, `MRL_Run_Report.md`

## 安裝

```bash
cd MRL_3D_AI_Reconstruction_System_v1
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 直接執行內建 COLMAP-style sample

```bash
python MRL_Main.py --config MRL_Config.yaml
```

輸出在：

```text
outputs/
```

## 使用自己的 COLMAP 資料

放入：

```text
sample_data/colmap/cameras.txt
sample_data/colmap/images.txt
sample_data/colmap/points3D.txt
sample_data/images/<images.txt 裡的檔名>
```

或修改 `MRL_Config.yaml`：

```yaml
input:
  type: colmap
  colmap_dir: ./your_colmap_text_folder
  images_dir: ./your_images_folder
  read_images: true
```

## 使用 OBJ Mesh 覆蓋分析

```yaml
input:
  type: mesh_obj
  mesh_path: ./sample_data/mesh/cube.obj
suggestion:
  objective: coverage
```

然後執行：

```bash
python MRL_Main.py --config MRL_Config.yaml
```

## 注意

這不是完整商業產品，但它是「真實可跑骨架」。後續可接 OpenMVS、NeRF/Gaussian Splatting、Web viewer、完整補拍位姿估計。
