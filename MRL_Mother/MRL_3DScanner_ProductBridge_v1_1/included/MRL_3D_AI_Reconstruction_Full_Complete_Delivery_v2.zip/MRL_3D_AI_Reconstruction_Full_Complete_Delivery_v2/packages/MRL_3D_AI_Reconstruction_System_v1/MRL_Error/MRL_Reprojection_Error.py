# -*- coding: utf-8 -*-
from __future__ import annotations

from MRL_Utils.MRL_Geometry import MRL_huber


def MRL_Robust_Error(value: float, robust: str = "huber", delta: float = 2.0) -> float:
    if robust == "huber":
        return MRL_huber(value, delta)
    return float(value)
