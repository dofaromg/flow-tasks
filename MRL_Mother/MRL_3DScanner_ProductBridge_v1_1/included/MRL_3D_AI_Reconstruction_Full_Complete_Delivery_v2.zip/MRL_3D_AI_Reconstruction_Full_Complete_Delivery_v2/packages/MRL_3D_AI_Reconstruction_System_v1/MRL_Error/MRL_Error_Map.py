# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np
from MRL_Error.MRL_Reprojection_Error import MRL_Robust_Error


def _stats(values):
    arr = np.asarray(values, dtype=np.float32)
    if arr.size == 0:
        return {"p50": 0.0, "p90": 0.0, "max": 0.0, "mean": 0.0, "count": 0}
    return {
        "p50": float(np.percentile(arr, 50)),
        "p90": float(np.percentile(arr, 90)),
        "max": float(arr.max()),
        "mean": float(arr.mean()),
        "count": int(arr.size),
    }


def MRL_Build_Error_Maps(cfg: dict, cams: dict, tracks: dict, attention_maps: dict):
    robust = cfg.get("error", {}).get("robust", "huber")
    delta = float(cfg.get("error", {}).get("huber_delta", 2.0))
    objective = cfg.get("suggestion", {}).get("objective", "error").lower()
    heatmaps = {}
    weighted_values = {}
    metrics = {"p90_by_cam": {}, "summary": {}, "objective": objective}

    for cam_id, cam in cams.items():
        H, W = int(cam["H"]), int(cam["W"])
        hm = np.zeros((H, W), dtype=np.float32)
        vals = []
        attn = attention_maps.get(cam_id)
        if attn is None:
            attn = np.ones((H, W), dtype=np.float32)
        for (u, v, pid, value) in tracks.get(cam_id, []):
            ui, vi = int(round(u)), int(round(v))
            if 0 <= ui < W and 0 <= vi < H:
                w = float(attn[vi, ui])
                if objective == "coverage":
                    score = float(value) * max(w, 0.05)
                else:
                    score = w * MRL_Robust_Error(float(value), robust, delta)
                hm[vi, ui] = max(float(hm[vi, ui]), score)
                vals.append(score)
        heatmaps[cam_id] = hm
        weighted_values[cam_id] = vals
        s = _stats(vals)
        metrics["p90_by_cam"][cam_id] = s["p90"]
        # Coverage here means how much of the output image was touched by tracks.
        metrics["summary"][cam_id] = {**s, "pixel_coverage": float((hm > 0).mean())}
    return heatmaps, metrics
