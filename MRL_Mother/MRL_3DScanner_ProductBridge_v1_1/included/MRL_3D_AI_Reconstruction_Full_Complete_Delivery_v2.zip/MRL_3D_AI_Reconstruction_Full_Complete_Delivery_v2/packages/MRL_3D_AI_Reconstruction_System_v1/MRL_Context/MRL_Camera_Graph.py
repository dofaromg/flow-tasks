# -*- coding: utf-8 -*-
from __future__ import annotations

import numpy as np


def _corr(a: np.ndarray, b: np.ndarray) -> float:
    aa = a.reshape(-1).astype(np.float64)
    bb = b.reshape(-1).astype(np.float64)
    if aa.size < 2 or bb.size < 2 or aa.std() < 1e-9 or bb.std() < 1e-9:
        return 0.0
    return float(np.corrcoef(aa, bb)[0, 1])


def MRL_Build_Camera_Graph(cfg: dict, cams: dict, heatmaps: dict):
    threshold = float(cfg.get("context", {}).get("neg_corr_threshold", -0.2))
    ids = list(heatmaps.keys())
    edges = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            c = _corr(heatmaps[ids[i]], heatmaps[ids[j]])
            if c < threshold:
                edges.append({"a": ids[i], "b": ids[j], "corr": c, "relation": "complementary"})
    return {"edges": edges, "threshold": threshold}
