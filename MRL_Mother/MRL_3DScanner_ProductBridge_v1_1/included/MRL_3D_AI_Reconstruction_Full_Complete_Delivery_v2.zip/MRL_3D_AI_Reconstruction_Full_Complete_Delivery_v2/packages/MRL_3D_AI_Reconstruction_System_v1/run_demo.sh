#!/usr/bin/env bash
set -e
python MRL_Main.py --config MRL_Config.yaml
