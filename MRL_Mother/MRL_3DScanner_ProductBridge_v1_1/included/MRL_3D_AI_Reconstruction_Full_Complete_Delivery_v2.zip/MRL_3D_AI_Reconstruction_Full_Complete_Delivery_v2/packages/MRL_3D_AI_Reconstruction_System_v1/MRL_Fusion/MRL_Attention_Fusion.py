# -*- coding: utf-8 -*-
from __future__ import annotations


def MRL_Fuse_Error_Attention(metrics: dict, heatmaps: dict):
    """Currently a pass-through fusion layer.

    Kept as a stable expansion point for future NeRF/GS masks and semantic segmentation.
    """
    return {"metrics": metrics, "heatmaps": heatmaps}
