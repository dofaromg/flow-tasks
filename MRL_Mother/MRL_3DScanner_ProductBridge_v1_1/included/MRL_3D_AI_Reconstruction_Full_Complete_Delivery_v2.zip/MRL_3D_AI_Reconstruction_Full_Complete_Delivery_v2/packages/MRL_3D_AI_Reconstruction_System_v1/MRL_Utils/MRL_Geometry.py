# -*- coding: utf-8 -*-
"""Geometry utilities for MRL 3D AI Reconstruction."""
from __future__ import annotations

import math
from typing import Iterable, Optional, Tuple
import numpy as np


def MRL_quat_to_rot(qw: float, qx: float, qy: float, qz: float) -> np.ndarray:
    """COLMAP quaternion (qw, qx, qy, qz) to world-to-camera rotation matrix."""
    n = math.sqrt(qw * qw + qx * qx + qy * qy + qz * qz)
    if n <= 1e-12:
        raise ValueError("Invalid zero quaternion")
    qw, qx, qy, qz = qw / n, qx / n, qy / n, qz / n
    return np.array([
        [1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw)],
        [2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw)],
        [2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy)],
    ], dtype=np.float64)


def MRL_rot_to_quat(R: np.ndarray) -> Tuple[float, float, float, float]:
    """Rotation matrix to quaternion (qw, qx, qy, qz)."""
    R = np.asarray(R, dtype=np.float64)
    tr = np.trace(R)
    if tr > 0:
        s = math.sqrt(tr + 1.0) * 2
        qw = 0.25 * s
        qx = (R[2, 1] - R[1, 2]) / s
        qy = (R[0, 2] - R[2, 0]) / s
        qz = (R[1, 0] - R[0, 1]) / s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        qw = (R[2, 1] - R[1, 2]) / s
        qx = 0.25 * s
        qy = (R[0, 1] + R[1, 0]) / s
        qz = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        qw = (R[0, 2] - R[2, 0]) / s
        qx = (R[0, 1] + R[1, 0]) / s
        qy = 0.25 * s
        qz = (R[1, 2] + R[2, 1]) / s
    else:
        s = math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        qw = (R[1, 0] - R[0, 1]) / s
        qx = (R[0, 2] + R[2, 0]) / s
        qy = (R[1, 2] + R[2, 1]) / s
        qz = 0.25 * s
    n = math.sqrt(qw*qw + qx*qx + qy*qy + qz*qz)
    return qw/n, qx/n, qy/n, qz/n


def MRL_look_at_rotation(camera_pos: np.ndarray, target: np.ndarray, up: np.ndarray | None = None) -> np.ndarray:
    """Create a world-to-camera rotation whose camera z-axis looks at target."""
    camera_pos = np.asarray(camera_pos, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    up = np.asarray(up if up is not None else [0.0, 1.0, 0.0], dtype=np.float64)
    forward = target - camera_pos
    forward /= np.linalg.norm(forward) + 1e-12
    right = np.cross(up, forward)
    if np.linalg.norm(right) < 1e-8:
        up = np.asarray([0.0, 0.0, 1.0], dtype=np.float64)
        right = np.cross(up, forward)
    right /= np.linalg.norm(right) + 1e-12
    cam_up = np.cross(forward, right)
    cam_up /= np.linalg.norm(cam_up) + 1e-12
    return np.stack([right, cam_up, forward], axis=0)


def MRL_project_point(
    xyz_world: Iterable[float],
    R: np.ndarray,
    t: np.ndarray,
    K: Tuple[float, float, float, float],
    model: str = "PINHOLE",
    params: Optional[Iterable[float]] = None,
) -> Optional[Tuple[float, float]]:
    """Project a world point to pixel coordinates with simple COLMAP camera distortion support."""
    X = np.asarray(xyz_world, dtype=np.float64).reshape(3, 1)
    R = np.asarray(R, dtype=np.float64)
    t = np.asarray(t, dtype=np.float64).reshape(3, 1)
    xc = (R @ X + t).flatten()
    if xc[2] <= 1e-9:
        return None
    x = xc[0] / xc[2]
    y = xc[1] / xc[2]
    fx, fy, cx, cy = K
    model = (model or "PINHOLE").upper()
    params = list(params or [])

    if model == "SIMPLE_RADIAL" and len(params) >= 4:
        k1 = params[3]
        r2 = x * x + y * y
        x *= (1 + k1 * r2)
        y *= (1 + k1 * r2)
    elif model in ("OPENCV", "OPENCV_FISHEYE"):
        # Approximate OPENCV radial/tangential model. Fisheye is approximated to keep the pipeline runnable.
        k1 = params[4] if len(params) > 4 else 0.0
        k2 = params[5] if len(params) > 5 else 0.0
        p1 = params[6] if len(params) > 6 else 0.0
        p2 = params[7] if len(params) > 7 else 0.0
        k3 = params[8] if len(params) > 8 else 0.0
        r2 = x * x + y * y
        radial = 1 + k1 * r2 + k2 * (r2 ** 2) + k3 * (r2 ** 3)
        x_dist = x * radial + 2 * p1 * x * y + p2 * (r2 + 2 * x * x)
        y_dist = y * radial + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y
        x, y = x_dist, y_dist
    elif model == "RADIAL":
        k1 = params[4] if len(params) > 4 else 0.0
        k2 = params[5] if len(params) > 5 else 0.0
        r2 = x * x + y * y
        radial = 1 + k1 * r2 + k2 * (r2 ** 2)
        x *= radial
        y *= radial

    return fx * x + cx, fy * y + cy


def MRL_huber(e: float, delta: float = 2.0) -> float:
    e = abs(float(e))
    if e <= delta:
        return 0.5 * e * e
    return delta * (e - 0.5 * delta)
