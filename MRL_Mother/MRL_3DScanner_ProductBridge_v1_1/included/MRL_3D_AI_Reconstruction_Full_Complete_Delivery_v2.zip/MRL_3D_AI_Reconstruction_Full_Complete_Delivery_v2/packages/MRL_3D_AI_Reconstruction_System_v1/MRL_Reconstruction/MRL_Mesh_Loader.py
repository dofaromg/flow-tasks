# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Dict, Tuple
import numpy as np

from MRL_Utils.MRL_Geometry import MRL_look_at_rotation


def MRL_Load_OBJ_Vertices(mesh_path: str) -> np.ndarray:
    vertices = []
    with open(mesh_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith("v "):
                toks = line.split()
                if len(toks) >= 4:
                    vertices.append((float(toks[1]), float(toks[2]), float(toks[3])))
    if not vertices:
        raise RuntimeError(f"OBJ has no vertices: {mesh_path}")
    return np.asarray(vertices, dtype=np.float64)


def MRL_Project_OBJ_To_Synthetic_Cameras(mesh_path: str, synth_cfg: dict):
    """Create synthetic cameras around an OBJ and generate coverage tracks.

    Track value is 1.0 and should be interpreted as coverage, not reprojection error.
    """
    V = MRL_Load_OBJ_Vertices(mesh_path)
    num_cams = int(synth_cfg.get("num_cams", 8))
    radius_scale = float(synth_cfg.get("radius_scale", 2.0))
    res = synth_cfg.get("res", [640, 480])
    W, H = int(res[0]), int(res[1])
    fov_deg = float(synth_cfg.get("fov_deg", 60.0))
    fx = fy = (W / 2.0) / np.tan(np.deg2rad(fov_deg) / 2.0)
    cx, cy = W / 2.0, H / 2.0

    center = V.mean(axis=0)
    radius = max(np.linalg.norm(V.max(axis=0) - V.min(axis=0)) / 2.0 * radius_scale, 1e-2)
    cams: Dict[str, dict] = {}
    tracks: Dict[str, list] = {}
    imgs: Dict[str, np.ndarray] = {}
    points = {int(i): (float(p[0]), float(p[1]), float(p[2])) for i, p in enumerate(V)}

    for k, theta in enumerate(np.linspace(0, 2 * np.pi, num_cams, endpoint=False)):
        cam_pos = center + np.array([radius * np.cos(theta), radius * 0.15, radius * np.sin(theta)])
        R = MRL_look_at_rotation(cam_pos, center)
        t = -R @ cam_pos
        X = (R @ V.T + t.reshape(3, 1))
        z = X[2, :]
        vis = z > 1e-8
        x = X[0, vis] / z[vis]
        y = X[1, vis] / z[vis]
        u = fx * x + cx
        v = fy * y + cy
        visible_ids = np.where(vis)[0]
        obs = []
        for ui, vi, pid in zip(u, v, visible_ids):
            if 0 <= ui < W and 0 <= vi < H:
                obs.append((float(ui), float(vi), int(pid), 1.0))
        key = str(k)
        cams[key] = {"H": H, "W": W, "name": f"synthetic_cam_{k:02d}"}
        tracks[key] = obs
        imgs[key] = np.zeros((H, W, 3), dtype=np.uint8)
    return cams, points, tracks, imgs
