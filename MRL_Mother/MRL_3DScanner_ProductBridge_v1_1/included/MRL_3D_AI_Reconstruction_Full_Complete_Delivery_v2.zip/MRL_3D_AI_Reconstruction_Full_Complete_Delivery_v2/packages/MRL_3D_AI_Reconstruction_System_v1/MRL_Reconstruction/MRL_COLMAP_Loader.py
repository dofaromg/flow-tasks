# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import math
from typing import Dict, Tuple
import numpy as np

from MRL_Utils.MRL_Geometry import MRL_quat_to_rot, MRL_project_point


def _parse_cameras_txt(path: str) -> Dict[int, dict]:
    cams: Dict[int, dict] = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            toks = line.split()
            cam_id = int(toks[0])
            model = toks[1]
            width = int(toks[2])
            height = int(toks[3])
            params = list(map(float, toks[4:]))
            if model == "PINHOLE":
                fx, fy, cx, cy = params[:4]
            elif model == "SIMPLE_PINHOLE":
                f0, cx, cy = params[:3]
                fx = fy = f0
            elif model == "SIMPLE_RADIAL":
                f0, cx, cy = params[:3]
                fx = fy = f0
            else:
                if len(params) >= 4:
                    fx, fy, cx, cy = params[:4]
                elif len(params) >= 3:
                    f0, cx, cy = params[:3]
                    fx = fy = f0
                else:
                    fx = fy = 1000.0
                    cx, cy = width / 2.0, height / 2.0
            cams[cam_id] = {
                "model": model,
                "width": width,
                "height": height,
                "params": params,
                "K": (fx, fy, cx, cy),
            }
    return cams


def _parse_points3d_txt(path: str) -> Dict[int, Tuple[float, float, float]]:
    pts: Dict[int, Tuple[float, float, float]] = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            toks = line.split()
            pid = int(toks[0])
            pts[pid] = (float(toks[1]), float(toks[2]), float(toks[3]))
    return pts


def _read_image_or_blank(path: str, H: int, W: int, read_images: bool):
    if read_images:
        try:
            import cv2
            im = cv2.imread(path, cv2.IMREAD_COLOR)
            if im is not None:
                return im
        except Exception:
            pass
    return np.zeros((H, W, 3), dtype=np.uint8)


def _parse_images_txt(path: str, cams_by_id: dict, points3d: dict, images_dir: str, read_images: bool):
    images_info = {}
    tracks = {}
    imgs = {}
    with open(path, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]
    i = 0
    while i < len(lines):
        head = lines[i].split()
        i += 1
        image_id = int(head[0])
        qw, qx, qy, qz = map(float, head[1:5])
        tx, ty, tz = map(float, head[5:8])
        cam_id = int(head[8])
        name = head[9]
        R = MRL_quat_to_rot(qw, qx, qy, qz)
        t = np.array([tx, ty, tz], dtype=np.float64)
        cam = cams_by_id[cam_id]
        W, H = cam["width"], cam["height"]
        K, model, params = cam["K"], cam["model"], cam["params"]

        obs = []
        if i < len(lines):
            obs_tokens = lines[i].split()
            i += 1
            for k in range(0, len(obs_tokens), 3):
                if k + 2 >= len(obs_tokens):
                    continue
                x = float(obs_tokens[k])
                y = float(obs_tokens[k + 1])
                pid = int(obs_tokens[k + 2])
                if pid == -1 or pid not in points3d:
                    continue
                uv_hat = MRL_project_point(points3d[pid], R, t, K, model, params)
                if uv_hat is None:
                    continue
                err = math.hypot(uv_hat[0] - x, uv_hat[1] - y)
                obs.append((x, y, pid, float(err)))

        key = str(image_id)
        images_info[key] = {"image_id": image_id, "camera_id": cam_id, "name": name, "H": H, "W": W}
        tracks[key] = obs
        imgs[key] = _read_image_or_blank(os.path.join(images_dir, name), H, W, read_images)
    cams = {str(k): {"H": v["H"], "W": v["W"], "name": v["name"]} for k, v in images_info.items()}
    return cams, tracks, imgs


def MRL_Load_COLMAP(colmap_dir: str, images_dir: str = "./sample_data/images", read_images: bool = True):
    """Load COLMAP text model into the unified MRL pipeline format."""
    cam_path = os.path.join(colmap_dir, "cameras.txt")
    img_path = os.path.join(colmap_dir, "images.txt")
    pts_path = os.path.join(colmap_dir, "points3D.txt")
    for p in (cam_path, img_path, pts_path):
        if not os.path.isfile(p):
            raise FileNotFoundError(f"Missing COLMAP file: {p}")
    cams_by_id = _parse_cameras_txt(cam_path)
    points = _parse_points3d_txt(pts_path)
    cams, tracks, imgs = _parse_images_txt(img_path, cams_by_id, points, images_dir, read_images)
    return cams, points, tracks, imgs
