@echo off
python MRL_Main.py --config MRL_Config.yaml
