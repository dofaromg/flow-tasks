# MRL 3D AI Reconstruction Run Report

Input objective: `error`

## Camera Metrics

| cam_id | p50 | p90 | max | mean | count | pixel_coverage |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 0.0949 | 0.2487 | 0.4139 | 0.1356 | 11 | 0.000036 |
| 2 | 0.0878 | 0.2692 | 0.3075 | 0.1306 | 11 | 0.000036 |
| 3 | 0.0872 | 0.2311 | 0.6916 | 0.1540 | 11 | 0.000036 |
| 4 | 0.0493 | 0.2872 | 0.3048 | 0.0966 | 11 | 0.000036 |
| 5 | 0.1736 | 0.5762 | 0.6699 | 0.2176 | 11 | 0.000036 |
| 6 | 0.1100 | 0.4662 | 0.8347 | 0.2170 | 11 | 0.000036 |

## Suggestions

### Image 1
- tile=[2, 1] score=0.000022 hint=reshoot/inspect middle-left region
- tile=[1, 2] score=0.000018 hint=reshoot/inspect upper-center region
- tile=[2, 2] score=0.000017 hint=reshoot/inspect middle-center region
- tile=[1, 1] score=0.000014 hint=reshoot/inspect upper-left region
- tile=[0, 1] score=0.000003 hint=reshoot/inspect upper-left region
### Image 2
- tile=[2, 1] score=0.000025 hint=reshoot/inspect middle-left region
- tile=[0, 3] score=0.000016 hint=reshoot/inspect upper-right region
- tile=[1, 2] score=0.000014 hint=reshoot/inspect upper-center region
- tile=[2, 2] score=0.000007 hint=reshoot/inspect middle-center region
- tile=[1, 1] score=0.000006 hint=reshoot/inspect upper-left region
### Image 3
- tile=[2, 1] score=0.000036 hint=reshoot/inspect middle-left region
- tile=[1, 1] score=0.000020 hint=reshoot/inspect upper-left region
- tile=[2, 2] score=0.000016 hint=reshoot/inspect middle-center region
- tile=[2, 0] score=0.000007 hint=reshoot/inspect middle-left region
- tile=[0, 2] score=0.000005 hint=reshoot/inspect upper-center region
### Image 4
- tile=[2, 2] score=0.000023 hint=reshoot/inspect middle-center region
- tile=[2, 1] score=0.000018 hint=reshoot/inspect middle-left region
- tile=[1, 2] score=0.000008 hint=reshoot/inspect upper-center region
- tile=[3, 1] score=0.000002 hint=reshoot/inspect lower-left region
- tile=[1, 1] score=0.000002 hint=reshoot/inspect upper-left region
### Image 5
- tile=[2, 1] score=0.000053 hint=reshoot/inspect middle-left region
- tile=[1, 2] score=0.000044 hint=reshoot/inspect upper-center region
- tile=[1, 1] score=0.000014 hint=reshoot/inspect upper-left region
- tile=[3, 2] score=0.000011 hint=reshoot/inspect lower-center region
- tile=[0, 3] score=0.000002 hint=reshoot/inspect upper-right region
### Image 6
- tile=[1, 2] score=0.000068 hint=reshoot/inspect upper-center region
- tile=[1, 1] score=0.000024 hint=reshoot/inspect upper-left region
- tile=[2, 1] score=0.000012 hint=reshoot/inspect middle-left region
- tile=[3, 2] score=0.000007 hint=reshoot/inspect lower-center region
- tile=[3, 1] score=0.000005 hint=reshoot/inspect lower-left region