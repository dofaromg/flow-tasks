#!/usr/bin/env bash
set -e
IMG_DIR=${1:-./sample_data/images}
OUT_DIR=${2:-./external_colmap_run}
DB="$OUT_DIR/colmap.db"
SPARSE="$OUT_DIR/sparse"
TEXT="$OUT_DIR/text"
mkdir -p "$OUT_DIR" "$SPARSE" "$TEXT"
rm -f "$DB"
colmap feature_extractor --database_path "$DB" --image_path "$IMG_DIR" --SiftExtraction.use_gpu=1
colmap exhaustive_matcher --database_path "$DB" --SiftMatching.use_gpu=1
colmap mapper --database_path "$DB" --image_path "$IMG_DIR" --output_path "$SPARSE"
colmap model_converter --input_path "$SPARSE/0" --output_path "$TEXT" --output_type TXT
printf "COLMAP text model exported to %s\n" "$TEXT"
