# MRL_3D_AI_Reconstruction_System_v1_REAL

這包不是口頭規劃，是可安裝、可執行、可產出報表的 3D AI 分析管線。

核心用途：把照片 / COLMAP / 影片幀 / OBJ mesh 轉成同一條分析線：

```text
input adapter → attention map → reprojection / coverage heatmap → context graph → gap / reshoot suggestion → reports
```

## 1. 安裝

```bash
cd MRL_3D_AI_Reconstruction_System_v1_REAL
python -m venv .venv
source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -e .
```

## 2. 先跑內建 demo

```bash
mrl3d run --config config/demo_simulate.yaml
```

輸出會在：

```text
data/outputs/demo_simulate/
```

主要檔案：

```text
metrics.json
metrics_summary.csv
suggestions.json
links.json
heatmap_*.png
heatmap_*.npy
```

## 3. 跑 OBJ coverage demo

```bash
mrl3d run --config config/mesh_obj.yaml
```

輸出會在：

```text
data/outputs/mesh_obj/
```

## 4. 接 COLMAP 真資料

把 COLMAP 的文字模型放到：

```text
adapters/colmap/cameras.txt
adapters/colmap/images.txt
adapters/colmap/points3D.txt
```

若有原始照片，放到：

```text
data/images/
```

然後跑：

```bash
mrl3d run --config config/colmap.yaml
```

## 5. 接影片

把影片放到：

```text
data/2025_8_15.mp4
```

然後跑：

```bash
mrl3d run --config config/video_frames.yaml
```

此模式先切幀與建檔，不會自動完成 SfM。要從影片取得真相機/點雲，需把切出的 frames 再丟 COLMAP。

## 6. 公式與工程狀態

- 公式整理：`docs/MRL_3D_AI_Reconstruction_Formulas.md`
- 工程狀態：`MRL_PACKAGE_STATUS.md`
