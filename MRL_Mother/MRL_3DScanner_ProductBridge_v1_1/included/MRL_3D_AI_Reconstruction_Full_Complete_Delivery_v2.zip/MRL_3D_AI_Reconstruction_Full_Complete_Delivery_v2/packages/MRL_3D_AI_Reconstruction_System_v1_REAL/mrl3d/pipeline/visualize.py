# -*- coding: utf-8 -*-
import numpy as np


def save_heatmap_png(path, heatmap, image=None):
    try:
        import cv2
        hm = heatmap.astype(np.float32)
        hm = (hm - hm.min()) / (hm.max() - hm.min() + 1e-6)
        color = cv2.applyColorMap((hm * 255).astype(np.uint8), cv2.COLORMAP_JET)
        if image is not None and image.shape[:2] == heatmap.shape:
            out = cv2.addWeighted(image, 0.55, color, 0.45, 0.0)
        else:
            out = color
        cv2.imwrite(str(path), out)
    except Exception:
        pass
