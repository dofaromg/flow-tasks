# -*- coding: utf-8 -*-
from pathlib import Path
import cv2
import numpy as np


def load_video_frames_scene(cfg):
    input_cfg = cfg.get("input", {})
    video_path = Path(input_cfg.get("video_path", "./data/input.mp4"))
    sample_fps = float(input_cfg.get("sample_fps", 2.0))
    frame_dir = Path(input_cfg.get("frame_dir", "./data/images/video_frames"))
    frame_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    step = max(int(round(src_fps / max(sample_fps, 0.1))), 1)
    imgs, cams, tracks = {}, {}, {}
    idx = 0
    saved = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % step == 0:
            key = f"frame{saved:04d}"
            fp = frame_dir / f"{key}.jpg"
            cv2.imwrite(str(fp), frame)
            h, w = frame.shape[:2]
            imgs[key] = frame
            cams[key] = {"H": h, "W": w, "frame_path": str(fp)}
            # no SfM tracks yet: video frames are a material input, not a complete reconstruction.
            tracks[key] = []
            saved += 1
        idx += 1
    cap.release()
    meta = {"adapter": "video", "video_path": str(video_path), "frames_extracted": saved, "note": "video mode only extracts frames; run COLMAP for real reprojection error"}
    return cams, {}, tracks, imgs, meta
