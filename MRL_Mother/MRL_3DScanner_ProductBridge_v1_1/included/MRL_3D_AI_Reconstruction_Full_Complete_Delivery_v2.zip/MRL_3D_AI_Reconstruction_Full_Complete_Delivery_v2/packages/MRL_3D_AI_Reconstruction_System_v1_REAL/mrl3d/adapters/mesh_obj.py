# -*- coding: utf-8 -*-
from pathlib import Path
import numpy as np


def _read_obj_vertices(path):
    verts = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith("v "):
                toks = line.strip().split()
                if len(toks) >= 4:
                    verts.append((float(toks[1]), float(toks[2]), float(toks[3])))
    if not verts:
        raise RuntimeError(f"OBJ has no vertices: {path}")
    return np.asarray(verts, dtype=np.float32)


def _look_at_rotation(cam_pos, target):
    z = target - cam_pos
    z = z / (np.linalg.norm(z) + 1e-9)
    up = np.array([0, 1, 0], dtype=np.float32)
    x = np.cross(up, z)
    if np.linalg.norm(x) < 1e-6:
        up = np.array([0, 0, 1], dtype=np.float32)
        x = np.cross(up, z)
    x = x / (np.linalg.norm(x) + 1e-9)
    y = np.cross(z, x)
    return np.stack([x, y, z], axis=0)


def _project_points(V, R, t, K):
    fx, fy, cx, cy = K
    X = R @ V.T + t.reshape(3, 1)
    z = X[2]
    valid = z > 1e-9
    x = X[0, valid] / z[valid]
    y = X[1, valid] / z[valid]
    u = fx * x + cx
    v = fy * y + cy
    ids = np.arange(len(V))[valid]
    return u, v, ids


def load_mesh_obj_scene(cfg):
    input_cfg = cfg.get("input", {})
    path = Path(input_cfg.get("mesh_path", "./data/mesh/sample_cube.obj"))
    V = _read_obj_vertices(path)
    synth = input_cfg.get("synth", {})
    num_cams = int(synth.get("num_cams", 8))
    radius_scale = float(synth.get("radius_scale", 2.0))
    res = synth.get("res", [640, 480])
    W, H = int(res[0]), int(res[1])
    fov_deg = float(synth.get("fov_deg", 60.0))
    fx = fy = (W / 2.0) / np.tan(np.deg2rad(fov_deg) / 2.0)
    K = [float(fx), float(fy), W / 2.0, H / 2.0]

    center = V.mean(axis=0)
    radius = max(np.linalg.norm(V.max(axis=0) - V.min(axis=0)) * 0.5, 1e-2) * radius_scale
    cams, tracks, imgs = {}, {}, {}
    points = {int(i): (float(p[0]), float(p[1]), float(p[2])) for i, p in enumerate(V)}

    for k, theta in enumerate(np.linspace(0, 2 * np.pi, num_cams, endpoint=False)):
        cam_pos = np.array([center[0] + radius * np.cos(theta), center[1] + radius * 0.25, center[2] + radius * np.sin(theta)], dtype=np.float32)
        R = _look_at_rotation(cam_pos, center)
        t = -R @ cam_pos
        key = f"meshcam{k}"
        cams[key] = {"H": H, "W": W, "K": K, "synthetic_pose": [float(x) for x in cam_pos]}
        u, v, ids = _project_points(V, R, t, K)
        obs = []
        for uu, vv, pid in zip(u, v, ids):
            if 0 <= uu < W and 0 <= vv < H:
                # value = 1.0 coverage sample
                obs.append((float(uu), float(vv), int(pid), 1.0))
        tracks[key] = obs
        imgs[key] = np.zeros((H, W, 3), dtype=np.uint8)

    meta = {"adapter": "mesh_obj", "mesh_path": str(path), "num_vertices": len(V), "num_synth_cams": num_cams}
    return cams, points, tracks, imgs, meta
