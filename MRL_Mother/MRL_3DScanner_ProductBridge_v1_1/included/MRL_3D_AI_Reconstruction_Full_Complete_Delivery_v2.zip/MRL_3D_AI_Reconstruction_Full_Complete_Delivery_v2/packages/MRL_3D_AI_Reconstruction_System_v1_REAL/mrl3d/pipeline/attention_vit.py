# -*- coding: utf-8 -*-
import numpy as np


class AttentionViT:
    """Optional ViT-like attention proxy via timm features. Falls back handled by caller."""
    def __init__(self, cfg):
        import torch
        import torch.nn.functional as F
        from timm import create_model
        self.torch = torch
        self.F = F
        self.model_name = cfg.get("attention", {}).get("vit_model", "vit_tiny_patch16_224")
        self.model = create_model(self.model_name, pretrained=True).eval()
        self.img_size = (224, 224)

    def _pre(self, img_bgr):
        import cv2
        img = cv2.resize(img_bgr, self.img_size[::-1]).astype(np.float32) / 255.0
        img = img[:, :, ::-1]
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        img = (img - mean) / std
        return self.torch.from_numpy(img.transpose(2, 0, 1)).unsqueeze(0)

    def compute(self, imgs):
        maps = {}
        with self.torch.no_grad():
            for cid, im in imgs.items():
                x = self._pre(im)
                feats = self.model.forward_features(x)
                if feats.ndim == 3:
                    B, N, C = feats.shape
                    P = int(max((N - 1), 1) ** 0.5)
                    tokens = feats[:, 1:1 + P * P, :].reshape(B, P, P, C)
                    cls = feats[:, 0:1, :].reshape(B, 1, 1, C)
                    sim = self.F.cosine_similarity(tokens, cls, dim=-1).clamp(min=0)
                    attn = sim[0].cpu().numpy()
                elif feats.ndim == 4:
                    cls = feats.mean(dim=(2, 3), keepdim=True)
                    sim = self.F.cosine_similarity(feats, cls, dim=1).clamp(min=0)
                    attn = sim[0].cpu().numpy()
                else:
                    attn = np.ones((14, 14), dtype=np.float32)
                attn = (attn - attn.min()) / (attn.max() - attn.min() + 1e-6)
                H, W = im.shape[:2]
                t = self.torch.from_numpy(attn)[None, None].float()
                up = self.F.interpolate(t, size=(H, W), mode="bilinear", align_corners=False)[0, 0].cpu().numpy()
                maps[cid] = up.astype(np.float32)
        return maps
