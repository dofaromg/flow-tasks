# -*- coding: utf-8 -*-
import numpy as np


def stats_per_camera(weighted_errors_by_cam, bins=20):
    out = {}
    for cid, errs in weighted_errors_by_cam.items():
        arr = np.asarray(errs, dtype=np.float32)
        if arr.size == 0:
            out[cid] = {"count": 0, "p50": 0.0, "p90": 0.0, "max": 0.0, "mean": 0.0, "coverage": 0.0, "hist": [0] * bins, "edges": []}
            continue
        maxv = float(arr.max())
        hist, edges = np.histogram(arr, bins=bins, range=(0, max(maxv, 1e-6)))
        out[cid] = {
            "count": int(arr.size),
            "p50": float(np.percentile(arr, 50)),
            "p90": float(np.percentile(arr, 90)),
            "max": maxv,
            "mean": float(arr.mean()),
            "coverage": float((arr > 0).mean()),
            "hist": hist.tolist(),
            "edges": edges.tolist(),
        }
    return out
