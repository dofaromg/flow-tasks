# -*- coding: utf-8 -*-
import csv
import json
from pathlib import Path

import numpy as np
from .visualize import save_heatmap_png


class Exporter:
    def __init__(self, cfg):
        self.cfg = cfg
        self.out_dir = Path(cfg.get("out_dir", "./data/outputs/default"))
        self.out_dir.mkdir(parents=True, exist_ok=True)

    def dump_all(self, cams, metrics, links, suggestions, heatmaps, imgs=None):
        self._json("cameras.json", cams)
        self._json("metrics.json", metrics)
        self._json("links.json", links)
        self._json("suggestions.json", suggestions)
        self._csv_summary(metrics)
        for cid, hm in heatmaps.items():
            np.save(self.out_dir / f"heatmap_{cid}.npy", hm)
            img = imgs.get(cid) if isinstance(imgs, dict) else None
            save_heatmap_png(self.out_dir / f"heatmap_{cid}.png", hm, img)

    def _json(self, name, data):
        with open(self.out_dir / name, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=self._default)

    def _csv_summary(self, metrics):
        with open(self.out_dir / "metrics_summary.csv", "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["camera_id", "count", "p50", "p90", "max", "mean", "coverage"])
            for cid, s in metrics.get("summary", {}).items():
                w.writerow([cid, s.get("count"), s.get("p50"), s.get("p90"), s.get("max"), s.get("mean"), s.get("coverage")])

    @staticmethod
    def _default(o):
        if isinstance(o, np.ndarray):
            return o.tolist()
        if hasattr(o, "item"):
            return o.item()
        return str(o)
