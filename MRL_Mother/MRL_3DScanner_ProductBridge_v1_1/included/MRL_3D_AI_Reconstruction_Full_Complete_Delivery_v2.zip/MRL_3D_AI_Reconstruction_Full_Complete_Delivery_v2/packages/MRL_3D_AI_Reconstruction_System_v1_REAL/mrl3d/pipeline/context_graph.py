# -*- coding: utf-8 -*-
import numpy as np


class ContextGraph:
    def __init__(self, cfg):
        self.threshold = float(cfg.get("context", {}).get("neg_corr_threshold", -0.2))

    @staticmethod
    def _corr(a, b):
        a = a.flatten()
        b = b.flatten()
        if a.size < 2 or b.size < 2 or a.std() < 1e-6 or b.std() < 1e-6:
            return 0.0
        return float(np.corrcoef(a, b)[0, 1])

    def build(self, cams, heatmaps):
        ids = list(heatmaps.keys())
        edges = []
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                c = self._corr(heatmaps[ids[i]], heatmaps[ids[j]])
                if c < self.threshold:
                    edges.append({"a": ids[i], "b": ids[j], "corr": c, "relation": "complementary_view"})
        return {"edges": edges, "threshold": self.threshold}
