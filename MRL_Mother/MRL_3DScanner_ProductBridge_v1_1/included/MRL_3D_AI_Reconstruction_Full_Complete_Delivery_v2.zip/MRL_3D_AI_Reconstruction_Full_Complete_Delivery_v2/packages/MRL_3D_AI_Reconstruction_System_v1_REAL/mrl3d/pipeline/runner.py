# -*- coding: utf-8 -*-
import json
import logging
import os
from pathlib import Path

import yaml

from .scene_loader import SceneLoader
from .attention import AttentionBackend
from .error_map import ErrorMapper
from .context_graph import ContextGraph
from .gap_fill import GapFiller
from .exporter import Exporter

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")


def run_pipeline(config_path: str):
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    out_dir = Path(cfg.get("out_dir", "./data/outputs/default"))
    out_dir.mkdir(parents=True, exist_ok=True)

    logging.info("Loading scene via adapter...")
    cams, points, tracks, imgs, meta = SceneLoader(cfg).load()

    logging.info("Computing attention maps...")
    attn_maps = AttentionBackend(cfg).compute(imgs)

    logging.info("Building error / coverage heatmaps...")
    heatmaps, metrics = ErrorMapper(cfg).make(cams, points, tracks, attn_maps)
    metrics["input_meta"] = meta

    logging.info("Building context graph...")
    links = ContextGraph(cfg).build(cams, heatmaps)

    logging.info("Generating gap / reshoot suggestions...")
    suggestions = GapFiller(cfg).propose(heatmaps, links, cams)

    logging.info("Exporting artifacts...")
    Exporter(cfg).dump_all(cams, metrics, links, suggestions, heatmaps, imgs)

    logging.info("Done. Output directory: %s", out_dir)
    return {
        "cams": cams,
        "metrics": metrics,
        "links": links,
        "suggestions": suggestions,
        "output_dir": str(out_dir),
    }
