# -*- coding: utf-8 -*-
from mrl3d.adapters.simulate import load_simulated_scene
from mrl3d.adapters.colmap_loader import load_colmap_scene
from mrl3d.adapters.mesh_obj import load_mesh_obj_scene
from mrl3d.adapters.video_frames import load_video_frames_scene


class SceneLoader:
    def __init__(self, cfg):
        self.cfg = cfg

    def load(self):
        input_cfg = self.cfg.get("input", {})
        typ = input_cfg.get("type", "simulate").lower()
        if typ == "simulate":
            return load_simulated_scene(self.cfg)
        if typ == "colmap":
            return load_colmap_scene(self.cfg)
        if typ == "mesh_obj":
            return load_mesh_obj_scene(self.cfg)
        if typ == "video":
            return load_video_frames_scene(self.cfg)
        raise ValueError(f"Unknown input.type: {typ}")
