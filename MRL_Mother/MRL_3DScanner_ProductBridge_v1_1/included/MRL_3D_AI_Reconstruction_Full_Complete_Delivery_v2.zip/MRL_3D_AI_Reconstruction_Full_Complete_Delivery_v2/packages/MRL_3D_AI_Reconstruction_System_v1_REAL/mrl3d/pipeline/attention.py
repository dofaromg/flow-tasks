# -*- coding: utf-8 -*-
import numpy as np
import cv2


class AttentionBackend:
    """Pluggable attention. `simple` is deterministic and lightweight; `vit` is optional."""
    def __init__(self, cfg):
        self.cfg = cfg
        self.backend = cfg.get("attention", {}).get("backend", "simple").lower()
        self.vit = None
        if self.backend == "vit":
            try:
                from .attention_vit import AttentionViT
                self.vit = AttentionViT(cfg)
            except Exception as exc:
                print(f"[attention] vit unavailable; fallback to simple. reason={exc}")
                self.backend = "simple"

    def compute(self, imgs):
        if self.backend == "vit" and self.vit is not None:
            return self.vit.compute(imgs)
        return self._simple(imgs)

    def _simple(self, imgs):
        maps = {}
        edge_weight = float(self.cfg.get("attention", {}).get("edge_weight", 0.35))
        center_weight = 1.0 - edge_weight
        for cid, im in imgs.items():
            h, w = im.shape[:2]
            yy, xx = np.mgrid[0:h, 0:w]
            cx, cy = w / 2.0, h / 2.0
            center = 1.0 - np.sqrt(((xx - cx) / max(w / 2.0, 1)) ** 2 + ((yy - cy) / max(h / 2.0, 1)) ** 2)
            center = np.clip(center, 0, 1).astype(np.float32)
            gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY) if im.ndim == 3 else im.astype(np.uint8)
            gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
            gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
            edge = np.sqrt(gx * gx + gy * gy)
            if edge.max() > 1e-6:
                edge = edge / edge.max()
            attn = center_weight * center + edge_weight * edge
            attn = (attn - attn.min()) / (attn.max() - attn.min() + 1e-6)
            maps[cid] = attn.astype(np.float32)
        return maps
