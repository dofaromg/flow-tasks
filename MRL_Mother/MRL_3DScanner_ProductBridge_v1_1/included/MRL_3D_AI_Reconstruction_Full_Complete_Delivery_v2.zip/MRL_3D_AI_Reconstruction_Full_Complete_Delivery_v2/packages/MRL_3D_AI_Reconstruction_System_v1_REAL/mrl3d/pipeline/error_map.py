# -*- coding: utf-8 -*-
import numpy as np
from .metrics import stats_per_camera


def _huber(e, delta):
    e = float(e)
    if abs(e) <= delta:
        return 0.5 * e * e
    return delta * (abs(e) - 0.5 * delta)


class ErrorMapper:
    def __init__(self, cfg):
        self.cfg = cfg
        self.mode = cfg.get("suggestion", {}).get("objective", "error").lower()
        self.huber_delta = float(cfg.get("eval", {}).get("huber_delta", 0.0))

    def make(self, cams, points, tracks, attn_maps):
        heatmaps = {}
        weighted_values_by_cam = {}
        metrics = {"p90_by_cam": {}, "summary": {}, "objective": self.mode}
        for cam_id, cam in cams.items():
            H, W = int(cam["H"]), int(cam["W"])
            acc = np.zeros((H, W), dtype=np.float32)
            cnt = np.zeros((H, W), dtype=np.float32)
            values = []
            for (u, v, pid, val) in tracks.get(cam_id, []):
                ui, vi = int(round(u)), int(round(v))
                if 0 <= ui < W and 0 <= vi < H:
                    w = float(attn_maps.get(cam_id, np.ones((H, W), dtype=np.float32))[vi, ui])
                    base = _huber(val, self.huber_delta) if self.huber_delta > 0 else float(val)
                    weighted = w * base
                    acc[vi, ui] += weighted
                    cnt[vi, ui] += 1.0
                    values.append(weighted)
            hm = np.divide(acc, np.maximum(cnt, 1.0))
            heatmaps[cam_id] = hm
            weighted_values_by_cam[cam_id] = values
            metrics["p90_by_cam"][cam_id] = float(np.percentile(values, 90)) if values else 0.0
        metrics["summary"] = stats_per_camera(weighted_values_by_cam)
        return heatmaps, metrics
