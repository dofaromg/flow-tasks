# -*- coding: utf-8 -*-
import math
import os
from pathlib import Path

import cv2
import numpy as np


def _parse_cameras_txt(path):
    cams = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            toks = line.split()
            cam_id = int(toks[0])
            model = toks[1]
            width = int(toks[2])
            height = int(toks[3])
            params = list(map(float, toks[4:]))
            if model == "PINHOLE":
                fx, fy, cx, cy = params[:4]
            elif model in ("SIMPLE_PINHOLE", "SIMPLE_RADIAL"):
                f, cx, cy = params[:3]
                fx = fy = f
            elif model in ("OPENCV", "RADIAL", "OPENCV_FISHEYE") and len(params) >= 4:
                fx, fy, cx, cy = params[:4]
            else:
                fx = fy = params[0] if params else max(width, height)
                cx = width / 2.0
                cy = height / 2.0
            cams[cam_id] = {
                "model": model,
                "width": width,
                "height": height,
                "params": params,
                "K": (fx, fy, cx, cy),
            }
    return cams


def _parse_points3d_txt(path):
    pts = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            toks = line.split()
            pid = int(toks[0])
            pts[pid] = tuple(map(float, toks[1:4]))
    return pts


def _quat_to_rot(qw, qx, qy, qz):
    n = math.sqrt(qw * qw + qx * qx + qy * qy + qz * qz)
    if n == 0:
        return np.eye(3, dtype=np.float64)
    qw, qx, qy, qz = qw / n, qx / n, qy / n, qz / n
    return np.array([
        [1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw)],
        [2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw)],
        [2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy)],
    ], dtype=np.float64)


def _distort_xy(x, y, model, params):
    if model == "SIMPLE_RADIAL" and len(params) >= 4:
        k1 = params[3]
        r2 = x * x + y * y
        return x * (1 + k1 * r2), y * (1 + k1 * r2)

    if model == "RADIAL" and len(params) >= 6:
        k1, k2 = params[4], params[5]
        r2 = x * x + y * y
        radial = 1 + k1 * r2 + k2 * (r2 ** 2)
        return x * radial, y * radial

    if model in ("OPENCV", "OPENCV_FISHEYE") and len(params) >= 8:
        k1 = params[4] if len(params) > 4 else 0.0
        k2 = params[5] if len(params) > 5 else 0.0
        p1 = params[6] if len(params) > 6 else 0.0
        p2 = params[7] if len(params) > 7 else 0.0
        k3 = params[8] if len(params) > 8 else 0.0
        r2 = x * x + y * y
        radial = 1 + k1 * r2 + k2 * (r2 ** 2) + k3 * (r2 ** 3)
        xd = x * radial + 2 * p1 * x * y + p2 * (r2 + 2 * x * x)
        yd = y * radial + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y
        return xd, yd

    return x, y


def _project_point(xyz_world, R, t, cam):
    X = np.asarray(xyz_world, dtype=np.float64).reshape(3, 1)
    xc = (R @ X + t.reshape(3, 1)).flatten()
    if xc[2] <= 1e-9:
        return None
    x = xc[0] / xc[2]
    y = xc[1] / xc[2]
    x, y = _distort_xy(x, y, cam["model"], cam["params"])
    fx, fy, cx, cy = cam["K"]
    return fx * x + cx, fy * y + cy


def _parse_images_txt(path, cams, points3d, images_dir=None, read_images=False):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        lines = [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]

    cams_out = {}
    tracks = {}
    imgs = {}
    info_by_id = {}

    i = 0
    while i < len(lines):
        head = lines[i].split()
        i += 1
        image_id = int(head[0])
        qw, qx, qy, qz = map(float, head[1:5])
        tx, ty, tz = map(float, head[5:8])
        camera_id = int(head[8])
        name = head[9]
        R = _quat_to_rot(qw, qx, qy, qz)
        t = np.array([tx, ty, tz], dtype=np.float64)
        cam = cams[camera_id]
        key = str(image_id)
        cams_out[key] = {"H": cam["height"], "W": cam["width"], "K": list(cam["K"]), "image_name": name}
        info_by_id[key] = {"R": R, "t": t, "camera_id": camera_id, "name": name}

        obs_line = lines[i].split() if i < len(lines) else []
        i += 1
        obs = []
        for k in range(0, len(obs_line), 3):
            try:
                u_obs = float(obs_line[k])
                v_obs = float(obs_line[k + 1])
                pid = int(obs_line[k + 2])
            except (IndexError, ValueError):
                continue
            if pid == -1 or pid not in points3d:
                continue
            uv_hat = _project_point(points3d[pid], R, t, cam)
            if uv_hat is None:
                continue
            u_hat, v_hat = uv_hat
            err = math.hypot(u_hat - u_obs, v_hat - v_obs)
            obs.append((u_obs, v_obs, pid, float(err)))
        tracks[key] = obs

        img = None
        if read_images and images_dir:
            fp = Path(images_dir) / name
            if fp.exists():
                img = cv2.imread(str(fp), cv2.IMREAD_COLOR)
        if img is None:
            img = np.zeros((cam["height"], cam["width"], 3), dtype=np.uint8)
        imgs[key] = img

    return cams_out, tracks, imgs, info_by_id


def load_colmap_scene(cfg):
    input_cfg = cfg.get("input", {})
    colmap_dir = Path(input_cfg.get("colmap_dir", "./adapters/colmap"))
    images_dir = cfg.get("images_dir", "./data/images")
    read_images = bool(input_cfg.get("read_images", False))
    camera_path = colmap_dir / "cameras.txt"
    image_path = colmap_dir / "images.txt"
    point_path = colmap_dir / "points3D.txt"
    missing = [p.name for p in (camera_path, image_path, point_path) if not p.exists()]
    if missing:
        raise FileNotFoundError(f"COLMAP text model missing files: {missing}")
    cameras = _parse_cameras_txt(camera_path)
    points = _parse_points3d_txt(point_path)
    cams, tracks, imgs, info = _parse_images_txt(image_path, cameras, points, images_dir, read_images)
    meta = {"adapter": "colmap", "colmap_dir": str(colmap_dir), "num_points": len(points), "num_images": len(cams)}
    return cams, points, tracks, imgs, meta
