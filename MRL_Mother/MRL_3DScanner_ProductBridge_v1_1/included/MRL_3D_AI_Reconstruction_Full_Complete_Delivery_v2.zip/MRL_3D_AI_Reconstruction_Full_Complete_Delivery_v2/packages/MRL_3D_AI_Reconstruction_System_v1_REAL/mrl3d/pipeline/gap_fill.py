# -*- coding: utf-8 -*-
import numpy as np


class GapFiller:
    def __init__(self, cfg):
        self.tiles = cfg.get("suggestion", {}).get("tiles", [4, 4])
        self.topk = int(cfg.get("suggestion", {}).get("topk", 5))
        self.objective = cfg.get("suggestion", {}).get("objective", "error").lower()

    def _tile_scores(self, hm):
        r, c = int(self.tiles[0]), int(self.tiles[1])
        H, W = hm.shape
        rows = np.linspace(0, H, r + 1, dtype=int)
        cols = np.linspace(0, W, c + 1, dtype=int)
        scores = []
        for i in range(r):
            for j in range(c):
                sub = hm[rows[i]:rows[i + 1], cols[j]:cols[j + 1]]
                score = float(sub.mean()) if sub.size else 0.0
                bbox = [int(cols[j]), int(rows[i]), int(cols[j + 1]), int(rows[i + 1])]
                scores.append({"tile_rc": [int(i), int(j)], "bbox_xyxy": bbox, "score": score})
        reverse = self.objective != "coverage"
        scores.sort(key=lambda x: x["score"], reverse=reverse)
        return scores

    def propose(self, heatmaps, links, cams):
        per_image = []
        for cid, hm in heatmaps.items():
            top = self._tile_scores(hm)[:self.topk]
            hints = []
            for t in top:
                hints.append({
                    **t,
                    "suggestion": "reshoot_or_recompute_this_tile" if self.objective == "error" else "low_coverage_tile_need_extra_view"
                })
            per_image.append({"image_id": cid, "top_tiles": hints})
        return {"version": "1.0", "objective": self.objective, "per_image": per_image, "links_used": links.get("edges", [])}
