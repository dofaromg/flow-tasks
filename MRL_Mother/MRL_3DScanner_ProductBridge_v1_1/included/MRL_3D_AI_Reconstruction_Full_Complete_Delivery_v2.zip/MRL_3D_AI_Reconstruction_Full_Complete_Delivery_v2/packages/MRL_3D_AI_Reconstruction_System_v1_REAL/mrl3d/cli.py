# -*- coding: utf-8 -*-
import argparse
from .pipeline.runner import run_pipeline


def main():
    parser = argparse.ArgumentParser(prog="mrl3d")
    sub = parser.add_subparsers(dest="command")

    run = sub.add_parser("run", help="Run MRL 3D AI reconstruction analysis pipeline")
    run.add_argument("--config", required=True, help="Path to YAML config")

    args = parser.parse_args()
    if args.command == "run":
        run_pipeline(args.config)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
