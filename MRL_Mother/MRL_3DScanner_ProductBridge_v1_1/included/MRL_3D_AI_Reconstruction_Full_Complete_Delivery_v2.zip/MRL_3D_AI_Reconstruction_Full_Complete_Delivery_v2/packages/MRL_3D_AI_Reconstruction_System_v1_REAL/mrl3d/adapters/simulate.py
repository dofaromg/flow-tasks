# -*- coding: utf-8 -*-
import math
import numpy as np


def _blank_image(h, w):
    img = np.zeros((h, w, 3), dtype=np.uint8)
    yy, xx = np.mgrid[0:h, 0:w]
    img[..., 0] = np.clip(30 + 120 * (xx / max(w - 1, 1)), 0, 255).astype(np.uint8)
    img[..., 1] = np.clip(30 + 120 * (yy / max(h - 1, 1)), 0, 255).astype(np.uint8)
    img[..., 2] = 80
    return img


def load_simulated_scene(cfg):
    """Deterministic small scene: 4 cameras, 27 cube points, synthetic reprojection errors."""
    h = int(cfg.get("simulate", {}).get("height", 160))
    w = int(cfg.get("simulate", {}).get("width", 220))
    num_cams = int(cfg.get("simulate", {}).get("num_cams", 4))

    cams = {}
    tracks = {}
    imgs = {}
    points = {}

    # cube-ish point cloud
    idx = 0
    for x in np.linspace(-0.5, 0.5, 3):
        for y in np.linspace(-0.5, 0.5, 3):
            for z in np.linspace(2.5, 3.5, 3):
                points[idx] = (float(x), float(y), float(z))
                idx += 1

    fx = fy = 120.0
    cx = w / 2
    cy = h / 2
    rng = np.random.default_rng(42)

    for ci in range(num_cams):
        cam_id = f"cam{ci}"
        cams[cam_id] = {"H": h, "W": w, "K": [fx, fy, cx, cy]}
        imgs[cam_id] = _blank_image(h, w)
        obs = []
        # synthetic camera x-shift
        cam_shift = (ci - (num_cams - 1) / 2) * 0.12
        for pid, p in points.items():
            x, y, z = p
            u = fx * ((x - cam_shift) / z) + cx
            v = fy * (y / z) + cy
            if 0 <= u < w and 0 <= v < h:
                # make some stable, reproducible error pattern
                base_err = abs(math.sin(pid * 0.7 + ci * 0.9)) * 2.0
                noise = float(rng.normal(0, 0.05))
                obs.append((float(u), float(v), int(pid), max(0.0, base_err + noise)))
        tracks[cam_id] = obs

    meta = {"adapter": "simulate", "description": "deterministic synthetic cameras/points/tracks"}
    return cams, points, tracks, imgs, meta
