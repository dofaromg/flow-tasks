#!/usr/bin/env bash
set -e
mrl3d run --config config/colmap.yaml
