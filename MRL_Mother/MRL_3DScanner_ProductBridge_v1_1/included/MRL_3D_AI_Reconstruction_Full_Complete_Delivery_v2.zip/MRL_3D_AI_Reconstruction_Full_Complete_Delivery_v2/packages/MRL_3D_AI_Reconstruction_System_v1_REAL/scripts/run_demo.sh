#!/usr/bin/env bash
set -e
mrl3d run --config config/demo_simulate.yaml
mrl3d run --config config/mesh_obj.yaml
