# MRL_3D_AI_Reconstruction_System_v1_REAL｜交付狀態

## 定位
這是「3D 立體成像 / AI 注意力誤差分析 / 自動補拍建議」的可跑工程包。

## 已實作
- 可安裝 Python package：`pip install -e .`
- CLI：`mrl3d run --config config/demo_simulate.yaml`
- 來源 adapter：
  - `simulate`：內建可重現資料，保證可跑出誤差與建議
  - `colmap`：讀 `cameras.txt / images.txt / points3D.txt`
  - `mesh_obj`：讀 OBJ 頂點，做 coverage heatmap
  - `video`：切幀並輸出 frame inventory；若要真 SfM 需另外接 COLMAP
- 注意力：
  - `simple`：中心性 + 邊緣強度，保證可跑
  - `vit`：選配，需要安裝 `requirements-vit.txt`
- 輸出：
  - `metrics.json`
  - `metrics_summary.csv`
  - `suggestions.json`
  - `links.json`
  - `heatmap_*.npy`
  - `heatmap_*.png`

## 尚未實作為完整版的部分
- 不內建 COLMAP/OpenMVS 二進位工具；真實 3D 重建仍需使用者本機或伺服器安裝。
- 影片 adapter 目前只做切幀；要從影片得到真相機位姿與點雲，需跑 COLMAP。
- OBJ adapter 目前用頂點 coverage，不含完整面片遮擋、法線與可見性裁切。
- 補拍建議目前輸出影像 tile / 合成視角提示，尚未輸出完整真實相機外參最佳化結果。

## 驗證
本包已用內建 `demo_simulate.yaml` 與 `mesh_obj.yaml` 在本環境執行通過，並產生輸出報表。
