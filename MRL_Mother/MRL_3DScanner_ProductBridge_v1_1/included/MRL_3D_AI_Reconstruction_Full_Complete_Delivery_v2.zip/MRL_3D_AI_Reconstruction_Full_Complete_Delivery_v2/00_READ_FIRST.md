# MRL_3D_AI_Reconstruction_Full_Complete_Delivery_v2

本包是「3D 立體成像 / AI 重建分析系統」完整檔案交付包，不是單一摘要，也不是只給 Claude 的說明文件。

## 主線定位

- 主線：MRL母體工程架構中心
- 分支：MRL_Branch_3D_AI_Reconstruction_Complete_File_Delivery_v2
- 本包目的：把目前已形成的 3D AI 重建分析系統檔案完整收斂交付，保留 MRL 命名版與可安裝 runtime 版。

## 本包包含

1. `packages/MRL_3D_AI_Reconstruction_System_v1/`
   - 全 MRL 命名版
   - 可直接跑 demo / mesh / video sample
   - 含 sample COLMAP text、sample images、sample mesh、sample video

2. `packages/MRL_3D_AI_Reconstruction_System_v1_REAL/`
   - pip 可安裝 runtime 版
   - `mrl3d run --config ...` CLI
   - 含 simulate / mesh_obj / video_frames / colmap config

3. `docs/`
   - 公式總表
   - Claude additive patch 指令
   - 原先公式檢查與建構 handoff

4. `mainline/`
   - 分支狀態、驗收、主線回填草稿

5. `tests/`
   - 本次可執行驗收紀錄

## 重要狀態

- 已驗證：demo simulate、mesh OBJ coverage、video frame adapter 在本環境可跑。
- 待驗證：真 COLMAP / 真 OpenMVS / 真手機拍攝資料，需要使用者或 Claude 提供實際資料與外部工具。
- 不可宣稱：真實完整 3D 重建已完成。現在是「可跑分析管線 + sample data + adapter + 報表」，不是 Polycam 級完整產品。

