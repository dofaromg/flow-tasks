# 01_FILE_DELIVERY_MANIFEST

## 完整交付檔案區

### A. MRL 命名版
`packages/MRL_3D_AI_Reconstruction_System_v1/`

用途：保留全 MRL 命名、模組層級與工程語義。

主要檔案：
- `MRL_Main.py`
- `MRL_Config.yaml`
- `MRL_Config_mesh.yaml`
- `MRL_Config_video.yaml`
- `MRL_Formulas.md`
- `MRL_Core/*`
- `MRL_Perception/*`
- `MRL_Reconstruction/*`
- `MRL_Error/*`
- `MRL_Fusion/*`
- `MRL_Context/*`
- `MRL_Decision/*`
- `MRL_Fix/*`
- `MRL_Visualization/*`
- `sample_data/colmap/*`
- `sample_data/images/*`
- `sample_data/mesh/*`
- `sample_data/video/sample.mp4`
- `outputs/*`
- `outputs_mesh/*`
- `outputs_video/*`

### B. 可安裝 runtime 版
`packages/MRL_3D_AI_Reconstruction_System_v1_REAL/`

用途：pip 安裝、CLI 執行、較接近實作套件。

主要檔案：
- `pyproject.toml`
- `requirements.txt`
- `requirements-vit.txt`
- `mrl3d/cli.py`
- `mrl3d/adapters/*`
- `mrl3d/pipeline/*`
- `config/*.yaml`
- `data/mesh/sample_cube.obj`
- `data/2025_8_15.mp4`
- `data/outputs/*`
- `docs/MRL_3D_AI_Reconstruction_Formulas.md`
- `scripts/*`

### C. 文件區
`docs/`

- `MRL_3D_AI_Reconstruction_Formula_Check_and_Claude_Handoff_v1.md`
- `MRL_3D_AI_Reconstruction_Formulas_MRL_Named.md`
- `MRL_3D_AI_Reconstruction_Formulas_Runtime.md`

### D. 原始 zip 保留區
`package_zips/`

保留既有壓縮交付，不以新的單一版本取代舊包。

