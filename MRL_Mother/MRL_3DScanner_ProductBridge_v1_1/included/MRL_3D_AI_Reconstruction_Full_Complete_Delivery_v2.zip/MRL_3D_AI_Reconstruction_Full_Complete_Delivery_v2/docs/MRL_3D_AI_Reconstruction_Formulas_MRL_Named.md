# MRL 3D AI Reconstruction｜核心公式清單

## 1. 世界座標到相機座標

\[
X_c = R X_w + t = [x_c, y_c, z_c]^T
\]

## 2. 針孔投影

\[
x = \frac{x_c}{z_c}, \quad y = \frac{y_c}{z_c}
\]

\[
\begin{bmatrix}u\\v\end{bmatrix}
= \begin{bmatrix} f_x & 0 & c_x \\ 0 & f_y & c_y \end{bmatrix}
\begin{bmatrix}x\\y\\1\end{bmatrix}
\]

## 3. SIMPLE_RADIAL 畸變

\[
r^2 = x^2 + y^2
\]

\[
x' = x(1+k_1 r^2), \quad y' = y(1+k_1 r^2)
\]

## 4. OPENCV 畸變

\[
radial = 1 + k_1r^2 + k_2r^4 + k_3r^6
\]

\[
x' = x\cdot radial + 2p_1xy + p_2(r^2+2x^2)
\]

\[
y' = y\cdot radial + p_1(r^2+2y^2) + 2p_2xy
\]

## 5. 重投影誤差

\[
e_{ij}=\lVert x_{ij}-\hat{x}_{ij}\rVert_2
\]

## 6. Huber Robust Loss

\[
\rho_\delta(e)=
\begin{cases}
\frac{1}{2}e^2, & |e|\le\delta \\
\delta(|e|-\frac{1}{2}\delta), & |e|>\delta
\end{cases}
\]

## 7. 注意力加權誤差

\[
\bar{e}_{ij} = w_{ij}\cdot \rho_\delta(e_{ij})
\]

其中 \(w_{ij}\in[0,1]\) 由注意力圖取得。

## 8. 影像域 Heatmap 聚合

\[
H_i(u,v)=Agg\{\bar{e}_{ij}\mid \hat{x}_{ij}\approx(u,v)\}
\]

目前實作用 `max` 聚合，保留局部最高風險。

## 9. Mesh Coverage 目標

OBJ mesh 路徑不具原始相機誤差，因此用合成環繞相機投影 mesh vertices：

\[
C_i(u,v)=Agg\{1\mid \pi_i(X_j)\approx(u,v)\}
\]

若 `objective=coverage`，低值 tile 代表覆蓋不足。

## 10. 視角上下文關聯

以 heatmap 相關係數建立互補視角：

\[
 corr(H_a,H_b)=\frac{Cov(H_a,H_b)}{\sigma_{H_a}\sigma_{H_b}}
\]

若 `corr < threshold`，視為互補視角。
