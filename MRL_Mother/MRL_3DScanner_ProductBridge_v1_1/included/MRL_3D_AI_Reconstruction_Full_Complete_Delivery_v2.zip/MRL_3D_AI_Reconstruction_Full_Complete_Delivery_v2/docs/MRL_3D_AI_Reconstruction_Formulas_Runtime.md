# MRL 3D AI Reconstruction｜核心公式表

## A. 世界座標到相機座標

```math
X_c = R X_w + t = [x_c, y_c, z_c]^T
```

## B. 針孔投影

```math
x = x_c / z_c,
y = y_c / z_c
```

```math
u = f_x x + c_x,
v = f_y y + c_y
```

## C. SIMPLE_RADIAL 畸變

```math
r^2 = x^2 + y^2
```

```math
x' = x(1 + k_1 r^2),
y' = y(1 + k_1 r^2)
```

## D. OPENCV 畸變

```math
radial = 1 + k_1 r^2 + k_2 r^4 + k_3 r^6
```

```math
x' = x \cdot radial + 2p_1xy + p_2(r^2 + 2x^2)
```

```math
y' = y \cdot radial + p_1(r^2 + 2y^2) + 2p_2xy
```

## E. 重投影誤差

```math
e_{ij} = ||x_{ij} - \hat{x}_{ij}||_2
```

## F. Huber 魯棒誤差

```math
\rho_\delta(e)=
\begin{cases}
\frac{1}{2}e^2, & |e| \le \delta \\
\delta(|e|-\frac{1}{2}\delta), & |e| > \delta
\end{cases}
```

## G. 注意力加權誤差

```math
\bar{e}_{ij} = w_{ij} \cdot \rho(e_{ij})
```

其中 `w_ij` 來自 simple attention 或 ViT/DINO 類 backend。

## H. Heatmap 聚合

```math
H_i(u,v) = Agg_{j: \hat{x}_{ij}\approx(u,v)}(\bar{e}_{ij})
```

本實作目前使用 max / mean 類聚合。

## I. Tile 補拍分數

對每個 tile：

```math
S(T)=\frac{1}{|T|}\sum_{(u,v)\in T} H(u,v)
```

- error 目標：選 `S(T)` 最大的 tile。
- coverage 目標：選 `S(T)` 最小的 tile。

## J. 視角互補關聯

```math
corr(H_a,H_b)=\frac{cov(H_a,H_b)}{\sigma(H_a)\sigma(H_b)}
```

若 `corr < threshold`，視為互補視角。
