# Claude 執行命令｜MRL_3D_AI_Reconstruction_Complete_File_Delivery_v2

Claude 必須 additive patch，不得刪除既有 MRL 命名版或 runtime 版。

## 分支名稱

MRL_Branch_3D_AI_Reconstruction_Complete_File_Delivery_v2

## 分支目標

把 3D 立體成像 / AI 重建分析系統從「sample 可跑分析管線」補到「真資料閉環」：照片/影片 → COLMAP → MVS/mesh → attention heatmap → geometry coverage → NBV 補拍建議 → 主流 3D 輸出。

## 必須保留

- `packages/MRL_3D_AI_Reconstruction_System_v1/`
- `packages/MRL_3D_AI_Reconstruction_System_v1_REAL/`
- 所有公式文件
- 所有 sample data / outputs

## 必須補齊

1. 真 COLMAP runner
   - video/photos → database
   - feature_extractor
   - matcher
   - mapper
   - model_converter

2. OpenMVS runner
   - interface COLMAP model to OpenMVS
   - densify point cloud
   - reconstruct mesh
   - texture mesh

3. Geometry domain heatmap
   - PLY reader
   - OBJ face reader
   - normals
   - face area weighting
   - coverage map on mesh / point cloud

4. NBV 補拍外參
   - camera position
   - look_at
   - target surface point
   - expected_gain
   - reason

5. 主流輸出
   - `.ply`
   - `.obj + .mtl`
   - `.glb`
   - report JSON + markdown

6. AI attention backend
   - simple backend remains fallback
   - optional DINOv2 / ViT / SAM mask
   - reflective / low texture / dynamic blur masks

## 禁止

- 不得把 video frame adapter 說成真 SfM。
- 不得把 sample data 說成真實資料驗證。
- 不得刪除舊包。
- 不得把待驗證項升格為已完成。

## 驗收命令

```bash
cd packages/MRL_3D_AI_Reconstruction_System_v1_REAL
python -m mrl3d.cli run --config config/demo_simulate.yaml
python -m mrl3d.cli run --config config/mesh_obj.yaml
python -m mrl3d.cli run --config config/video_frames.yaml
```

真資料補齊後還必須通過：

```bash
python -m mrl3d.cli run --config config/colmap.yaml
python -m mrl3d.cli run --config config/video_colmap.yaml
python -m mrl3d.cli run --config config/openmvs_mesh.yaml
```

