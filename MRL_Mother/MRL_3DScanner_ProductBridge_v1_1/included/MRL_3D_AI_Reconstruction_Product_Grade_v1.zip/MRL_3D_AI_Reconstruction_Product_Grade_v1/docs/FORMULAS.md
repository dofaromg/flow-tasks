# Formula Reference

## 1. Camera Projection

World to camera:

```math
X_c = R X_w + t = [x_c, y_c, z_c]^T
```

Pinhole projection:

```math
x = x_c / z_c, \quad y = y_c / z_c
```

```math
u = f_x x + c_x, \quad v = f_y y + c_y
```

Reprojection error:

```math
e_{ij} = ||x_{ij} - \hat{x}_{ij}||_2
```

## 2. Distortion Models

SIMPLE_RADIAL:

```math
r^2 = x^2 + y^2
```

```math
x' = x(1 + k_1 r^2), \quad y' = y(1 + k_1 r^2)
```

RADIAL:

```math
x' = x(1 + k_1 r^2 + k_2 r^4), \quad y' = y(1 + k_1 r^2 + k_2 r^4)
```

OPENCV:

```math
radial = 1 + k_1 r^2 + k_2 r^4 + k_3 r^6
```

```math
x' = x radial + 2p_1xy + p_2(r^2 + 2x^2)
```

```math
y' = y radial + p_1(r^2 + 2y^2) + 2p_2xy
```

## 3. Attention-Weighted Error

Attention map:

```math
w_i(u, v) \in [0, 1]
```

Weighted reprojection error:

```math
\bar{e}_{ij} = (\epsilon + (1 - \epsilon)w_i(u_{ij}, v_{ij})) e_{ij}
```

## 4. Heatmap Aggregation

```math
H_i(u, v) = Agg_{j: \hat{x}_{ij} \approx (u, v)}(\bar{e}_{ij})
```

This package uses max accumulation for sparse observations and tile-mean ranking for suggestions.

## 5. Mesh Coverage

For a mesh vertex `p` observed by synthetic camera `i`:

```math
c_{ip} = max(0.05, n_p \cdot \hat{v}_{ip})
```

where `n_p` is the vertex normal and `v` is the direction from point to camera. Low coverage tiles are suggested for reshoot / rescan.

## 6. Context Graph

Heatmap correlation:

```math
corr(H_a, H_b) = Cov(H_a, H_b) / (\sigma_a \sigma_b)
```

Pairs with negative or low correlation are treated as complementary views.

## 7. MRL Expansion Law

MRL high-level state growth / reduction relation:

```math
P_{k+1} = N_k \cdot P_k \cdot \eta_k
```

In this package:

- `P_k`: current scene evidence, camera tracks, mesh vertices, or frame observations.
- `N_k`: number of views, tracks, tiles, cameras, or mesh samples.
- `eta_k`: confidence / attention / coverage / reprojection quality.

This is used as an engineering interpretation, not as a substitute for geometric calibration.
