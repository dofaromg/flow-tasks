# Product-Grade Acceptance

## Completed

- Installable Python package with CLI entrypoint `mrl3d`.
- Runnable adapters: simulate, COLMAP text, video, OBJ mesh, ASCII PLY mesh.
- Attention-weighted error / coverage heatmaps.
- Context graph and next-best-view / reshoot suggestions.
- Geometry-domain mesh heatmap output as colored PLY.
- Sample data included for all non-external modes.
- Tests included and run in this environment.

## Verified locally in this delivery

- `mrl3d run --config config/simulate.yaml`
- `mrl3d run --config config/colmap_text.yaml`
- `mrl3d run --config config/video.yaml`
- `mrl3d run --config config/mesh_obj.yaml`
- `mrl3d run --config config/mesh_ply.yaml`
- `pytest -q`

## Not marked complete

- Real-world COLMAP/OpenMVS reconstruction of a user-captured scene is not claimed until the user supplies real camera/images or local external tools run.
- This package is a reconstruction-assistant and diagnostics pipeline. It is not pretending to be Polycam as a full consumer mobile app.
