# Known Limits

- Video mode alone cannot compute true SfM reprojection error because camera poses and 2D-3D tracks are not available until COLMAP or a similar tool is run.
- Built-in PLY reader supports ASCII PLY. Use OBJ or convert binary PLY to ASCII if needed.
- ViT attention is optional and requires torch/timm. The default simple attention is deterministic and lightweight.
- NBV suggestions are conservative diagnostic hints, not a full global next-best-view optimizer.
- Mesh coverage mode uses synthetic orbit cameras; real scanner trajectories produce more accurate coverage analysis if provided.
