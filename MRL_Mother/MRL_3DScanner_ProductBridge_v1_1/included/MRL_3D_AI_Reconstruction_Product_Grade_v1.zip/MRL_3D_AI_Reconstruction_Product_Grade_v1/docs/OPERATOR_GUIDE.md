# Operator Guide

## Build order

1. Install package with `pip install -e .`.
2. Run sample configs.
3. Replace sample paths with real data.
4. Compare `metrics_summary.csv`, `overlays/*.png`, and `suggestions.json`.
5. If suggestions show high error or low coverage, reshoot / rescan and rerun.

## Input modes

### `simulate`
Useful for testing pipeline integrity.

### `colmap`
Use for true reprojection error. Requires COLMAP text outputs.

### `video`
Extracts frames and produces frame-quality diagnostics. To compute true reprojection error, run COLMAP on frames and then switch to `colmap` mode.

### `mesh_obj` / `mesh_ply`
Computes coverage diagnostics with synthetic orbit cameras and exports `mesh_vertex_heatmap.ply`.

## External tools

COLMAP and OpenMVS are optional. The package can read their outputs. Wrappers are provided, but they only run when the executables are installed locally.
