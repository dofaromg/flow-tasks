# MRL_3D_AI_Reconstruction_Product_Grade_v1

MRL 3D AI Reconstruction product-grade diagnostic package.

This package is not only a formula note. It is an installable Python package with real runnable adapters for:

- simulated calibrated multi-view data,
- COLMAP text models (`cameras.txt`, `images.txt`, `points3D.txt`),
- video frame extraction and frame-quality diagnostics,
- OBJ / ASCII PLY mesh coverage diagnostics.

It produces attention-weighted heatmaps, metrics, context links, next-best-view / reshoot suggestions, and geometry-domain mesh heatmaps.

## Install

```bash
cd MRL_3D_AI_Reconstruction_Product_Grade_v1
python -m venv .venv
. .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e .
```

## Run verified demos

```bash
mrl3d run --config config/simulate.yaml
mrl3d run --config config/colmap_text.yaml
mrl3d run --config config/video.yaml
mrl3d run --config config/mesh_obj.yaml
mrl3d run --config config/mesh_ply.yaml
```

Outputs are written to `verified_outputs/<mode>/` and include:

- `RUN_REPORT.md`
- `metrics.json`
- `metrics_summary.csv`
- `suggestions.json`
- `links.json`
- `overlays/heatmap_*.png`
- `heatmaps/heatmap_*.npy`
- `mesh_vertex_heatmap.ply` for mesh modes

## Real COLMAP data

Place a text model here:

```text
my_scene/colmap_text/cameras.txt
my_scene/colmap_text/images.txt
my_scene/colmap_text/points3D.txt
my_scene/images/<image files referenced by images.txt>
```

Then create a config like:

```yaml
out_dir: ./outputs/my_scene
input:
  type: colmap
  colmap_dir: ./my_scene/colmap_text
  images_dir: ./my_scene/images
  read_images: true
attention:
  backend: simple
suggestion:
  objective: error
  tiles: [4, 4]
  topk: 5
```

Run:

```bash
mrl3d run --config my_scene.yaml
```

## Real video data

Video mode extracts frames and runs frame-quality / attention diagnostics. For true reprojection error, run COLMAP on extracted frames using `mrl3d run-colmap` if COLMAP is installed, then run the COLMAP text adapter.

```bash
mrl3d run --config config/video.yaml
mrl3d run-colmap --images ./sample_data/video_frames --work-dir ./colmap_work --cpu
```

## Real mesh data

Use `input.type: mesh_obj` or `input.type: mesh_ply` and point to an OBJ / ASCII PLY. The package will synthesize orbit cameras, compute coverage heatmaps, and export a colored PLY.

## Scope

This is a product-grade diagnostic and reconstruction-assistant package. It does not falsely claim to replace COLMAP/OpenMVS/NeRF. It integrates with them, analyzes their output, and generates attention-guided repair suggestions.
