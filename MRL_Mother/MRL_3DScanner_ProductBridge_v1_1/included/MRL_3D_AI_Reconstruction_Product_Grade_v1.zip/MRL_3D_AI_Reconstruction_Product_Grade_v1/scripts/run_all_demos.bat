python -m mrl3d.cli run --config config/simulate.yaml
python -m mrl3d.cli run --config config/colmap_text.yaml
python -m mrl3d.cli run --config config/video.yaml
python -m mrl3d.cli run --config config/mesh_obj.yaml
python -m mrl3d.cli run --config config/mesh_ply.yaml
