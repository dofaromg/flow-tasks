# -*- coding: utf-8 -*-
from pathlib import Path
import math
import sys
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mrl3d.geometry.camera import look_at_rotation, project_point
from mrl3d.geometry.ply import write_ply


def rot_to_quat(R):
    # Returns qw qx qy qz for rotation matrix.
    m = R
    tr = np.trace(m)
    if tr > 0:
        S = math.sqrt(tr + 1.0) * 2
        qw = 0.25 * S
        qx = (m[2,1] - m[1,2]) / S
        qy = (m[0,2] - m[2,0]) / S
        qz = (m[1,0] - m[0,1]) / S
    elif (m[0,0] > m[1,1]) and (m[0,0] > m[2,2]):
        S = math.sqrt(1.0 + m[0,0] - m[1,1] - m[2,2]) * 2
        qw = (m[2,1] - m[1,2]) / S
        qx = 0.25 * S
        qy = (m[0,1] + m[1,0]) / S
        qz = (m[0,2] + m[2,0]) / S
    elif m[1,1] > m[2,2]:
        S = math.sqrt(1.0 + m[1,1] - m[0,0] - m[2,2]) * 2
        qw = (m[0,2] - m[2,0]) / S
        qx = (m[0,1] + m[1,0]) / S
        qy = 0.25 * S
        qz = (m[1,2] + m[2,1]) / S
    else:
        S = math.sqrt(1.0 + m[2,2] - m[0,0] - m[1,1]) * 2
        qw = (m[1,0] - m[0,1]) / S
        qx = (m[0,2] + m[2,0]) / S
        qy = (m[1,2] + m[2,1]) / S
        qz = 0.25 * S
    return qw, qx, qy, qz


def make_cube_mesh():
    verts = np.array([
        [-0.5,-0.5,-0.5],[0.5,-0.5,-0.5],[0.5,0.5,-0.5],[-0.5,0.5,-0.5],
        [-0.5,-0.5,0.5],[0.5,-0.5,0.5],[0.5,0.5,0.5],[-0.5,0.5,0.5]
    ], dtype=float)
    faces = np.array([
        [0,1,2],[0,2,3],[4,6,5],[4,7,6],[0,4,5],[0,5,1],
        [1,5,6],[1,6,2],[2,6,7],[2,7,3],[3,7,4],[3,4,0]
    ], dtype=int)
    mesh_dir = ROOT / 'sample_data' / 'mesh'
    mesh_dir.mkdir(parents=True, exist_ok=True)
    with open(mesh_dir / 'cube.obj', 'w') as f:
        for v in verts:
            f.write(f"v {v[0]} {v[1]} {v[2]}\n")
        for face in faces + 1:
            f.write(f"f {face[0]} {face[1]} {face[2]}\n")
    write_ply(str(mesh_dir / 'cube.ply'), verts, faces)
    return verts, faces


def make_surface_points():
    pts=[]
    for x in np.linspace(-0.5,0.5,6):
        for y in np.linspace(-0.5,0.5,6):
            for z in np.linspace(-0.5,0.5,6):
                if abs(x)==0.5 or abs(y)==0.5 or abs(z)==0.5:
                    pts.append((float(x),float(y),float(z)))
    return pts


def main():
    (ROOT / 'sample_data' / 'images').mkdir(parents=True, exist_ok=True)
    (ROOT / 'sample_data' / 'colmap_text').mkdir(parents=True, exist_ok=True)
    (ROOT / 'sample_data' / 'video').mkdir(parents=True, exist_ok=True)
    (ROOT / 'sample_data' / 'video_frames').mkdir(parents=True, exist_ok=True)
    make_cube_mesh()
    pts = make_surface_points()
    W,H = 640,480
    fx = fy = (W/2)/math.tan(math.radians(55)/2)
    cx,cy = W/2,H/2
    target = np.array([0.0,0.0,0.0])
    radius = 2.6
    rng = np.random.default_rng(12)
    # cameras.txt: one PINHOLE camera shared.
    (ROOT/'sample_data'/'colmap_text'/'cameras.txt').write_text(f"# CAMERA_ID MODEL WIDTH HEIGHT PARAMS\n1 PINHOLE {W} {H} {fx} {fy} {cx} {cy}\n", encoding='utf-8')
    # points3D.txt
    p_lines=["# POINT3D_ID X Y Z R G B ERROR TRACK[]"]
    for i,p in enumerate(pts, start=1):
        color=(80+(i*17)%155, 80+(i*31)%155, 80+(i*47)%155)
        p_lines.append(f"{i} {p[0]} {p[1]} {p[2]} {color[0]} {color[1]} {color[2]} 0.2")
    (ROOT/'sample_data'/'colmap_text'/'points3D.txt').write_text('\n'.join(p_lines)+'\n', encoding='utf-8')
    image_lines=["# IMAGE_ID QW QX QY QZ TX TY TZ CAMERA_ID NAME", "# POINTS2D[] as (X Y POINT3D_ID)"]
    video_frames=[]
    for ci,theta in enumerate(np.linspace(0, 2*math.pi, 6, endpoint=False), start=1):
        cam_pos = np.array([radius*math.cos(theta), 0.45+0.15*math.sin(2*theta), radius*math.sin(theta)])
        R = look_at_rotation(cam_pos, target)
        t = -R @ cam_pos
        qw,qx,qy,qz = rot_to_quat(R)
        name=f"image_{ci:03d}.png"
        img=np.zeros((H,W,3), dtype=np.uint8); img[:]=(18,18,24)
        obs=[]
        for pid,p in enumerate(pts, start=1):
            uvz=project_point(p, R, t, (fx,fy,cx,cy))
            if uvz is None: continue
            u,v,z=uvz
            if 0<=u<W and 0<=v<H:
                uo = u + rng.normal(0, 0.85)
                vo = v + rng.normal(0, 0.85)
                obs.extend([f"{uo:.5f}", f"{vo:.5f}", str(pid)])
                cv2.circle(img, (int(round(uo)), int(round(vo))), 3, (80+(pid*13)%150, 160, 230), -1)
        cv2.putText(img, f"MRL COLMAP sample {ci}", (18, H-20), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (180,180,180), 1)
        cv2.imwrite(str(ROOT/'sample_data'/'images'/name), img)
        video_frames.append(img)
        image_lines.append(f"{ci} {qw} {qx} {qy} {qz} {t[0]} {t[1]} {t[2]} 1 {name}")
        image_lines.append(' '.join(obs))
    (ROOT/'sample_data'/'colmap_text'/'images.txt').write_text('\n'.join(image_lines)+'\n', encoding='utf-8')
    # Video sample.
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(str(ROOT/'sample_data'/'video'/'sample.mp4'), fourcc, 6.0, (W,H))
    for frame in video_frames:
        out.write(frame)
    out.release()

if __name__ == '__main__':
    main()
