# MRL 3D AI Reconstruction Run Report

Adapter: `simulate`
Cameras: 6
Points: 98
Global weighted metric p90: 1.008531

## Outputs
- `metrics.json`, `metrics_summary.csv`
- `suggestions.json`
- `overlays/heatmap_*.png`, `heatmaps/heatmap_*.npy`
- `mesh_vertex_heatmap.ply`, `mesh_quality.json`

## Top suggestion summary
- sim_000: [{'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0007265767198987305}, {'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0006444321479648352}, {'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.0005022597033530474}]
- sim_001: [{'tile_rc': [1, 1], 'bbox_xyxy': [160, 120, 320, 240], 'score': 0.0006225947290658951}, {'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0005986830219626427}, {'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.0005731350393034518}]
- sim_002: [{'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0006536947912536561}, {'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0006112007540650666}, {'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.0005708042299374938}]
- sim_003: [{'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0006947838119231164}, {'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0006561755435541272}, {'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.0006450223154388368}]
- sim_004: [{'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.0006397815886884928}, {'tile_rc': [1, 1], 'bbox_xyxy': [160, 120, 320, 240], 'score': 0.0005992853548377752}, {'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0005700463079847395}]
- sim_005: [{'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.000584164634346962}, {'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.0005744681693613529}, {'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0005628173239529133}]