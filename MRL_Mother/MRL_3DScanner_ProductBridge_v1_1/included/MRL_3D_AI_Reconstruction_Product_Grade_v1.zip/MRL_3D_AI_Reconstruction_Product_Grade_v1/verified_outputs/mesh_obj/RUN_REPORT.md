# MRL 3D AI Reconstruction Run Report

Adapter: `mesh`
Cameras: 8
Points: 8
Global weighted metric p90: 0.343724

## Outputs
- `metrics.json`, `metrics_summary.csv`
- `suggestions.json`
- `overlays/heatmap_*.png`, `heatmaps/heatmap_*.npy`
- `mesh_vertex_heatmap.ply`, `mesh_quality.json`

## Top suggestion summary
- mesh_000: [{'tile_rc': [0, 1], 'bbox_xyxy': [160, 0, 320, 120], 'score': 0.0}, {'tile_rc': [0, 2], 'bbox_xyxy': [320, 0, 480, 120], 'score': 0.0}, {'tile_rc': [1, 0], 'bbox_xyxy': [0, 120, 160, 240], 'score': 0.0}]
- mesh_001: [{'tile_rc': [0, 0], 'bbox_xyxy': [0, 0, 160, 120], 'score': 0.0}, {'tile_rc': [0, 1], 'bbox_xyxy': [160, 0, 320, 120], 'score': 0.0}, {'tile_rc': [0, 2], 'bbox_xyxy': [320, 0, 480, 120], 'score': 0.0}]
- mesh_002: [{'tile_rc': [0, 1], 'bbox_xyxy': [160, 0, 320, 120], 'score': 0.0}, {'tile_rc': [0, 2], 'bbox_xyxy': [320, 0, 480, 120], 'score': 0.0}, {'tile_rc': [1, 0], 'bbox_xyxy': [0, 120, 160, 240], 'score': 0.0}]
- mesh_003: [{'tile_rc': [0, 0], 'bbox_xyxy': [0, 0, 160, 120], 'score': 0.0}, {'tile_rc': [0, 1], 'bbox_xyxy': [160, 0, 320, 120], 'score': 0.0}, {'tile_rc': [0, 2], 'bbox_xyxy': [320, 0, 480, 120], 'score': 0.0}]
- mesh_004: [{'tile_rc': [0, 1], 'bbox_xyxy': [160, 0, 320, 120], 'score': 0.0}, {'tile_rc': [0, 2], 'bbox_xyxy': [320, 0, 480, 120], 'score': 0.0}, {'tile_rc': [1, 0], 'bbox_xyxy': [0, 120, 160, 240], 'score': 0.0}]
- mesh_005: [{'tile_rc': [0, 0], 'bbox_xyxy': [0, 0, 160, 120], 'score': 0.0}, {'tile_rc': [0, 1], 'bbox_xyxy': [160, 0, 320, 120], 'score': 0.0}, {'tile_rc': [0, 2], 'bbox_xyxy': [320, 0, 480, 120], 'score': 0.0}]
- mesh_006: [{'tile_rc': [0, 1], 'bbox_xyxy': [160, 0, 320, 120], 'score': 0.0}, {'tile_rc': [0, 2], 'bbox_xyxy': [320, 0, 480, 120], 'score': 0.0}, {'tile_rc': [1, 0], 'bbox_xyxy': [0, 120, 160, 240], 'score': 0.0}]
- mesh_007: [{'tile_rc': [0, 0], 'bbox_xyxy': [0, 0, 160, 120], 'score': 0.0}, {'tile_rc': [0, 1], 'bbox_xyxy': [160, 0, 320, 120], 'score': 0.0}, {'tile_rc': [0, 2], 'bbox_xyxy': [320, 0, 480, 120], 'score': 0.0}]