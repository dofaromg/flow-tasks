# MRL 3D AI Reconstruction Run Report

Adapter: `video`
Cameras: 2
Points: 128
Global weighted metric p90: 0.292391

## Outputs
- `metrics.json`, `metrics_summary.csv`
- `suggestions.json`
- `overlays/heatmap_*.png`, `heatmaps/heatmap_*.npy`

## Top suggestion summary
- frame_0000: [{'tile_rc': [1, 0], 'bbox_xyxy': [0, 120, 160, 240], 'score': 5.858071017428301e-05}, {'tile_rc': [1, 3], 'bbox_xyxy': [480, 120, 640, 240], 'score': 5.858071017428301e-05}, {'tile_rc': [2, 0], 'bbox_xyxy': [0, 240, 160, 360], 'score': 5.858069926034659e-05}]
- frame_0001: [{'tile_rc': [1, 0], 'bbox_xyxy': [0, 120, 160, 240], 'score': 5.865350249223411e-05}, {'tile_rc': [2, 0], 'bbox_xyxy': [0, 240, 160, 360], 'score': 5.865341518074274e-05}, {'tile_rc': [2, 3], 'bbox_xyxy': [480, 240, 640, 360], 'score': 5.8653185988077894e-05}]