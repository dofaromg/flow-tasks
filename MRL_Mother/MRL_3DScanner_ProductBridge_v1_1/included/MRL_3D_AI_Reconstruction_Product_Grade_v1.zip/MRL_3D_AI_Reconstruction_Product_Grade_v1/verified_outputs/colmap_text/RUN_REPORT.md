# MRL 3D AI Reconstruction Run Report

Adapter: `colmap`
Cameras: 6
Points: 152
Global weighted metric p90: 0.770674

## Outputs
- `metrics.json`, `metrics_summary.csv`
- `suggestions.json`
- `overlays/heatmap_*.png`, `heatmaps/heatmap_*.npy`

## Top suggestion summary
- 1: [{'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0007605082937516272}, {'tile_rc': [1, 1], 'bbox_xyxy': [160, 120, 320, 240], 'score': 0.0007548135472461581}, {'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0007084683165885508}]
- 2: [{'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0008551927166990936}, {'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.0007849354296922684}, {'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0006286338903009892}]
- 3: [{'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0007909827399998903}, {'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0006795520312152803}, {'tile_rc': [1, 1], 'bbox_xyxy': [160, 120, 320, 240], 'score': 0.0006615685997530818}]
- 4: [{'tile_rc': [1, 1], 'bbox_xyxy': [160, 120, 320, 240], 'score': 0.0008846473647281528}, {'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0007634826470166445}, {'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0006915353005751967}]
- 5: [{'tile_rc': [2, 2], 'bbox_xyxy': [320, 240, 480, 360], 'score': 0.0007912430446594954}, {'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.000743009673897177}, {'tile_rc': [1, 1], 'bbox_xyxy': [160, 120, 320, 240], 'score': 0.0007166048744693398}]
- 6: [{'tile_rc': [1, 2], 'bbox_xyxy': [320, 120, 480, 240], 'score': 0.0007694030646234751}, {'tile_rc': [2, 1], 'bbox_xyxy': [160, 240, 320, 360], 'score': 0.0007673500804230571}, {'tile_rc': [1, 1], 'bbox_xyxy': [160, 120, 320, 240], 'score': 0.0007219478720799088}]