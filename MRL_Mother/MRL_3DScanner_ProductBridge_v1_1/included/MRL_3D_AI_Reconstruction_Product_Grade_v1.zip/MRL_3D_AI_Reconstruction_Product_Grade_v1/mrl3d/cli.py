# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse
import json
from pathlib import Path
import shutil

from mrl3d.pipeline.runner import run_pipeline
from mrl3d.external.colmap_runner import run_colmap_from_images


def _write_init(path: str):
    dst = Path(path)
    dst.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parents[1]
    for sub in ("config", "sample_data"):
        src = root / sub
        if src.exists():
            shutil.copytree(src, dst / sub, dirs_exist_ok=True)
    print(f"Initialized MRL3D project at {dst}")


def main(argv=None):
    parser = argparse.ArgumentParser(prog="mrl3d", description="MRL 3D AI Reconstruction diagnostic pipeline")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser("run", help="Run reconstruction diagnostics from YAML config")
    p_run.add_argument("--config", required=True)

    p_init = sub.add_parser("init", help="Copy sample config/data into a folder")
    p_init.add_argument("path", nargs="?", default="./mrl3d_project")

    p_colmap = sub.add_parser("run-colmap", help="Run COLMAP on an image folder if COLMAP is installed")
    p_colmap.add_argument("--images", required=True)
    p_colmap.add_argument("--work-dir", required=True)
    p_colmap.add_argument("--cpu", action="store_true")

    args = parser.parse_args(argv)
    if args.cmd == "run":
        result = run_pipeline(args.config)
        print(json.dumps({"output_dir": result["output_dir"], "global": result["metrics"].get("global"), "meta": result.get("meta")}, indent=2, ensure_ascii=False))
    elif args.cmd == "init":
        _write_init(args.path)
    elif args.cmd == "run-colmap":
        print(json.dumps(run_colmap_from_images(args.images, args.work_dir, use_gpu=not args.cpu), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
