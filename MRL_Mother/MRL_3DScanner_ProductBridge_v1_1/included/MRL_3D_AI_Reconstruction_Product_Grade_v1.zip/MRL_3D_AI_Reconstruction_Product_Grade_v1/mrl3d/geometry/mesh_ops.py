# -*- coding: utf-8 -*-
from __future__ import annotations
import numpy as np


def compute_face_normals(vertices: np.ndarray, faces: np.ndarray) -> np.ndarray:
    if faces.size == 0:
        return np.zeros((0, 3), dtype=np.float64)
    v0 = vertices[faces[:, 0]]
    v1 = vertices[faces[:, 1]]
    v2 = vertices[faces[:, 2]]
    n = np.cross(v1 - v0, v2 - v0)
    n /= (np.linalg.norm(n, axis=1, keepdims=True) + 1e-12)
    return n


def compute_vertex_normals(vertices: np.ndarray, faces: np.ndarray) -> np.ndarray:
    normals = np.zeros_like(vertices, dtype=np.float64)
    if faces.size == 0:
        return normals
    fn = compute_face_normals(vertices, faces)
    for fi, f in enumerate(faces):
        normals[f] += fn[fi]
    normals /= (np.linalg.norm(normals, axis=1, keepdims=True) + 1e-12)
    return normals


def mesh_quality(vertices: np.ndarray, faces: np.ndarray) -> dict:
    out = {"num_vertices": int(len(vertices)), "num_faces": int(len(faces))}
    if len(vertices) == 0:
        return out
    bb_min = vertices.min(axis=0)
    bb_max = vertices.max(axis=0)
    extent = bb_max - bb_min
    out["bbox_min"] = bb_min.tolist()
    out["bbox_max"] = bb_max.tolist()
    out["bbox_extent"] = extent.tolist()
    out["bbox_diag"] = float(np.linalg.norm(extent))
    if faces.size:
        edges = set()
        for a, b, c in faces.tolist():
            for u, v in ((a, b), (b, c), (c, a)):
                edges.add(tuple(sorted((int(u), int(v)))))
        lengths = [np.linalg.norm(vertices[u] - vertices[v]) for u, v in edges]
        out["edge_mean"] = float(np.mean(lengths)) if lengths else 0.0
        out["edge_p95"] = float(np.percentile(lengths, 95)) if lengths else 0.0
    return out


def color_map_values(values: np.ndarray) -> np.ndarray:
    """Simple blue-to-red color mapping. Returns uint8 RGB."""
    if values.size == 0:
        return np.zeros((0, 3), dtype=np.uint8)
    v = values.astype(np.float64)
    v = (v - np.nanmin(v)) / (np.nanmax(v) - np.nanmin(v) + 1e-12)
    r = (255 * v).clip(0, 255)
    g = (255 * (1.0 - np.abs(v - 0.5) * 2.0)).clip(0, 255)
    b = (255 * (1.0 - v)).clip(0, 255)
    return np.stack([r, g, b], axis=1).astype(np.uint8)
