# -*- coding: utf-8 -*-
from __future__ import annotations
import math
import numpy as np


def quat_to_rot(qw: float, qx: float, qy: float, qz: float) -> np.ndarray:
    n = math.sqrt(qw * qw + qx * qx + qy * qy + qz * qz)
    if n <= 1e-12:
        return np.eye(3, dtype=np.float64)
    qw, qx, qy, qz = qw / n, qx / n, qy / n, qz / n
    return np.array([
        [1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw)],
        [2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw)],
        [2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy)],
    ], dtype=np.float64)


def look_at_rotation(camera_pos: np.ndarray, target: np.ndarray, up=np.array([0, 1, 0], dtype=np.float64)) -> np.ndarray:
    """World-to-camera rotation. Camera z-axis points toward target."""
    z = target - camera_pos
    z = z / (np.linalg.norm(z) + 1e-12)
    x = np.cross(up, z)
    if np.linalg.norm(x) < 1e-9:
        x = np.cross(np.array([1, 0, 0], dtype=np.float64), z)
    x = x / (np.linalg.norm(x) + 1e-12)
    y = np.cross(z, x)
    y = y / (np.linalg.norm(y) + 1e-12)
    return np.stack([x, y, z], axis=0)


def distort_xy(x: float, y: float, model: str, params: list[float]) -> tuple[float, float]:
    model = (model or "PINHOLE").upper()
    if model == "SIMPLE_RADIAL" and len(params) >= 4:
        k1 = params[3]
        r2 = x * x + y * y
        return x * (1 + k1 * r2), y * (1 + k1 * r2)
    if model == "RADIAL" and len(params) >= 6:
        k1, k2 = params[4], params[5]
        r2 = x * x + y * y
        radial = 1 + k1 * r2 + k2 * r2 * r2
        return x * radial, y * radial
    if model in ("OPENCV", "FULL_OPENCV") and len(params) >= 8:
        k1 = params[4] if len(params) > 4 else 0.0
        k2 = params[5] if len(params) > 5 else 0.0
        p1 = params[6] if len(params) > 6 else 0.0
        p2 = params[7] if len(params) > 7 else 0.0
        k3 = params[8] if len(params) > 8 else 0.0
        r2 = x * x + y * y
        radial = 1 + k1 * r2 + k2 * r2 * r2 + k3 * r2 * r2 * r2
        xd = x * radial + 2 * p1 * x * y + p2 * (r2 + 2 * x * x)
        yd = y * radial + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y
        return xd, yd
    if model in ("FOV",):
        # COLMAP FOV: fx fy cx cy omega. Good enough for diagnostics.
        if len(params) >= 5:
            omega = params[4]
            r = math.sqrt(x * x + y * y)
            if abs(omega) > 1e-9 and r > 1e-9:
                factor = math.atan(r * math.tan(omega / 2.0)) / (r * omega / 2.0)
                return x * factor, y * factor
    return x, y


def project_point(xyz_world, R: np.ndarray, t: np.ndarray, K: tuple[float, float, float, float], model="PINHOLE", params=None):
    params = params or []
    X = np.asarray(xyz_world, dtype=np.float64).reshape(3, 1)
    xc = (R @ X + t.reshape(3, 1)).flatten()
    if xc[2] <= 1e-9:
        return None
    x = xc[0] / xc[2]
    y = xc[1] / xc[2]
    x, y = distort_xy(float(x), float(y), model, params)
    fx, fy, cx, cy = K
    return float(fx * x + cx), float(fy * y + cy), float(xc[2])


def camera_center_from_rt(R: np.ndarray, t: np.ndarray) -> np.ndarray:
    return -R.T @ t.reshape(3)
