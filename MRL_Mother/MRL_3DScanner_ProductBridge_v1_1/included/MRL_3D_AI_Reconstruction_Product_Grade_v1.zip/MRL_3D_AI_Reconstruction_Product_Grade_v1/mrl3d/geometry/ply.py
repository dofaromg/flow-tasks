# -*- coding: utf-8 -*-
from __future__ import annotations
import numpy as np


def read_ply_vertices_faces(path: str):
    """Small ASCII PLY reader for vertices/faces. Binary PLY is intentionally rejected."""
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        line = f.readline().strip()
        if line != "ply":
            raise ValueError("Not a PLY file")
        fmt = None
        n_vertices = 0
        n_faces = 0
        while True:
            line = f.readline().strip()
            if line.startswith("format"):
                fmt = line.split()[1]
            elif line.startswith("element vertex"):
                n_vertices = int(line.split()[2])
            elif line.startswith("element face"):
                n_faces = int(line.split()[2])
            elif line == "end_header":
                break
        if fmt != "ascii":
            raise ValueError("Only ASCII PLY is supported by the built-in reader")
        verts = []
        for _ in range(n_vertices):
            toks = f.readline().split()
            verts.append([float(toks[0]), float(toks[1]), float(toks[2])])
        faces = []
        for _ in range(n_faces):
            toks = f.readline().split()
            if not toks:
                continue
            n = int(toks[0])
            if n >= 3:
                ids = list(map(int, toks[1:1+n]))
                # triangulate fan
                for k in range(1, n-1):
                    faces.append([ids[0], ids[k], ids[k+1]])
        return np.asarray(verts, dtype=np.float64), np.asarray(faces, dtype=np.int32)


def write_ply(path: str, vertices: np.ndarray, faces: np.ndarray | None = None, colors: np.ndarray | None = None):
    faces = faces if faces is not None else np.zeros((0, 3), dtype=np.int32)
    has_colors = colors is not None and len(colors) == len(vertices)
    with open(path, "w", encoding="utf-8") as f:
        f.write("ply\nformat ascii 1.0\n")
        f.write(f"element vertex {len(vertices)}\n")
        f.write("property float x\nproperty float y\nproperty float z\n")
        if has_colors:
            f.write("property uchar red\nproperty uchar green\nproperty uchar blue\n")
        f.write(f"element face {len(faces)}\n")
        f.write("property list uchar int vertex_indices\n")
        f.write("end_header\n")
        for i, v in enumerate(vertices):
            if has_colors:
                c = colors[i]
                f.write(f"{v[0]} {v[1]} {v[2]} {int(c[0])} {int(c[1])} {int(c[2])}\n")
            else:
                f.write(f"{v[0]} {v[1]} {v[2]}\n")
        for face in faces:
            f.write(f"3 {int(face[0])} {int(face[1])} {int(face[2])}\n")
