# -*- coding: utf-8 -*-
from __future__ import annotations
from collections import defaultdict
import numpy as np
from mrl3d.pipeline.metrics import summarize_values


class ErrorMapper:
    def __init__(self, cfg):
        self.cfg = cfg
        self.mode = cfg.get("suggestion", {}).get("objective", "auto").lower()

    def make(self, scene, attn_maps):
        heatmaps = {}
        metrics = {"per_camera": {}, "global": {}, "vertex_scores": None}
        all_weighted = []
        vertex_values = defaultdict(list)

        for cid, cam in scene.cameras.items():
            H, W = cam.height, cam.width
            hm = np.zeros((H, W), dtype=np.float32)
            cnt = np.zeros((H, W), dtype=np.float32)
            weighted_vals = []
            raw_vals = []
            kind_counts = defaultdict(int)
            attn = attn_maps.get(cid, np.ones((H, W), dtype=np.float32))
            for ob in scene.tracks.get(cid, []):
                u = int(round(ob.u)); v = int(round(ob.v))
                if 0 <= u < W and 0 <= v < H:
                    a = float(attn[v, u])
                    if ob.kind == "coverage":
                        val = float(ob.value) * max(0.05, a)
                    elif ob.kind == "frame_quality":
                        val = float(ob.value) * (0.25 + 0.75 * a)
                    else:
                        val = float(ob.value) * (0.10 + 0.90 * a)
                    hm[v, u] += val
                    cnt[v, u] += 1.0
                    weighted_vals.append(val)
                    raw_vals.append(float(ob.value))
                    kind_counts[ob.kind] += 1
                    vertex_values[ob.point_id].append(val)
            cnt[cnt == 0] = 1.0
            hm = hm / cnt
            heatmaps[cid] = hm
            metrics["per_camera"][cid] = {
                "weighted": summarize_values(weighted_vals),
                "raw": summarize_values(raw_vals),
                "nonzero_fraction": float((hm > 0).mean()),
                "kind_counts": dict(kind_counts),
            }
            all_weighted.extend(weighted_vals)

        metrics["global"] = summarize_values(all_weighted)
        if scene.mesh is not None and scene.mesh.vertices is not None:
            scores = np.zeros(len(scene.mesh.vertices), dtype=np.float64)
            for pid in range(len(scores)):
                if pid in vertex_values:
                    scores[pid] = float(np.mean(vertex_values[pid]))
            metrics["vertex_scores"] = scores.tolist()
        return heatmaps, metrics
