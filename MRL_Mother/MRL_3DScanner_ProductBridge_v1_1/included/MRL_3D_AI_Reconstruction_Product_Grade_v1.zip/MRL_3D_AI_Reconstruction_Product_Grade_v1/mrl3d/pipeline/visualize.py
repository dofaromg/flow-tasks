# -*- coding: utf-8 -*-
from __future__ import annotations
import cv2
import numpy as np


def normalize_u8(arr):
    a = arr.astype(np.float32)
    a = a - np.nanmin(a)
    a = a / (np.nanmax(a) + 1e-6)
    return (a * 255).clip(0, 255).astype(np.uint8)


def heatmap_png(arr, image=None):
    hm = cv2.applyColorMap(normalize_u8(arr), cv2.COLORMAP_JET)
    if image is None or image.shape[:2] != arr.shape[:2]:
        return hm
    return cv2.addWeighted(image, 0.55, hm, 0.45, 0)
