# -*- coding: utf-8 -*-
from __future__ import annotations
import numpy as np
from mrl3d.geometry.camera import camera_center_from_rt


class ContextGraph:
    def __init__(self, cfg):
        self.cfg = cfg
        self.neg_corr_threshold = float(cfg.get("context", {}).get("neg_corr_threshold", -0.05))
        self.max_edges = int(cfg.get("context", {}).get("max_edges", 50))

    @staticmethod
    def _corr(a, b):
        a = a.flatten(); b = b.flatten()
        if a.size < 2 or b.size < 2 or a.std() < 1e-9 or b.std() < 1e-9:
            return 0.0
        return float(np.corrcoef(a, b)[0, 1])

    def build(self, scene, heatmaps):
        ids = list(heatmaps.keys())
        edges = []
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                a, b = ids[i], ids[j]
                corr = self._corr(heatmaps[a], heatmaps[b])
                meta = {"a": a, "b": b, "heatmap_corr": corr}
                ca = scene.cameras[a]; cb = scene.cameras[b]
                if ca.R is not None and cb.R is not None and ca.t is not None and cb.t is not None:
                    A = camera_center_from_rt(ca.R, ca.t)
                    B = camera_center_from_rt(cb.R, cb.t)
                    meta["baseline"] = float(np.linalg.norm(A - B))
                if corr <= self.neg_corr_threshold:
                    meta["relationship"] = "complementary"
                    edges.append(meta)
        edges = sorted(edges, key=lambda e: e.get("heatmap_corr", 0.0))[:self.max_edges]
        return {"edges": edges, "num_edges": len(edges)}
