# -*- coding: utf-8 -*-
from __future__ import annotations
import numpy as np
from mrl3d.geometry.camera import camera_center_from_rt


def _tile_bounds(H, W, tiles, rc):
    r, c = tiles
    rows = np.linspace(0, H, r + 1, dtype=int)
    cols = np.linspace(0, W, c + 1, dtype=int)
    i, j = rc
    return int(rows[i]), int(rows[i+1]), int(cols[j]), int(cols[j+1])


class NBVGenerator:
    """Approximate next-best-view hints. It does not claim to solve full NBV optimization."""
    def __init__(self, cfg):
        self.cfg = cfg
        self.tiles = cfg.get("suggestion", {}).get("tiles", [4, 4])
        self.topk = int(cfg.get("suggestion", {}).get("topk", 5))
        self.objective = cfg.get("suggestion", {}).get("objective", "auto").lower()

    def propose(self, scene, heatmaps, links):
        per_image = []
        r, c = self.tiles
        for cid, hm in heatmaps.items():
            H, W = hm.shape
            scores = []
            for i in range(r):
                for j in range(c):
                    y0, y1, x0, x1 = _tile_bounds(H, W, self.tiles, (i, j))
                    sub = hm[y0:y1, x0:x1]
                    score = float(sub.mean()) if sub.size else 0.0
                    scores.append(((i, j), score, [x0, y0, x1, y1]))
            # coverage mode wants low-score tiles, error/frame mode wants high-score tiles.
            is_coverage = any(ob.kind == "coverage" for ob in scene.tracks.get(cid, []))
            reverse = not is_coverage
            scores.sort(key=lambda x: x[1], reverse=reverse)
            cam = scene.cameras[cid]
            pose_hint = None
            if cam.R is not None and cam.t is not None:
                center = camera_center_from_rt(cam.R, cam.t)
                # move slightly around current view as a conservative reshoot hint
                pose_hint = {"camera_center": center.tolist(), "action": "reshoot_or_add_neighbor_view", "note": "Use this as a local hint; full NBV requires visibility optimization."}
            per_image.append({
                "image_id": cid,
                "source": cam.source,
                "objective": "low_coverage" if is_coverage else "high_attention_weighted_error",
                "top_tiles": [
                    {"tile_rc": [int(rc[0]), int(rc[1])], "bbox_xyxy": bbox, "score": score} for rc, score, bbox in scores[:self.topk]
                ],
                "pose_hint": pose_hint,
            })
        # Mesh-level suggestion from vertex scores.
        mesh_hint = None
        if scene.mesh is not None and scene.mesh.vertices is not None and scene.mesh.vertices.size:
            verts = scene.mesh.vertices
            center = verts.mean(axis=0)
            extent = verts.max(axis=0) - verts.min(axis=0)
            radius = float(np.linalg.norm(extent))
            mesh_hint = {
                "center": center.tolist(),
                "recommended_orbit_radius": max(radius * 1.5, 1.0),
                "directions": ["front", "back", "left", "right", "top_oblique"],
            }
        return {"version": "1.0", "per_image": per_image, "context_edges": links.get("edges", []), "mesh_hint": mesh_hint}
