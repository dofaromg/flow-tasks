# -*- coding: utf-8 -*-
from __future__ import annotations
import logging
from pathlib import Path
import yaml

from mrl3d.adapters.scene_loader import load_scene
from mrl3d.pipeline.attention import AttentionBackend
from mrl3d.pipeline.error_map import ErrorMapper
from mrl3d.pipeline.context_graph import ContextGraph
from mrl3d.pipeline.nbv import NBVGenerator
from mrl3d.pipeline.exporter import Exporter

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")


def run_pipeline(config_path: str):
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    out_dir = Path(cfg.get("out_dir", "./outputs"))
    out_dir.mkdir(parents=True, exist_ok=True)

    logging.info("Loading scene from adapter: %s", cfg.get("input", {}).get("type", "simulate"))
    scene = load_scene(cfg)
    logging.info("Scene loaded: cameras=%d points=%d", len(scene.cameras), len(scene.points))

    logging.info("Computing attention maps...")
    attn_maps = AttentionBackend(cfg).compute(scene.images)

    logging.info("Computing attention-weighted error / coverage maps...")
    heatmaps, metrics = ErrorMapper(cfg).make(scene, attn_maps)
    metrics["input_meta"] = scene.meta

    logging.info("Building context graph...")
    links = ContextGraph(cfg).build(scene, heatmaps)

    logging.info("Generating NBV / gap suggestions...")
    suggestions = NBVGenerator(cfg).propose(scene, heatmaps, links)

    logging.info("Exporting artifacts to %s", out_dir)
    Exporter(cfg).dump_all(scene, metrics, links, suggestions, heatmaps, attn_maps)
    return {"output_dir": str(out_dir), "metrics": metrics, "suggestions": suggestions, "links": links, "meta": scene.meta}
