# -*- coding: utf-8 -*-
from __future__ import annotations
import csv
import json
from pathlib import Path
import cv2
import numpy as np

from mrl3d.geometry.mesh_ops import color_map_values, mesh_quality
from mrl3d.geometry.ply import write_ply
from mrl3d.pipeline.visualize import heatmap_png


def _json_default(x):
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.float32, np.float64)):
        return float(x)
    if isinstance(x, (np.int32, np.int64)):
        return int(x)
    raise TypeError(type(x).__name__)


class Exporter:
    def __init__(self, cfg):
        self.cfg = cfg
        self.out_dir = Path(cfg.get("out_dir", "./outputs"))
        self.out_dir.mkdir(parents=True, exist_ok=True)

    def dump_all(self, scene, metrics, links, suggestions, heatmaps, attn_maps=None):
        (self.out_dir / "heatmaps").mkdir(exist_ok=True)
        (self.out_dir / "overlays").mkdir(exist_ok=True)
        with open(self.out_dir / "cameras.json", "w", encoding="utf-8") as f:
            json.dump(scene.json_cameras(), f, indent=2, ensure_ascii=False, default=_json_default)
        with open(self.out_dir / "metrics.json", "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2, ensure_ascii=False, default=_json_default)
        with open(self.out_dir / "links.json", "w", encoding="utf-8") as f:
            json.dump(links, f, indent=2, ensure_ascii=False, default=_json_default)
        with open(self.out_dir / "suggestions.json", "w", encoding="utf-8") as f:
            json.dump(suggestions, f, indent=2, ensure_ascii=False, default=_json_default)
        with open(self.out_dir / "scene_meta.json", "w", encoding="utf-8") as f:
            json.dump(scene.meta, f, indent=2, ensure_ascii=False, default=_json_default)

        with open(self.out_dir / "metrics_summary.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["camera", "kind_counts", "count", "p50", "p90", "p95", "max", "mean", "nonzero_fraction"])
            for cid, row in metrics.get("per_camera", {}).items():
                s = row.get("weighted", {})
                w.writerow([cid, json.dumps(row.get("kind_counts", {})), s.get("count", 0), s.get("p50", 0), s.get("p90", 0), s.get("p95", 0), s.get("max", 0), s.get("mean", 0), row.get("nonzero_fraction", 0)])

        for cid, hm in heatmaps.items():
            np.save(self.out_dir / "heatmaps" / f"heatmap_{cid}.npy", hm)
            img = scene.images.get(cid)
            png = heatmap_png(hm, img)
            cv2.imwrite(str(self.out_dir / "overlays" / f"heatmap_{cid}.png"), png)
            if attn_maps and cid in attn_maps:
                cv2.imwrite(str(self.out_dir / "overlays" / f"attention_{cid}.png"), heatmap_png(attn_maps[cid], img))

        # Geometry-domain output if mesh exists.
        if scene.mesh is not None and scene.mesh.vertices is not None and len(scene.mesh.vertices):
            q = mesh_quality(scene.mesh.vertices, scene.mesh.faces)
            with open(self.out_dir / "mesh_quality.json", "w", encoding="utf-8") as f:
                json.dump(q, f, indent=2, ensure_ascii=False)
            scores = metrics.get("vertex_scores")
            if scores is not None:
                scores_arr = np.asarray(scores, dtype=np.float64)
                colors = color_map_values(scores_arr)
                write_ply(str(self.out_dir / "mesh_vertex_heatmap.ply"), scene.mesh.vertices, scene.mesh.faces, colors)

        # Human-readable report
        self._write_report(scene, metrics, suggestions)

    def _write_report(self, scene, metrics, suggestions):
        lines = []
        lines.append("# MRL 3D AI Reconstruction Run Report")
        lines.append("")
        lines.append(f"Adapter: `{scene.meta.get('adapter')}`")
        lines.append(f"Cameras: {len(scene.cameras)}")
        lines.append(f"Points: {len(scene.points)}")
        lines.append(f"Global weighted metric p90: {metrics.get('global', {}).get('p90', 0):.6f}")
        lines.append("")
        lines.append("## Outputs")
        lines.append("- `metrics.json`, `metrics_summary.csv`")
        lines.append("- `suggestions.json`")
        lines.append("- `overlays/heatmap_*.png`, `heatmaps/heatmap_*.npy`")
        if scene.mesh is not None:
            lines.append("- `mesh_vertex_heatmap.ply`, `mesh_quality.json`")
        lines.append("")
        lines.append("## Top suggestion summary")
        for row in suggestions.get("per_image", [])[:10]:
            tiles = row.get("top_tiles", [])[:3]
            lines.append(f"- {row.get('image_id')}: {tiles}")
        (self.out_dir / "RUN_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
