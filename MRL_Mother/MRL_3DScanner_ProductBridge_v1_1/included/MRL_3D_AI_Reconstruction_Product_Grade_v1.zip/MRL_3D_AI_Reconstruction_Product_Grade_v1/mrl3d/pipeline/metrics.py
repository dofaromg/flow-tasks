# -*- coding: utf-8 -*-
from __future__ import annotations
import numpy as np


def summarize_values(values, bins=20):
    arr = np.asarray(values, dtype=np.float64)
    if arr.size == 0:
        return {"count": 0, "p50": 0.0, "p90": 0.0, "p95": 0.0, "max": 0.0, "mean": 0.0, "hist": [0]*bins, "edges": [0.0]*(bins+1)}
    hi = max(float(arr.max()), 1e-6)
    hist, edges = np.histogram(arr, bins=bins, range=(0.0, hi))
    return {
        "count": int(arr.size),
        "p50": float(np.percentile(arr, 50)),
        "p90": float(np.percentile(arr, 90)),
        "p95": float(np.percentile(arr, 95)),
        "max": float(arr.max()),
        "mean": float(arr.mean()),
        "hist": hist.tolist(),
        "edges": edges.tolist(),
    }
