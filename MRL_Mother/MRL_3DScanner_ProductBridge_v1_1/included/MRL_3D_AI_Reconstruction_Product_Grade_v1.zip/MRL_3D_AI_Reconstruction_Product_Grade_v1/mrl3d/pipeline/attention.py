# -*- coding: utf-8 -*-
from __future__ import annotations
import cv2
import numpy as np


def _normalize(a: np.ndarray) -> np.ndarray:
    a = a.astype(np.float32)
    return (a - a.min()) / (a.max() - a.min() + 1e-6)


class AttentionBackend:
    def __init__(self, cfg):
        self.cfg = cfg
        self.backend = cfg.get("attention", {}).get("backend", "simple").lower()
        self.center_weight = float(cfg.get("attention", {}).get("center_weight", 0.20))
        self.edge_weight = float(cfg.get("attention", {}).get("edge_weight", 0.55))
        self.texture_weight = float(cfg.get("attention", {}).get("texture_weight", 0.25))
        if self.backend == "vit":
            try:
                from mrl3d.pipeline.attention_vit import AttentionVitBackend
                self.vit = AttentionVitBackend(cfg)
            except Exception as e:
                print(f"[attention] ViT backend unavailable, fallback to simple: {e}")
                self.backend = "simple"

    def compute(self, images: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
        if self.backend == "vit":
            return self.vit.compute(images)
        out = {}
        for cid, img in images.items():
            if img is None or img.size == 0:
                out[cid] = np.ones((64, 64), dtype=np.float32)
                continue
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
            H, W = gray.shape[:2]
            yy, xx = np.mgrid[0:H, 0:W]
            cx, cy = W / 2.0, H / 2.0
            center = 1.0 - np.sqrt(((xx - cx) / max(W / 2, 1)) ** 2 + ((yy - cy) / max(H / 2, 1)) ** 2)
            center = np.clip(center, 0, 1)
            sx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
            sy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
            edge = _normalize(np.sqrt(sx * sx + sy * sy))
            mean = cv2.blur(gray.astype(np.float32), (9, 9))
            mean2 = cv2.blur((gray.astype(np.float32) ** 2), (9, 9))
            texture = _normalize(np.sqrt(np.maximum(0.0, mean2 - mean * mean)))
            attn = self.center_weight * center + self.edge_weight * edge + self.texture_weight * texture
            out[cid] = _normalize(attn).astype(np.float32)
        return out
