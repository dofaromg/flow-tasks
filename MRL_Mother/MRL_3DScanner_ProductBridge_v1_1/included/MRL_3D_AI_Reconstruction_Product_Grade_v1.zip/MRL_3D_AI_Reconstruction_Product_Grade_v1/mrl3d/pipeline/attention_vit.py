# -*- coding: utf-8 -*-
from __future__ import annotations
import numpy as np

class AttentionVitBackend:
    """Optional timm/torch backend. It is deliberately isolated so base install remains light."""
    def __init__(self, cfg):
        import torch
        import torch.nn.functional as F
        from timm import create_model
        self.torch = torch
        self.F = F
        self.model_name = cfg.get("attention", {}).get("vit_model", "vit_tiny_patch16_224")
        self.model = create_model(self.model_name, pretrained=True).eval()
        self.size = (224, 224)

    def _preprocess(self, img):
        import cv2
        torch = self.torch
        im = cv2.resize(img, self.size).astype(np.float32) / 255.0
        im = im[:, :, ::-1]
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        im = (im - mean) / std
        return torch.from_numpy(im.transpose(2, 0, 1)).unsqueeze(0)

    def compute(self, images):
        torch = self.torch; F = self.F
        out = {}
        with torch.no_grad():
            for cid, img in images.items():
                x = self._preprocess(img)
                feats = self.model.forward_features(x)
                if feats.ndim == 3:
                    B, N, C = feats.shape
                    # CLS similarity proxy.
                    cls = feats[:, 0:1, :]
                    toks = feats[:, 1:, :]
                    p = int(np.sqrt(toks.shape[1]))
                    toks = toks[:, :p*p, :].reshape(B, p, p, C)
                    sim = F.cosine_similarity(toks, cls[:, None, :, :], dim=-1).clamp(min=0)
                    attn = sim[0].cpu().numpy()
                elif feats.ndim == 4:
                    cls = feats.mean(dim=(2, 3), keepdim=True)
                    sim = F.cosine_similarity(feats, cls, dim=1).clamp(min=0)
                    attn = sim[0].cpu().numpy()
                else:
                    attn = np.ones((14, 14), dtype=np.float32)
                H, W = img.shape[:2]
                a = torch.from_numpy(attn)[None, None].float()
                a = F.interpolate(a, size=(H, W), mode="bilinear", align_corners=False)[0, 0].numpy()
                a = (a - a.min()) / (a.max() - a.min() + 1e-6)
                out[cid] = a.astype(np.float32)
        return out
