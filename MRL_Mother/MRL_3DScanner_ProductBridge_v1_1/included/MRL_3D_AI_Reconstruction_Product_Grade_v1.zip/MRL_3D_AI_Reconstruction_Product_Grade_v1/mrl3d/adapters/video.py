# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import cv2
import numpy as np

from mrl3d.core.types import Camera, Observation, Scene


def load_video_scene(cfg) -> Scene:
    input_cfg = cfg.get("input", {})
    video_path = Path(input_cfg.get("video_path", "./sample_data/video/sample.mp4"))
    sample_fps = float(input_cfg.get("sample_fps", 2.0))
    frame_dir = Path(input_cfg.get("frame_dir", "./data/video_frames"))
    frame_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    step = max(int(round(src_fps / max(sample_fps, 0.1))), 1)
    cameras = {}; tracks = {}; images = {}; points = {}
    idx = 0; saved = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % step == 0:
            cid = f"frame_{saved:04d}"
            H, W = frame.shape[:2]
            path = frame_dir / f"{cid}.jpg"
            cv2.imwrite(str(path), frame)
            cameras[cid] = Camera(cid, W, H, (W, W, W / 2.0, H / 2.0), image_name=path.name, source="video_frame")
            # frame quality diagnostic tracks: edges/blur-based score points on a grid
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            lap = cv2.Laplacian(gray, cv2.CV_32F)
            blur_score = float(np.var(lap))
            obs = []
            grid = 8
            pid_base = saved * grid * grid
            for gy in range(grid):
                for gx in range(grid):
                    y0 = int(gy * H / grid); y1 = int((gy + 1) * H / grid)
                    x0 = int(gx * W / grid); x1 = int((gx + 1) * W / grid)
                    sub = lap[y0:y1, x0:x1]
                    # low sharpness => higher risk
                    val = float(max(0.0, 1.0 - (np.var(sub) / (blur_score + 1e-6))))
                    u = (x0 + x1) / 2.0; v = (y0 + y1) / 2.0
                    pid = pid_base + gy * grid + gx
                    points[pid] = (float(gx), float(gy), float(saved))
                    obs.append(Observation(u, v, pid, val, "frame_quality"))
            tracks[cid] = obs
            images[cid] = frame
            saved += 1
        idx += 1
    cap.release()
    meta = {"adapter": "video", "video_path": str(video_path), "sample_fps": sample_fps, "num_frames": saved, "note": "Video adapter extracts frames and runs frame-quality diagnostics. For true SfM reprojection error, run COLMAP on extracted frames."}
    return Scene(cameras, points, tracks, images, meta)
