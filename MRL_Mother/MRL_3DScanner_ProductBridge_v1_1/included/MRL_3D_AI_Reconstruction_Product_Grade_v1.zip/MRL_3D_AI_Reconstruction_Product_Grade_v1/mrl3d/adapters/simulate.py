# -*- coding: utf-8 -*-
from __future__ import annotations
import math
from pathlib import Path
import cv2
import numpy as np

from mrl3d.core.types import Camera, Observation, Scene, Mesh
from mrl3d.geometry.camera import look_at_rotation, project_point


def _make_cube_points() -> dict[int, tuple[float, float, float]]:
    pts = {}
    idx = 0
    for x in np.linspace(-0.5, 0.5, 5):
        for y in np.linspace(-0.5, 0.5, 5):
            for z in np.linspace(-0.5, 0.5, 5):
                if abs(x) == 0.5 or abs(y) == 0.5 or abs(z) == 0.5:
                    pts[idx] = (float(x), float(y), float(z))
                    idx += 1
    return pts


def _draw_image(width, height, obs, rng):
    img = np.zeros((height, width, 3), dtype=np.uint8)
    img[:] = (16, 16, 18)
    for u, v, pid, err in obs:
        color = (120 + (pid * 17) % 120, 80 + (pid * 31) % 150, 180)
        cv2.circle(img, (int(round(u)), int(round(v))), 3, color, -1)
    # synthetic geometric cues for attention
    cv2.rectangle(img, (10, 10), (width - 10, height - 10), (40, 70, 120), 1)
    cv2.putText(img, "MRL sample", (20, height - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (140, 140, 140), 1)
    noise = rng.normal(0, 2, img.shape).astype(np.int16)
    return np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)


def load_simulated_scene(cfg) -> Scene:
    input_cfg = cfg.get("input", {})
    width, height = input_cfg.get("resolution", [640, 480])
    num_cams = int(input_cfg.get("num_cameras", 6))
    radius = float(input_cfg.get("radius", 2.5))
    noise_px = float(input_cfg.get("noise_px", 1.0))
    seed = int(input_cfg.get("seed", 7))
    rng = np.random.default_rng(seed)

    points = _make_cube_points()
    fx = fy = (width / 2) / math.tan(math.radians(55) / 2)
    K = (float(fx), float(fy), width / 2.0, height / 2.0)
    cameras = {}
    tracks = {}
    images = {}
    target = np.array([0.0, 0.0, 0.0])

    for i, theta in enumerate(np.linspace(0, 2 * math.pi, num_cams, endpoint=False)):
        cam_pos = np.array([radius * math.cos(theta), 0.45 + 0.2 * math.sin(2 * theta), radius * math.sin(theta)])
        R = look_at_rotation(cam_pos, target)
        t = -R @ cam_pos
        cid = f"sim_{i:03d}"
        cam = Camera(cid, width, height, K, R=R, t=t, image_name=f"{cid}.png", source="simulate")
        cameras[cid] = cam
        obs = []
        obs_for_img = []
        for pid, xyz in points.items():
            uvz = project_point(xyz, R, t, K)
            if uvz is None:
                continue
            u, v, z = uvz
            if 0 <= u < width and 0 <= v < height:
                u_obs = u + rng.normal(0, noise_px)
                v_obs = v + rng.normal(0, noise_px)
                err = float(math.hypot(u_obs - u, v_obs - v))
                obs.append(Observation(u_obs, v_obs, pid, err, "reprojection_error", predicted_u=u, predicted_v=v))
                obs_for_img.append((u_obs, v_obs, pid, err))
        tracks[cid] = obs
        images[cid] = _draw_image(width, height, obs_for_img, rng)

    verts = np.array(list(points.values()), dtype=np.float64)
    scene = Scene(cameras, points, tracks, images, {"adapter": "simulate", "seed": seed, "num_points": len(points)}, Mesh(verts))
    return scene
