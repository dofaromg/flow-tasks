# -*- coding: utf-8 -*-
from __future__ import annotations
from mrl3d.adapters.simulate import load_simulated_scene
from mrl3d.adapters.colmap_text import load_colmap_scene
from mrl3d.adapters.video import load_video_scene
from mrl3d.adapters.mesh import load_mesh_scene


def load_scene(cfg):
    typ = cfg.get("input", {}).get("type", "simulate").lower()
    if typ == "simulate":
        return load_simulated_scene(cfg)
    if typ in ("colmap", "colmap_text"):
        return load_colmap_scene(cfg)
    if typ in ("video", "mp4"):
        return load_video_scene(cfg)
    if typ in ("mesh", "mesh_obj", "mesh_ply", "obj", "ply"):
        return load_mesh_scene(cfg)
    raise ValueError(f"Unknown input.type: {typ}")
