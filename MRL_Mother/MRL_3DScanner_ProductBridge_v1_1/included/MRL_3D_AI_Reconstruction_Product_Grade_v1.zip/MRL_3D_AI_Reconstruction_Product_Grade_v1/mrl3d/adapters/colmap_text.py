# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import math
import cv2
import numpy as np

from mrl3d.core.types import Camera, Observation, Scene
from mrl3d.geometry.camera import quat_to_rot, project_point


def parse_cameras_txt(path: Path):
    cams = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            toks = line.split()
            camera_id = int(toks[0])
            model = toks[1].upper()
            width = int(toks[2]); height = int(toks[3])
            params = list(map(float, toks[4:]))
            if model == "PINHOLE":
                fx, fy, cx, cy = params[:4]
            elif model in ("SIMPLE_PINHOLE", "SIMPLE_RADIAL"):
                f, cx, cy = params[:3]
                fx = fy = f
            elif len(params) >= 4:
                fx, fy, cx, cy = params[:4]
            elif len(params) >= 3:
                f, cx, cy = params[:3]
                fx = fy = f
            else:
                fx = fy = max(width, height)
                cx = width / 2; cy = height / 2
            cams[camera_id] = {"model": model, "width": width, "height": height, "params": params, "K": (fx, fy, cx, cy)}
    return cams


def parse_points3d_txt(path: Path):
    pts = {}
    colors = {}
    errors = {}
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            toks = line.split()
            pid = int(toks[0])
            pts[pid] = tuple(map(float, toks[1:4]))
            if len(toks) >= 7:
                colors[pid] = tuple(map(int, toks[4:7]))
            if len(toks) >= 8:
                try:
                    errors[pid] = float(toks[7])
                except Exception:
                    pass
    return pts, colors, errors


def load_colmap_scene(cfg) -> Scene:
    input_cfg = cfg.get("input", {})
    colmap_dir = Path(input_cfg.get("colmap_dir", "./sample_data/colmap_text"))
    images_dir = Path(input_cfg.get("images_dir", cfg.get("images_dir", "./sample_data/images")))
    read_images = bool(input_cfg.get("read_images", True))

    camera_path = colmap_dir / "cameras.txt"
    image_path = colmap_dir / "images.txt"
    point_path = colmap_dir / "points3D.txt"
    missing = [str(p) for p in (camera_path, image_path, point_path) if not p.exists()]
    if missing:
        raise FileNotFoundError(f"COLMAP text model missing files: {missing}")

    cam_defs = parse_cameras_txt(camera_path)
    points, point_colors, point_errors = parse_points3d_txt(point_path)
    cameras = {}
    tracks = {}
    images = {}
    pose_meta = {}

    with open(image_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]

    i = 0
    while i < len(lines):
        head = lines[i].split(); i += 1
        if len(head) < 10:
            continue
        image_id = int(head[0])
        qw, qx, qy, qz = map(float, head[1:5])
        tx, ty, tz = map(float, head[5:8])
        camera_id = int(head[8])
        name = head[9]
        cam_def = cam_defs[camera_id]
        R = quat_to_rot(qw, qx, qy, qz)
        t = np.array([tx, ty, tz], dtype=np.float64)
        cid = str(image_id)
        cameras[cid] = Camera(cid, cam_def["width"], cam_def["height"], cam_def["K"], R=R, t=t, image_name=name, source="colmap")
        pose_meta[cid] = {"camera_id": camera_id, "qvec": [qw, qx, qy, qz], "tvec": [tx, ty, tz]}

        obs_line = lines[i].split() if i < len(lines) else []
        i += 1
        obs = []
        for k in range(0, len(obs_line), 3):
            try:
                u_obs = float(obs_line[k]); v_obs = float(obs_line[k + 1]); pid = int(obs_line[k + 2])
            except (ValueError, IndexError):
                continue
            if pid == -1 or pid not in points:
                continue
            uvz = project_point(points[pid], R, t, cam_def["K"], cam_def["model"], cam_def["params"])
            if uvz is None:
                continue
            u_hat, v_hat, _ = uvz
            err = float(math.hypot(u_hat - u_obs, v_hat - v_obs))
            obs.append(Observation(u_obs, v_obs, pid, err, "reprojection_error", predicted_u=u_hat, predicted_v=v_hat))
        tracks[cid] = obs

        img = None
        if read_images:
            fp = images_dir / name
            if fp.exists():
                img = cv2.imread(str(fp), cv2.IMREAD_COLOR)
        if img is None:
            img = np.zeros((cam_def["height"], cam_def["width"], 3), dtype=np.uint8)
        images[cid] = img

    meta = {"adapter": "colmap", "colmap_dir": str(colmap_dir), "num_points": len(points), "num_images": len(cameras), "poses": pose_meta}
    return Scene(cameras, points, tracks, images, meta)
