# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import math
import cv2
import numpy as np

from mrl3d.core.types import Camera, Observation, Scene, Mesh
from mrl3d.geometry.camera import look_at_rotation, project_point
from mrl3d.geometry.mesh_ops import compute_vertex_normals
from mrl3d.geometry.ply import read_ply_vertices_faces


def _read_obj(path: Path):
    vertices = []
    faces = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith("v "):
                toks = line.split()
                vertices.append([float(toks[1]), float(toks[2]), float(toks[3])])
            elif line.startswith("f "):
                toks = line.split()[1:]
                ids = []
                for t in toks:
                    ids.append(int(t.split("/")[0]) - 1)
                if len(ids) >= 3:
                    for k in range(1, len(ids) - 1):
                        faces.append([ids[0], ids[k], ids[k + 1]])
    if not vertices:
        raise RuntimeError(f"OBJ has no vertices: {path}")
    return np.asarray(vertices, dtype=np.float64), np.asarray(faces, dtype=np.int32)


def load_mesh_scene(cfg) -> Scene:
    input_cfg = cfg.get("input", {})
    mesh_path = Path(input_cfg.get("mesh_path", "./sample_data/mesh/cube.obj"))
    synth = input_cfg.get("synth", {})
    num_cams = int(synth.get("num_cameras", 8))
    radius_scale = float(synth.get("radius_scale", 2.2))
    width, height = synth.get("resolution", [640, 480])
    fov_deg = float(synth.get("fov_deg", 60.0))

    if mesh_path.suffix.lower() == ".ply":
        vertices, faces = read_ply_vertices_faces(str(mesh_path))
    else:
        vertices, faces = _read_obj(mesh_path)
    normals = compute_vertex_normals(vertices, faces) if faces.size else np.zeros_like(vertices)
    mesh = Mesh(vertices, faces, normals, str(mesh_path))

    center = vertices.mean(axis=0)
    extent = vertices.max(axis=0) - vertices.min(axis=0)
    radius = max(float(np.linalg.norm(extent) * 0.5 * radius_scale), 1e-3)
    fx = fy = (width / 2) / math.tan(math.radians(fov_deg) / 2)
    K = (float(fx), float(fy), width / 2.0, height / 2.0)

    cameras = {}; tracks = {}; images = {}
    points = {int(i): tuple(map(float, v)) for i, v in enumerate(vertices)}
    coverage_count = np.zeros(len(vertices), dtype=np.float64)

    for i, theta in enumerate(np.linspace(0, 2 * math.pi, num_cams, endpoint=False)):
        cam_pos = center + np.array([radius * math.cos(theta), 0.35 * radius, radius * math.sin(theta)])
        R = look_at_rotation(cam_pos, center)
        t = -R @ cam_pos
        cid = f"mesh_{i:03d}"
        cameras[cid] = Camera(cid, width, height, K, R=R, t=t, image_name=f"{cid}.png", source="mesh_synthetic")
        img = np.zeros((height, width, 3), dtype=np.uint8); img[:] = (18, 18, 18)
        obs = []
        for pid, xyz in points.items():
            uvz = project_point(xyz, R, t, K)
            if uvz is None:
                continue
            u, v, z = uvz
            if 0 <= u < width and 0 <= v < height:
                # if normals available, prefer points facing camera
                if normals.size:
                    view = cam_pos - np.asarray(xyz)
                    view = view / (np.linalg.norm(view) + 1e-12)
                    facing = float(max(0.0, np.dot(normals[pid], view)))
                else:
                    facing = 1.0
                val = max(0.05, facing)
                coverage_count[pid] += val
                obs.append(Observation(u, v, pid, val, "coverage"))
                cv2.circle(img, (int(round(u)), int(round(v))), 2, (50, 120, 220), -1)
        tracks[cid] = obs
        images[cid] = img

    meta = {"adapter": "mesh", "mesh_path": str(mesh_path), "num_vertices": int(len(vertices)), "num_faces": int(len(faces)), "coverage_count_min": float(coverage_count.min()) if len(coverage_count) else 0.0, "coverage_count_max": float(coverage_count.max()) if len(coverage_count) else 0.0}
    return Scene(cameras, points, tracks, images, meta, mesh=mesh)
