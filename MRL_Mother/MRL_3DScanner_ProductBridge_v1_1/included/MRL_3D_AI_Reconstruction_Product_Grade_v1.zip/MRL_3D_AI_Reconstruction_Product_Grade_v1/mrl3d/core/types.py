# -*- coding: utf-8 -*-
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Tuple, Optional
import numpy as np

@dataclass
class Camera:
    id: str
    width: int
    height: int
    K: Tuple[float, float, float, float]
    R: Optional[np.ndarray] = None
    t: Optional[np.ndarray] = None
    image_name: Optional[str] = None
    source: str = "unknown"

    def as_json(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "width": self.width,
            "height": self.height,
            "K": list(map(float, self.K)),
            "R": self.R.tolist() if self.R is not None else None,
            "t": self.t.tolist() if self.t is not None else None,
            "image_name": self.image_name,
            "source": self.source,
        }

@dataclass
class Observation:
    u: float
    v: float
    point_id: int
    value: float
    kind: str = "reprojection_error"  # reprojection_error | coverage | frame_quality
    predicted_u: Optional[float] = None
    predicted_v: Optional[float] = None

    def as_tuple(self):
        return (self.u, self.v, self.point_id, self.value, self.kind)

@dataclass
class Mesh:
    vertices: np.ndarray
    faces: np.ndarray = field(default_factory=lambda: np.zeros((0, 3), dtype=np.int32))
    vertex_normals: Optional[np.ndarray] = None
    source_path: Optional[str] = None

@dataclass
class Scene:
    cameras: Dict[str, Camera]
    points: Dict[int, Tuple[float, float, float]]
    tracks: Dict[str, List[Observation]]
    images: Dict[str, np.ndarray]
    meta: Dict[str, Any]
    mesh: Optional[Mesh] = None

    def json_cameras(self) -> Dict[str, Any]:
        return {k: cam.as_json() for k, cam in self.cameras.items()}
