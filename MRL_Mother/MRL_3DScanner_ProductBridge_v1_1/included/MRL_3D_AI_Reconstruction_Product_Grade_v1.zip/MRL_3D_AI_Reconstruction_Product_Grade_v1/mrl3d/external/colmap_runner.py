# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import shutil
import subprocess


def command_exists(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def run_colmap_from_images(images_dir: str, work_dir: str, use_gpu: bool = True) -> dict:
    if not command_exists("colmap"):
        raise RuntimeError("COLMAP executable not found. Install COLMAP or use input.type=colmap with existing text model.")
    images = Path(images_dir)
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    db = work / "colmap.db"
    sparse = work / "sparse"
    text = work / "text"
    sparse.mkdir(exist_ok=True)
    text.mkdir(exist_ok=True)
    gpu = "1" if use_gpu else "0"
    cmds = [
        ["colmap", "feature_extractor", "--database_path", str(db), "--image_path", str(images), "--SiftExtraction.use_gpu", gpu],
        ["colmap", "exhaustive_matcher", "--database_path", str(db), "--SiftMatching.use_gpu", gpu],
        ["colmap", "mapper", "--database_path", str(db), "--image_path", str(images), "--output_path", str(sparse)],
        ["colmap", "model_converter", "--input_path", str(sparse / "0"), "--output_path", str(text), "--output_type", "TXT"],
    ]
    logs = []
    for cmd in cmds:
        proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        logs.append({"cmd": cmd, "returncode": proc.returncode, "output": proc.stdout[-4000:]})
        if proc.returncode != 0:
            return {"ok": False, "text_model_dir": str(text), "logs": logs}
    return {"ok": True, "text_model_dir": str(text), "logs": logs}
