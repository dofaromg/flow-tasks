# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import shutil
import subprocess


def _which_any(names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None


def run_openmvs(work_dir: str, scene_mvs: str | None = None) -> dict:
    """Run a minimal OpenMVS chain when tools are available. This wrapper is optional."""
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    densify = _which_any(["DensifyPointCloud"])
    reconstruct = _which_any(["ReconstructMesh"])
    texture = _which_any(["TextureMesh"])
    if not (densify and reconstruct):
        raise RuntimeError("OpenMVS tools not found. Install OpenMVS or provide mesh OBJ/PLY directly.")
    if scene_mvs is None:
        raise ValueError("scene_mvs is required for OpenMVS wrapper")
    scene = Path(scene_mvs)
    dense = work / "scene_dense.mvs"
    mesh = work / "scene_mesh.mvs"
    logs = []
    cmds = [[densify, str(scene), "--working-folder", str(work), "--output-file", str(dense)], [reconstruct, str(dense), "--working-folder", str(work), "--output-file", str(mesh)]]
    if texture:
        cmds.append([texture, str(mesh), "--working-folder", str(work), "--export-type", "obj"])
    for cmd in cmds:
        proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        logs.append({"cmd": cmd, "returncode": proc.returncode, "output": proc.stdout[-4000:]})
        if proc.returncode != 0:
            return {"ok": False, "logs": logs}
    return {"ok": True, "logs": logs, "mesh_mvs": str(mesh)}
