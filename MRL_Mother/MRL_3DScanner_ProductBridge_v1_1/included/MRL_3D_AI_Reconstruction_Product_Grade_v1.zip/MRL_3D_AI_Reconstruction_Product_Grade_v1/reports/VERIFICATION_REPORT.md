# Verification Report

Executed in the delivery environment.

## Commands executed

```bash
pip install -e .
bash scripts/run_all_demos.sh
pytest -q
```

## Demo runs verified

- simulate adapter: produced metrics, heatmaps, suggestions
- COLMAP text adapter: loaded sample `cameras.txt`, `images.txt`, `points3D.txt`; produced reprojection diagnostics
- video adapter: extracted MP4 frames and produced frame-quality diagnostics
- OBJ mesh adapter: produced synthetic coverage heatmaps and `mesh_vertex_heatmap.ply`
- ASCII PLY mesh adapter: produced synthetic coverage heatmaps and `mesh_vertex_heatmap.ply`

## Test result

```text
4 passed
```

## Output locations

- `verified_outputs/simulate/`
- `verified_outputs/colmap_text/`
- `verified_outputs/video/`
- `verified_outputs/mesh_obj/`
- `verified_outputs/mesh_ply/`

## Installable source zip check

Also checked:

```bash
pip install /mnt/data/mrl3d_ai_reconstruction-1.0.0-src.zip --target /mnt/data/_piptest
PYTHONPATH=/mnt/data/_piptest python -c "import mrl3d; print(mrl3d.__version__)"
```

Result: imported `mrl3d` version `1.0.0`.
