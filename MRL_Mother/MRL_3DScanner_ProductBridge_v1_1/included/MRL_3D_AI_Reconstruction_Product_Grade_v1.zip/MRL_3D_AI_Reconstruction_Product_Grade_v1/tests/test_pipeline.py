# -*- coding: utf-8 -*-
from pathlib import Path
from mrl3d.pipeline.runner import run_pipeline


def _run(root, cfg):
    result = run_pipeline(str(root / cfg))
    out = Path(result["output_dir"])
    assert out.exists()
    assert (out / "metrics.json").exists()
    assert (out / "suggestions.json").exists()
    assert (out / "RUN_REPORT.md").exists()
    return out, result


def test_simulate_pipeline():
    root = Path(__file__).resolve().parents[1]
    out, result = _run(root, "config/simulate.yaml")
    assert result["metrics"]["global"]["count"] > 0
    assert len(list((out / "overlays").glob("heatmap_*.png"))) > 0


def test_colmap_text_pipeline():
    root = Path(__file__).resolve().parents[1]
    out, result = _run(root, "config/colmap_text.yaml")
    assert result["meta"]["adapter"] == "colmap"
    assert result["metrics"]["global"]["count"] > 0


def test_mesh_obj_pipeline():
    root = Path(__file__).resolve().parents[1]
    out, result = _run(root, "config/mesh_obj.yaml")
    assert result["meta"]["adapter"] == "mesh"
    assert (out / "mesh_vertex_heatmap.ply").exists()


def test_video_pipeline():
    root = Path(__file__).resolve().parents[1]
    out, result = _run(root, "config/video.yaml")
    assert result["meta"]["adapter"] == "video"
    assert result["meta"]["num_frames"] > 0
