# READ FIRST

This is the product-grade delivery package for the MRL 3D AI Reconstruction branch.

Start here:

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e .
mrl3d run --config config/simulate.yaml
```

Then run all demos:

```bash
bash scripts/run_all_demos.sh
pytest -q
```

The package includes real adapters and sample data. It does not claim real-world Polycam-level reconstruction until a real user scene is supplied and verified.
