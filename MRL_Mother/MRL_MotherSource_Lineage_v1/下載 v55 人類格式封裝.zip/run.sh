#!/bin/bash
python3 flow_cli.py
# Version: V55