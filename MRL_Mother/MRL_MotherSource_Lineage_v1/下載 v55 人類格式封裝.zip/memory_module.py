# Memory node logic
# Version: V55