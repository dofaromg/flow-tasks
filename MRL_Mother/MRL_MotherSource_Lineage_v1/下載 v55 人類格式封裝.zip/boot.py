# Unified boot logic
# Version: V55