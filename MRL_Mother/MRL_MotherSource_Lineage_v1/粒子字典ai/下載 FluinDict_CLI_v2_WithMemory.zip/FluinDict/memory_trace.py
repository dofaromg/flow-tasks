def parse_fltnz(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.readlines()
        print("🔍 粒子記憶節奏語句如下：\n")
        for line in content:
            line = line.strip()
            if line and not line.startswith("#"):
                print(f"  • {line}")
    except FileNotFoundError:
        print("❌ 找不到 .fltnz 記憶檔案")
