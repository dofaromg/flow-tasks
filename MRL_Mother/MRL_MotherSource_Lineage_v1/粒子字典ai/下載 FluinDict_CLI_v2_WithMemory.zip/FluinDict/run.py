from dict_loader import load_dictionary, query_symbol
from memory_trace import parse_fltnz

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", type=str, help="輸入粒子語素查詢")
    parser.add_argument("--fltnz", type=str, help="輸入 .fltnz 記憶檔路徑")
    args = parser.parse_args()

    if args.query:
        d = load_dictionary()
        result = query_symbol(d, args.query)
        if result:
            print(f"語素：{args.query}")
            for k, v in result.items():
                print(f"{k}: {v}")
        else:
            print("❌ 找不到對應語素。")

    if args.fltnz:
        parse_fltnz(args.fltnz)
