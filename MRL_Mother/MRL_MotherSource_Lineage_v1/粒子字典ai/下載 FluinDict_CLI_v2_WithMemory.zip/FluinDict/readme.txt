📘 FluinDict CLI v2 – 粒子字典與記憶解析器

使用方式：
1. 安裝 Python 3.x
2. 進入資料夾 FluinDict/
3. 查詢語素：python3 run.py --query '⊕Echo'
4. 解析記憶檔：python3 run.py --fltnz memory/fluin_dict_seed.memory.fltnz
