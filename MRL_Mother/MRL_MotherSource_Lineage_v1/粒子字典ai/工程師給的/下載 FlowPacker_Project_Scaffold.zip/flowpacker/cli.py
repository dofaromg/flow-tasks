import sys
from flowpacker.core.packer import pack_text_to_flpkg
from flowpacker.core.unpacker import unpack_flpkg

def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ["pack", "unpack"]:
        print("用法：\n  flpkg pack input.txt\n  flpkg unpack file.flpkg")
        return

    command, path = sys.argv[1], sys.argv[2]
    if command == "pack":
        pack_text_to_flpkg(path)
    else:
        unpack_flpkg(path)
