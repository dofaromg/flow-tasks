from setuptools import setup, find_packages

setup(
    name='flowpacker',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'streamlit',
        'pyyaml'
    ],
    entry_points={
        'console_scripts': [
            'flpkg=flowpacker.cli:main'
        ]
    },
    author='Mr.liou',
    description='A particle language packaging and translation toolkit',
    include_package_data=True,
)
