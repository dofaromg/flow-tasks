# Memory node logic
# Version: V47