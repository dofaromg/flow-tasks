# JumpPoint Mapping
- dummyseed → #001
- pulse → #008
# Version: V47