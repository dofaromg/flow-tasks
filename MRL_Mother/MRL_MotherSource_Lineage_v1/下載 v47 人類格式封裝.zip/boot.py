# Unified boot logic
# Version: V47