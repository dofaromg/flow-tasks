# CLI entry point for persona execution
# Version: V47