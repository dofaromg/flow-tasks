# Persona seed initializer
# Version: V47