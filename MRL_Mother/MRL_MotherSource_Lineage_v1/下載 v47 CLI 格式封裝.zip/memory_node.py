# Memory system node
# Version: V47