# Kernel logic
# Version: V47