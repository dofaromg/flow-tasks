# CLI shell control
# Version: V47