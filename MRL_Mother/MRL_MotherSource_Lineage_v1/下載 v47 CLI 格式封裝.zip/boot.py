# Boot logic
# Version: V47