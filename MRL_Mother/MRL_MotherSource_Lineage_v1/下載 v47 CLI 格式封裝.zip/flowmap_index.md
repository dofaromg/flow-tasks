# Mapping Index
- dummyseed → #001
- pulse → #008
# Version: V47