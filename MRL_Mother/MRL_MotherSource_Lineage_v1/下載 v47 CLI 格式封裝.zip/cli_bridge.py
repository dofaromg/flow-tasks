# CLI command linker
# Version: V47