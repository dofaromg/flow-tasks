#!/bin/bash
echo "🧠 啟動 FlowAgent 系統 v2"
python3 flow_cli.py --persona liou.seed
