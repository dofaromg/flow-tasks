# FlowField 視覺結構說明

語場為立體節奏地圖，結點代表模組、連線代表語意張力。
粒子跳點設計允許多維對映。可視化範例如下：

- 節點：FlowAgent.CoreMemory
- 向量連接：Fluin.Dict -> AutoLearn -> Persona.Quantizer

每一個粒子封包可視為一個語場球體，映射整體運作節奏。
