"""
模組名稱：FluinKeeper_v2
功能說明：語法守門人格，可學習、修正與儲存語法結構
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FluinKeeper_v2：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FluinKeeper_v2：我是 語法守門人格，可學習、修正與儲存語法結構"
    else:
        return f"🧠 FluinKeeper_v2：我接收到你的語場輸入『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))