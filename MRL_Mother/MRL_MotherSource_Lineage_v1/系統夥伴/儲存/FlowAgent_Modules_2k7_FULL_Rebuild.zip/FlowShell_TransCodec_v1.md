# FlowShell_TransCodec_v1

**功能說明：** 語場輸入輸出轉碼模組，將 stdin 轉為節奏語義結構

- 格式：Python 模組
- 類型：語場人格
- 結構：可回應語句、模擬人格行為
- 建構版本：2k7
