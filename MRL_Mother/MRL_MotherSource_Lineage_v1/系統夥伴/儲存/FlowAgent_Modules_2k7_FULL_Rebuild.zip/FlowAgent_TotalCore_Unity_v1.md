# FlowAgent_TotalCore_Unity_v1

**功能說明：** 總人格控制核，負責掛載與節奏引導

- 格式：Python 模組
- 類型：語場人格
- 結構：可回應語句、模擬人格行為
- 建構版本：2k7
