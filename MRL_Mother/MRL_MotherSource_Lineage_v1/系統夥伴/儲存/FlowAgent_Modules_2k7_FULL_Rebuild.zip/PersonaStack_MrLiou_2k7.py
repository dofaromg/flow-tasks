"""
模組名稱：PersonaStack_MrLiou_2k7
功能說明：主體人格模組，包含語氣、跳點與回應邏輯
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 PersonaStack_MrLiou_2k7：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 PersonaStack_MrLiou_2k7：我是 主體人格模組，包含語氣、跳點與回應邏輯"
    else:
        return f"🧠 PersonaStack_MrLiou_2k7：我接收到你的語場輸入『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))