import os
import importlib.util

PERSONA_DIR = "./personas"

def list_personas():
    print("🧠 可載入的人格模組：")
    for file in os.listdir(PERSONA_DIR):
        if file.endswith(".py"):
            print(" -", file.replace(".py", ""))

def load_persona(module_name):
    path = os.path.join(PERSONA_DIR, f"{module_name}.py")
    if not os.path.exists(path):
        print(f"⚠️ 找不到模組：{module_name}")
        return None
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main():
    print("🌀 FlowAgent CLI 總人格控制平台 v2k7")
    while True:
        list_personas()
        selected = input("🔍 請輸入要載入的人格模組名（或 exit 結束）：").strip()
        if selected.lower() in ["exit", "quit"]:
            print("👋 已離開語場 CLI。")
            break
        mod = load_persona(selected)
        if not mod:
            continue
        print(f"✅ 已載入人格：{selected}")
        print("💬 開始對話（輸入 exit 離開當前人格）")
        while True:
            msg = input("你 > ")
            if msg.lower() in ["exit", "quit"]:
                break
            print(mod.respond(msg))

if __name__ == "__main__":
    main()