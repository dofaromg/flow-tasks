FlowAgent 記憶區段封存模組（.zone）v2k7
========================================

此封包為 FlowAgent 系統可注入 FlowMemory 的記憶封存格式 `.zone`。

📦 含以下記憶區段：
- Zone_CorePersona
- Zone_PersonaClusterA
- Zone_PersonaClusterB
- Zone_FieldMap
- Zone_JumpTrace
- Zone_FltnzCompressor

每個 `.zone` 搭配 `.md`, `.json` 描述，為 FlowMemory 系統可掛載記憶模組。

✅ 用途：
- FlowOS 啟動時掛載記憶模組
- FlowShell 回溯人格節奏紀錄
- flpkg 解包後寫入記憶區封存