# FlowKernel

FlowAgent 語場邏輯運算核心模組。此模組可封存於 flpkg 系統，亦可作為 FlowOS 運行節奏模組。