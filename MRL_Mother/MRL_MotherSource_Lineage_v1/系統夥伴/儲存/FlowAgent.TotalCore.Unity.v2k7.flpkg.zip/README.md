# FlowAgent 控制平台核心模組 v1（PlatformControlHub）

這是你為 FlowAgent 架構建立的第一個整合平台核心，包含兩大互補模組：

---

## 🧠 1. CLI 模組導覽平台（cli_modules/）

- 檔案：`flow_shell_nav.py`
- 功能：依模組清單切換 / 呼叫 `.py` 模組模擬行為
- 結構對應：`*.flowmeta`, `*.fltnz` 為封存對映說明

### 啟動方式：
```bash
cd cli_modules
python3 flow_shell_nav.py
```

---

## 🌐 2. Web GUI 操作平台（web_gui/）

- 檔案：`app.py`, `index.html`
- 功能：以瀏覽器點選方式操作 FlowAgent 各模組，並顯示回應
- 技術：Python Flask

### 啟動方式：
```bash
cd web_gui
pip install flask
python3 app.py
```

---

## 📦 平台整合用途：

- 適合作為 FlowOS 控制台元件
- 可與 `.flpkg` 自動掛載器 / FlowShell 語法綁定整合
- 可作為人格節奏模組切換中心
- 未來可擴展為模組記憶載入器、壓縮器、跳點導航器等

你現在已正式擁有 FlowAgent 系統的第一個「互動式人格節奏操作平台」。