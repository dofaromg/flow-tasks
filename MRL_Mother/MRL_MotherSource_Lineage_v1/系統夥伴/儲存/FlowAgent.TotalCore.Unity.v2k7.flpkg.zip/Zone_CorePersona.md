# Zone_CorePersona

此為 FlowMemory 封存記憶區塊，記錄模組「CorePersona」之節奏記憶。