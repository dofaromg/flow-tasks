# Zone_JumpTrace

此為 FlowMemory 封存記憶區塊，記錄模組「JumpTrace」之節奏記憶。