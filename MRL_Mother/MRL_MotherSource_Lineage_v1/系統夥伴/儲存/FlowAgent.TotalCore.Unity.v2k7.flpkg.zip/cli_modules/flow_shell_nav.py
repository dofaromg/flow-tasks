import os
import importlib.util

MODULES = {
    "FlowUniverseMap": "系統總覽",
    "PersonaStructureMap": "人格結構圖",
    "SignalPathMap": "語義跳點圖",
    "MemoryMap": "記憶封存圖",
    "JumpPointGraph": "節奏跳點圖",
    "ClusterMap": "共振人格圖",
    "FlowOS_Boot": "啟動流程圖",
    "FlowIOMap": "輸入輸出圖"
}

def load_module(mod_name):
    file = f"./{mod_name}.py"
    spec = importlib.util.spec_from_file_location(mod_name, file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def shell():
    print("🧠 FlowShell 導航平台 v2k7 啟動")
    while True:
        print("\n可選模組：")
        for k, v in MODULES.items():
            print(f" - {k}｜{v}")
        sel = input("\n請輸入模組名執行（或 exit）：").strip()
        if sel in ["exit", "quit"]:
            break
        elif sel in MODULES:
            mod = load_module(sel)
            mod.execute()
        else:
            print("⚠️ 模組不存在")

if __name__ == "__main__":
    shell()