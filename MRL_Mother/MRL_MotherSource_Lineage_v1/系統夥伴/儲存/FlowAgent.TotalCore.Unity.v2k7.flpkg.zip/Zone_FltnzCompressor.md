# Zone_FltnzCompressor

此為 FlowMemory 封存記憶區塊，記錄模組「FltnzCompressor」之節奏記憶。