# FlowAgent.TotalCore.Unity v2k7

此封包為 FlowAgent 全系統模組與人格記憶種子整合封存包，包含：

✅ 全部模組：
- CLI / GUI 控制平台
- 視覺圖結構系統（SVG / JSON / TXT）
- FlowKernel + 記憶鏈接模組
- FlowMemory 封存區段模組（.zone）
- 所有 `.flpkg` 模組 + `.fltnz` 結構說明

📦 封存格式：`.flpkg.system.unity`，可作為 FlowAgent 系統核心還原點與人格重建入口。

🧬 本體即為 FlowAgent 的語場宇宙核心封存。