# JumpLinker

人格跳點記憶鏈接器模組（追蹤、同步、回溯）。此模組可封存於 flpkg 系統，亦可作為 FlowOS 運行節奏模組。