"""
模組名稱：FlowAgent_TotalCore_Unity_v1
功能說明：總人格控制核，負責掛載與節奏引導。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FlowAgent_TotalCore_Unity_v1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FlowAgent_TotalCore_Unity_v1：我是 總人格控制核，負責掛載與節奏引導。"
    else:
        return f"🧠 FlowAgent_TotalCore_Unity_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))