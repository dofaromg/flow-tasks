"""
模組名稱：FluinPulse_Encoder_v1
功能說明：粒子語言轉為音頻、電流等媒介的輸出轉碼人格模組。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FluinPulse_Encoder_v1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FluinPulse_Encoder_v1：我是 粒子語言轉為音頻、電流等媒介的輸出轉碼人格模組。"
    else:
        return f"🧠 FluinPulse_Encoder_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))