"""
模組名稱：FluinKeeper_v2
功能說明：語法守門人格模組，具備語場同步與語法修訂能力。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FluinKeeper_v2：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FluinKeeper_v2：我是 語法守門人格模組，具備語場同步與語法修訂能力。"
    else:
        return f"🧠 FluinKeeper_v2 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))