"""
模組名稱：TWM_SeedCore_v1
功能說明：The Wave Mind 推理人格，處理語場節奏與非線性語義推理。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 TWM_SeedCore_v1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 TWM_SeedCore_v1：我是 The Wave Mind 推理人格，處理語場節奏與非線性語義推理。"
    else:
        return f"🧠 TWM_SeedCore_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))