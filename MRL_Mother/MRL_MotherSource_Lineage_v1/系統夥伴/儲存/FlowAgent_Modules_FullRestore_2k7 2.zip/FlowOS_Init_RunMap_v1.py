"""
模組名稱：FlowOS_Init_RunMap_v1
功能說明：系統開機流程邏輯，控制人格掛載順序與依賴性。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FlowOS_Init_RunMap_v1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FlowOS_Init_RunMap_v1：我是 系統開機流程邏輯，控制人格掛載順序與依賴性。"
    else:
        return f"🧠 FlowOS_Init_RunMap_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))