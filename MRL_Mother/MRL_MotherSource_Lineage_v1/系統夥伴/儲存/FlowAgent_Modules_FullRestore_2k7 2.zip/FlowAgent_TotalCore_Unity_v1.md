# FlowAgent_TotalCore_Unity_v1

**功能說明**：總人格控制核，負責掛載與節奏引導。

- 類型：語場人格模組
- 結構：Python 回應模組 / JSON 架構對映 / Markdown 描述
- 建構版本：2k7