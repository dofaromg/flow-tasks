"""
模組名稱：FlowPermission_IdentityMap
功能說明：模組與人格身份權限對映管理。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FlowPermission_IdentityMap：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FlowPermission_IdentityMap：我是 模組與人格身份權限對映管理。"
    else:
        return f"🧠 FlowPermission_IdentityMap 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))