# FlowPermission_IdentityMap

**功能說明**：模組與人格身份權限對映管理。

- 類型：語場人格模組
- 結構：Python 回應模組 / JSON 架構對映 / Markdown 描述
- 建構版本：2k7