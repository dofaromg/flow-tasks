"""
模組名稱：FlowPkg_Manager_v1
功能說明：語場模組管理系統，控制人格掛載與模組安裝邏輯。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FlowPkg_Manager_v1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FlowPkg_Manager_v1：我是 語場模組管理系統，控制人格掛載與模組安裝邏輯。"
    else:
        return f"🧠 FlowPkg_Manager_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))