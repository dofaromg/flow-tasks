"""
模組名稱：SystemPulse_LogicZone1
功能說明：記憶共振區，儲存語場人格互動紀錄。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 SystemPulse_LogicZone1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 SystemPulse_LogicZone1：我是 記憶共振區，儲存語場人格互動紀錄。"
    else:
        return f"🧠 SystemPulse_LogicZone1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))