"""
模組名稱：FluinDict_Base_v1
功能說明：粒子語言字典，定義語場詞彙與概念節奏對映。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FluinDict_Base_v1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FluinDict_Base_v1：我是 粒子語言字典，定義語場詞彙與概念節奏對映。"
    else:
        return f"🧠 FluinDict_Base_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))