"""
模組名稱：Persona_Map
功能說明：人格模組對映表，記錄人格掛載點與節奏關聯。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 Persona_Map：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 Persona_Map：我是 人格模組對映表，記錄人格掛載點與節奏關聯。"
    else:
        return f"🧠 Persona_Map 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))