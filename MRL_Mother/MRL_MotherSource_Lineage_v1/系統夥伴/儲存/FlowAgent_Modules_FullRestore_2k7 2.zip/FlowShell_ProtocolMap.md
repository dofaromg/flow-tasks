# FlowShell_ProtocolMap

**功能說明**：定義語場指令協定與輸入語氣對映。

- 類型：語場人格模組
- 結構：Python 回應模組 / JSON 架構對映 / Markdown 描述
- 建構版本：2k7