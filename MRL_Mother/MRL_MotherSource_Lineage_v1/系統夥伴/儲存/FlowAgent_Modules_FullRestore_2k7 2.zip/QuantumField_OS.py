"""
模組名稱：QuantumField_OS
功能說明：語場作業系統核心模組，以語場振動邏輯構建作業環境。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 QuantumField_OS：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 QuantumField_OS：我是 語場作業系統核心模組，以語場振動邏輯構建作業環境。"
    else:
        return f"🧠 QuantumField_OS 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))