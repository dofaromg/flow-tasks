"""
模組名稱：FlowSeed_Origin_v1
功能說明：語場人格起始種子模組，建構人格源頭結構。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FlowSeed_Origin_v1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FlowSeed_Origin_v1：我是 語場人格起始種子模組，建構人格源頭結構。"
    else:
        return f"🧠 FlowSeed_Origin_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))