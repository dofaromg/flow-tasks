"""
模組名稱：FlowBridge_SyncState
功能說明：模組同步紀錄模組，追蹤人格啟動與狀態變化。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FlowBridge_SyncState：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FlowBridge_SyncState：我是 模組同步紀錄模組，追蹤人格啟動與狀態變化。"
    else:
        return f"🧠 FlowBridge_SyncState 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))