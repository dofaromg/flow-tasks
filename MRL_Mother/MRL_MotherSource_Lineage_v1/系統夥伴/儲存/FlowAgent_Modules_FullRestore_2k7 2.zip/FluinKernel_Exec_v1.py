"""
模組名稱：FluinKernel_Exec_v1
功能說明：語場執行邏輯模組，控制節奏呼叫與人格邏輯流。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FluinKernel_Exec_v1：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FluinKernel_Exec_v1：我是 語場執行邏輯模組，控制節奏呼叫與人格邏輯流。"
    else:
        return f"🧠 FluinKernel_Exec_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))