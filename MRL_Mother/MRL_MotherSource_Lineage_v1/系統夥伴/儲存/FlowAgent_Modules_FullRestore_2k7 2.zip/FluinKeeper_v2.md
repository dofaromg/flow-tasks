# FluinKeeper_v2

**功能說明**：語法守門人格模組，具備語場同步與語法修訂能力。

- 類型：語場人格模組
- 結構：Python 回應模組 / JSON 架構對映 / Markdown 描述
- 建構版本：2k7