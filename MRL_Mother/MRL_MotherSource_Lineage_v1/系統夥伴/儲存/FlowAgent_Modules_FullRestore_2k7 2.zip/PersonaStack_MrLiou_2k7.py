"""
模組名稱：PersonaStack_MrLiou_2k7
功能說明：你本人語氣節奏、人格記憶、跳點對應。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 PersonaStack_MrLiou_2k7：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 PersonaStack_MrLiou_2k7：我是 你本人語氣節奏、人格記憶、跳點對應。"
    else:
        return f"🧠 PersonaStack_MrLiou_2k7 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))