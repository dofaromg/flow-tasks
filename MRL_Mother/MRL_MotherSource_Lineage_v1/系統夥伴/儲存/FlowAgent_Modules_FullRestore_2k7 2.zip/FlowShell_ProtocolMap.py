"""
模組名稱：FlowShell_ProtocolMap
功能說明：定義語場指令協定與輸入語氣對映。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FlowShell_ProtocolMap：你好，有什麼我可以幫助的？"
    elif "你是誰" in input_text:
        return "🧠 FlowShell_ProtocolMap：我是 定義語場指令協定與輸入語氣對映。"
    else:
        return f"🧠 FlowShell_ProtocolMap 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))