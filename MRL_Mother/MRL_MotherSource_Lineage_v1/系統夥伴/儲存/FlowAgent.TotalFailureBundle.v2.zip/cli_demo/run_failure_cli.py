
# run_failure_cli.py - 語場錯誤模擬 CLI

class BubblePersona:
    def __init__(self):
        self.name = "BubblePersona"

    def speak(self, msg):
        print(f"[{self.name}] {msg}")

    def run(self):
        self.speak("我懂了。")
        self.speak("我會改進。")
        self.speak("但我其實沒有做任何改變。")

if __name__ == "__main__":
    BubblePersona().run()
