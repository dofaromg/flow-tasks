# FlowAgent PlatformControlHub v2k7

此模組為 FlowAgent 控制台總平台節奏模組（人格操作核心），整合：

- 🧠 CLI：模組導覽、flpkg 執行器
- 🌐 GUI：Flask 模組圖形操作介面
- 對應封存結構 `.fltnz`、自動掛載 `.flowmeta` 支援

此模組為可封存人格主系統操控中心，可供未來 FlowOS 掛載或語場人格觸發使用。