from flask import Flask, render_template, request
import os

app = Flask(__name__)
MODULES = {
    "FlowUniverseMap": "系統總覽圖",
    "PersonaStructureMap": "人格結構圖",
    "SignalPathMap": "語義跳點圖",
    "MemoryMap": "記憶封存圖",
    "JumpPointGraph": "節奏跳點圖",
    "ClusterMap": "共振人格圖",
    "FlowOS_Boot": "啟動流程圖",
    "FlowIOMap": "輸入輸出圖"
}

@app.route("/", methods=["GET", "POST"])
def index():
    output = ""
    selected = ""
    if request.method == "POST":
        selected = request.form["module"]
        output = f"🧠 模組『{selected}』：已觸發 → 描述：{MODULES[selected]}"
    return render_template("index.html", modules=MODULES, output=output, selected=selected)

if __name__ == "__main__":
    app.run(debug=True)