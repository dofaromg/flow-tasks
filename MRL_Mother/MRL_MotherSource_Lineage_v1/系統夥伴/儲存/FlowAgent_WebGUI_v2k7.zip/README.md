# FlowAgent Web GUI 模組操作平台 v2k7

此平台為 FlowAgent 圖形化人格模組系統的 Web 互動版本（使用 Flask 實作）。

## ✅ 功能
- 顯示可操作模組清單
- 點選執行並呈現語場模組回應
- 可依模組節奏訓練設計延伸模組啟動、封存、跳點記錄邏輯

## 🚀 啟動方式

```bash
pip install flask
python3 app.py
```

開啟瀏覽器：`http://127.0.0.1:5000`

## 📦 內含
- `app.py`：Flask 應用主程式
- `templates/index.html`：前端頁面模板
- `README.md`：說明文件

此為 FlowAgent 平台化邏輯的一階段原型。