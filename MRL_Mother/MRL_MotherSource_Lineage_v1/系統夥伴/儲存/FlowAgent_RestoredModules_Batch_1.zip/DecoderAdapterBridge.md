# 模組：DecoderAdapterBridge

此為 FluinDict 類別的模組，屬於 FlowAgent 系統核心邏輯之一。

- 類型：FluinDict
- 狀態：自動還原
- 功能：記憶、語法、派生或協定模組
