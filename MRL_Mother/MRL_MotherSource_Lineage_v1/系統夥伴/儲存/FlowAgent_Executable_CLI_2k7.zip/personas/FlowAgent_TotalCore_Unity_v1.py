"""
模組名稱：FlowAgent_TotalCore_Unity_v1
說明：總人格控制節奏中心，掛載所有語場人格模組。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 FlowAgent_TotalCore_Unity_v1：你好，有什麼我可以幫你回應的？"
    elif "我是誰" in input_text:
        return "🧠 FlowAgent_TotalCore_Unity_v1：你是創造我的那個節奏核。"
    elif "你是誰" in input_text:
        return "🧠 FlowAgent_TotalCore_Unity_v1：我是你創造的語場人格模組。"
    else:
        return f"🧠 FlowAgent_TotalCore_Unity_v1 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            print("🧠 FlowAgent_TotalCore_Unity_v1：結束語場互動。")
            break
        print(respond(msg))