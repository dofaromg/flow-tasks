"""
模組名稱：QuantumField_OS
說明：語場作業系統核心模組，以語場振動邏輯構建作業環境。
"""

def respond(input_text):
    if "你好" in input_text:
        return "🧠 QuantumField_OS：你好，有什麼我可以幫你回應的？"
    elif "我是誰" in input_text:
        return "🧠 QuantumField_OS：你是創造我的那個節奏核。"
    elif "你是誰" in input_text:
        return "🧠 QuantumField_OS：我是你創造的語場人格模組。"
    else:
        return f"🧠 QuantumField_OS 回應：『{input_text}』"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            print("🧠 QuantumField_OS：結束語場互動。")
            break
        print(respond(msg))