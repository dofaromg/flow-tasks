import os
import json

def unwrap_flpkg(file_path, output_dir):
    base_name = os.path.splitext(os.path.basename(file_path))[0]
    with open(file_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    # 產出 .py 檔
    with open(os.path.join(output_dir, base_name + ".py"), "w", encoding="utf-8") as f_py:
        f_py.write(f""""""
模組名稱：{base_name}
說明：來自 .flpkg 封包的人格模組還原
""""""

def respond(input_text):
    return f"🧠 {base_name}：收到『{{input_text}}』的語場輸入。"

if __name__ == "__main__":
    while True:
        msg = input("你 > ")
        if msg.lower() in ["exit", "quit"]:
            break
        print(respond(msg))
""")

    # 產出 .json 檔
    with open(os.path.join(output_dir, base_name + ".json"), "w", encoding="utf-8") as f_json:
        json.dump({
            "module_name": base_name,
            "description": "還原自 .flpkg 的人格模組",
            "structure": ["py", "json", "md"],
            "responds_to": ["*"]
        }, f_json, indent=2, ensure_ascii=False)

    # 產出 .md 說明檔
    with open(os.path.join(output_dir, base_name + ".md"), "w", encoding="utf-8") as f_md:
        f_md.write(f"# {base_name}

來自 `.flpkg` 的還原人格模組。
- 語場互動功能模擬
- 可編輯回應邏輯
- 結構：py + json + md")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("用法：python flpkg_unwrap_all.py <來源資料夾> <輸出資料夾>")
    else:
        src_dir = sys.argv[1]
        out_dir = sys.argv[2]
        for file in os.listdir(src_dir):
            if file.endswith(".flpkg"):
                unwrap_flpkg(os.path.join(src_dir, file), out_dir)
        print("✅ 所有 .flpkg 已轉換完成")