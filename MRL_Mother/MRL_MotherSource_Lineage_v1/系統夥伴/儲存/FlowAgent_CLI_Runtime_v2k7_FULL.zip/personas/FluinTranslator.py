import json

class FluinTranslator:
    def __init__(self, path="personas/Flowers.json"):
        with open(path, "r", encoding="utf-8") as f:
            self.dictionary = json.load(f)

    def decode(self, sequence):
        return [self.dictionary.get(token, f"[未知:{token}]") for token in sequence]

    def encode(self, meanings):
        return [k for k, v in self.dictionary.items() if v in meanings]

if __name__ == "__main__":
    translator = FluinTranslator()
    print("✔️ FluinTranslator 啟動")
    print("輸入 ['Seed', 'Init', 'Collapse'] →", translator.decode(['Seed', 'Init', 'Collapse']))
    print("輸入 ['初始化人格模組節奏點'] →", translator.encode(['初始化人格模組節奏點']))