import json
import os

def load_personas():
    if not os.path.exists("personas/persona_index.json"):
        print("❌ 找不到 persona_index.json，請確認檔案存在於 personas/")
        return []
    with open("personas/persona_index.json", "r", encoding="utf-8") as f:
        return json.load(f)

def run_persona(key):
    try:
        with open(f"personas/{key}.txt", "r", encoding="utf-8") as f:
            content = f.read()
        print(f"🧠 [人格 {key}] 已啟動：\n---\n{content}\n---")
    except:
        print(f"❌ 找不到人格模組 {key}.txt")

def main():
    print("🌀 FlowAgent CLI 啟動")
    personas = load_personas()
    if not personas:
        return
    print("可用人格模組：")
    for p in personas:
        print(f"- {p}")
    while True:
        cmd = input("你 > ").strip()
        if cmd == "exit":
            break
        elif cmd.startswith("run "):
            key = cmd.split(" ", 1)[1]
            run_persona(key)
        else:
            print("❔ 指令無效，請使用：run <人格名>、exit")

if __name__ == "__main__":
    main()