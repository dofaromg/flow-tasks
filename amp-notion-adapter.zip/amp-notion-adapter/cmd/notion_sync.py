import os, yaml
from notion_client import Client
from core.schema import to_index
from storage.index_writer import append_index
from graph.chain import chain_append
from notion.fetch import get_page, get_db, list_children_blocks

def run(cfg_path="config.yaml"):
    cfg = yaml.safe_load(open(cfg_path, "r", encoding="utf-8"))
    token = os.environ.get(cfg["notion"]["token_env"])
    if not token:
        raise SystemExit("Missing NOTION_TOKEN env var")

    client = Client(auth=token)
    index_path = cfg["output"]["index_path"]
    chain_path = cfg["output"]["chain_path"]

    prev = ""
    visited = set()

    def ingest_obj(obj: dict):
        nonlocal prev
        idx = to_index(obj)
        if not idx.get("id") or idx["id"] in visited:
            return
        visited.add(idx["id"])
        append_index(idx, index_path)
        prev = chain_append(idx, prev, chain_path)

    roots = cfg["notion"]["roots"]
    for rid in roots:
        try:
            ingest_obj(get_page(client, rid))
            for b in list_children_blocks(client, rid):
                if b.get("type") == "child_page":
                    try:
                        ingest_obj(get_page(client, b["id"]))
                    except Exception:
                        pass
        except Exception:
            try:
                ingest_obj(get_db(client, rid))
            except Exception:
                pass

    print(f"OK: wrote {len(visited)} objects")
    print(f"index: {index_path}")
    print(f"chain: {chain_path}")

if __name__ == "__main__":
    run()
