# amp-notion-adapter (index-only)

Minimal, deployable Notion → index/chain adapter.

## What it does
- Reads **metadata only** from specified Notion root Page/Database IDs
- Writes:
  - `notion_index.jsonl` (index stream)
  - `chain.jsonl` (append-only causal chain)

## Quickstart (local)
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export NOTION_TOKEN="..."
python cli.py notion-sync config.yaml
```

## Docker
```bash
docker build -t amp-notion-adapter .
docker run --rm -e NOTION_TOKEN="..." -v "$PWD:/data" amp-notion-adapter notion-sync /data/config.yaml
```

Outputs will be written into `/data` (your current folder mounted into the container).
