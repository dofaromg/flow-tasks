from notion_client import Client

def get_page(client: Client, page_id: str) -> dict:
    return client.pages.retrieve(page_id=page_id)

def get_db(client: Client, db_id: str) -> dict:
    return client.databases.retrieve(database_id=db_id)

def list_children_blocks(client: Client, block_id: str, page_size: int = 100):
    cursor = None
    while True:
        resp = client.blocks.children.list(block_id=block_id, start_cursor=cursor, page_size=page_size)
        for b in resp.get("results", []) or []:
            yield b
        cursor = resp.get("next_cursor")
        if not resp.get("has_more"):
            break
