import hashlib, json

def _h(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()

def chain_append(idx: dict, prev_hash: str, path: str) -> str:
    payload = json.dumps(idx, ensure_ascii=False, sort_keys=True)
    node_hash = _h(prev_hash + ":" + _h(payload))
    record = {
        "hash": node_hash,
        "prev": prev_hash,
        "id": idx.get("id"),
        "type": idx.get("type"),
        "t": idx.get("last_edited_time"),
    }
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    return node_hash
