import json

def append_index(idx: dict, path: str):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(idx, ensure_ascii=False) + "\n")
