def to_index(obj: dict) -> dict:
    _id = obj.get("id")
    _type = obj.get("object")  # "page" or "database"
    _parent = obj.get("parent", {})
    _parent_type = _parent.get("type")
    _parent_id = _parent.get(_parent_type) if _parent_type else None

    created = obj.get("created_time")
    updated = obj.get("last_edited_time")
    archived = obj.get("archived", False)

    title = None
    if _type == "page":
        props = obj.get("properties", {}) or {}
        for _, v in props.items():
            if (v or {}).get("type") == "title":
                t = v.get("title", []) or []
                title = "".join([x.get("plain_text", "") for x in t])[:120]
                break
    elif _type == "database":
        t = obj.get("title", []) or []
        title = "".join([x.get("plain_text", "") for x in t])[:120]

    return {
        "id": _id,
        "type": _type,
        "parent_type": _parent_type,
        "parent_id": _parent_id,
        "created_time": created,
        "last_edited_time": updated,
        "archived": archived,
        "title": title,
    }
