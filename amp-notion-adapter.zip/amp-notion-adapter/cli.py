import sys
from cmd.notion_sync import run as notion_sync

def main():
    if len(sys.argv) < 2:
        raise SystemExit("usage: python cli.py notion-sync [config.yaml]")
    cmd = sys.argv[1]
    cfg = sys.argv[2] if len(sys.argv) > 2 else "config.yaml"
    if cmd == "notion-sync":
        notion_sync(cfg)
    else:
        raise SystemExit("unknown command")

if __name__ == "__main__":
    main()
